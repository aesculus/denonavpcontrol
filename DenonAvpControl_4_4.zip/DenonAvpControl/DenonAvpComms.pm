#	DenonAvpComms
#
#	Author:	Chris Couper <chris(dot)c(dot)couper(at)gmail(dot)com>
#
#	Copyright (c) 2008-2021 Chris Couper
#	All rights reserved.
#
#	----------------------------------------------------------------------
#	Function:	Send HTTP Commands to support DenonAvpControl plugin
#	This program is free software; you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation; either version 2 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program; if not, write to the Free Software
#	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
#	02111-1307 USA
#
package Plugins::DenonAvpControl::DenonAvpComms;

use strict;
use base qw(Slim::Networking::Async);

use URI;
use Slim::Utils::Log;
use Slim::Utils::Misc;
use Slim::Utils::Prefs;
use Socket qw(:crlf);
use Data::Dumper; #used to debug array contents

# ----------------------------------------------------------------------------
my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.denonavpcontrol',
	'defaultLevel' => 'ERROR',
	'description'  => 'PLUGIN_DENONAVPCONTROL_MODULE_NAME',
});

# ----------------------------------------------------------------------------
# Global Variables
# ----------------------------------------------------------------------------
	my $prefs = preferences('plugin.denonavpcontrol'); #name of preferences
	my $self;
	my %gGetPSModes = 0;	# looping through the PS modes
#	my %gInputQueryCount = 0;   # use this if we need to limit the number of SI? retries
	my %gInputQueryInProgress = 0;
	my %gNewAvr = 0;
	our %channels = ();

	my @surroundModes = ( # the avp surround mode commands
		'MSDIRECT',
		'MSPURE DIRECT',
		'MSSTEREO',
		'MSSTANDARD',
		'MSDOLBY DIGITAL',
		'MSDTS SURROUND',
		'MSWIDE SCREEN',
		'MS7CH STEREO',
		'MSSUPER STADIUM',
		'MSROCK ARENA',
		'MSJAZZ CLUB',
		'MSCLASSIC CONCERT',
		'MSMONO MOVIE',
		'MSMATRIX',
		'MSVIDEO GAME'
		);
	my @surroundModes_r = ( # the avr surround mode commands
		'MSDIRECT',
		'MSPURE DIRECT',
		'MSSTEREO',
		'MSSTANDARD',
		'MSDOLBY DIGITAL',
		'MSDTS SURROUND',
		'MSMCH STEREO',
		'MSROCK ARENA',
		'MSJAZZ CLUB',
		'MSMONO MOVIE',
		'MSMATRIX',
		'MSVIDEO GAME',
		'MSVIRTUAL'
		);
	my @roomModes = ( # the avp room equalizer modes
		'PSROOM EQ:AUDYSSEY',
		'PSROOM EQ:BYP.LR',
		'PSROOM EQ:FLAT',
		'PSROOM EQ:MANUAL',
		'PSROOM EQ:OFF'
		);
	my @multEqModes = ( # the avr mult equalizer modes
		'PSMULTEQ:AUDYSSEY',
		'PSMULTEQ:BYP.LR',
		'PSMULTEQ:FLAT',
		'PSMULTEQ:MANUAL',
		'PSMULTEQ:OFF'
		);
	my @nightModes = ( # the avp night modes
		'PSDYNSET NGT',
		'PSDYNSET EVE',
		'PSDYNSET DAY',
		);
	my @nightModes_avr = ( # the avr night modes
		'PSDYNVOL NGT',
		'PSDYNVOL EVE',
		'PSDYNVOL DAY',
		'PSDYNVOL OFF',
		);
	my @restorerModes = ( # the old restorer modes
		'PSRSTR OFF',
		'PSRSTR MODE1',
		'PSRSTR MODE2',
		'PSRSTR MODE3',
		);
	my @restorerModes_new = ( # the new restorer modes
		'PSRSTR OFF',
		'PSRSTR HI',
		'PSRSTR MED',
		'PSRSTR LOW',
		);
	my @dynamicVolModes = ( # the avp dynamic volume modes
		'PSDYN OFF',
		'PSDYN ON',
		'PSDYN VOL'
		);
	my @dynamicEqModes = ( # the avr dynamic Eq modes
		'PSDYNEQ OFF',
		'PSDYNEQ ON'
		);
	my @refLevelModes = ( # the avp reference level modes
		'PSREFLEV 0',
		'PSREFLEV 5',
		'PSREFLEV 10',
		'PSREFLEV 15',
		);
	my @sWPowerModes = ( #the avp SW power modes
		'PSSWR OFF',
		'PSSWR ON'
	);
# ----------------------------------------------------------------------------
# References to other classes
# ----------------------------------------------------------------------------
my $classPlugin		= undef;

# ----------------------------------------------------------------------------
sub new {
	my $ref = shift;
	$classPlugin = shift;

	$log->debug( "*** DenonAvpControl::DenonAvpComms::new() " . $classPlugin . "\n");
	$self = $ref->SUPER::new;
}

sub getChannelsHash {
	\%channels;
}

# ----------------------------------------------------------------------------
sub SendNetAvpVol {
	my $client = shift;
	my $url = shift;
	my $vol = shift;
	my $zone = shift;
	my $request;

	if ($zone == 0 ) {
		$request= "MV" .  $vol . $CR ;
	} elsif ($zone == 1 ) {
		$request= "Z2" .  $vol . $CR ;
	} elsif ($zone == 2 ) {
		$request= "Z3" .  $vol . $CR ;
	} else {
		$request= "Z4" .  $vol . $CR ;
	}
	$log->debug("Calling writemsg for volume command: $request");	
	writemsg($request, $client, $url);
}

# ----------------------------------------------------------------------------
sub SendNetAvpVolSetting {
	my $client = shift;
	my $url = shift;
	my $zone = shift;
	my $request;
	
	if ($zone == 0 ) {
		$request= "MV?" . $CR ;
	} elsif ($zone == 1 ) {
		$request= "Z2?" . $CR ;
	} elsif ($zone == 2 ) {
		$request= "Z3?" . $CR ;
	} else {
		$request= "Z4?" . $CR ;
	}
	$log->debug("Calling writemsg for volume request: $request");	
	writemsg($request, $client, $url);
}

# ----------------------------------------------------------------------------
sub SendNetAvpSurroundMode {
	my $client = shift;
	my $url = shift;
	my $mode = shift;
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $request;
	
	if ($avp == 0) {
		$request = $surroundModes_r[$mode] . $CR ;
	} else {
		$request = $surroundModes[$mode] . $CR ;
	}
	writemsg($request, $client, $url, 2);
}

# ----------------------------------------------------------------------------
sub SendNetAvpRoomMode {
	my $client = shift;
	my $url = shift;
	my $mode = shift;
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $request;
	
	if ($avp == 0) {
		$request = $multEqModes[$mode] . $CR ;		
	} else {
		$request = $roomModes[$mode] . $CR ;
	}
	writemsg($request, $client, $url);
}

# ----------------------------------------------------------------------------
sub SendNetAvpNightMode {
	my $client = shift;
	my $url = shift;
	my $mode = shift;
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $request;

	if ($avp == 0) {
		$request = $nightModes_avr[$mode] . $CR ;
	} else {
		$request = $nightModes[$mode] . $CR ;
	}
	writemsg($request, $client, $url);
}

# ----------------------------------------------------------------------------
sub SendNetAvpRestorerMode {
	my $client = shift;
	my $url = shift;
	my $mode = shift;
	my $new = shift;
	my $request;

	if ($new || ($gNewAvr{$client} == 1)) {    # use new API for new AVR models
		$request = $restorerModes_new[$mode] . $CR ;
	} else {
		$request = $restorerModes[$mode] . $CR ;
	}
	writemsg($request, $client, $url);
}

# ----------------------------------------------------------------------------
sub SendNetDynamicEq {
	my $client = shift;
	my $url = shift;
	my $mode = shift;
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $request;

	$log->debug("Calling writemsg for dynamic eq command");	
	if ($avp == 0) {
		$request = $dynamicEqModes[$mode] . $CR ;		
	} else {
		$request = $dynamicVolModes[$mode] . $CR ;
	}
	writemsg($request, $client, $url);
}

# ----------------------------------------------------------------------------
sub SendNetRefLevel {
	my $client = shift;
	my $url = shift;
	my $mode = shift;

	$log->debug("Calling writemsg for reference level command");	
	my $request = $refLevelModes[$mode] . $CR ;
	writemsg($request, $client, $url);
}

# ----------------------------------------------------------------------------
sub SendNetSwState{
	my $client = shift;
	my $url = shift;
	my $mode = shift;
	
	$log->debug("Calling writemsg for subwoofer on/off command");
	my $request = $sWPowerModes[$mode] . $CR ;
	writemsg($request, $client, $url);
}

# ----------------------------------------------------------------------------
sub SendNetGetAvpSettings {
	my $client = shift;
	my $url = shift;
	my $sMode = shift;
	my $request;

	if ( ($sMode == 0) || ($sMode == 1))  {
		$gGetPSModes{$client} = 1; #its the main menu looking for all settings
		$request= "MS?" . $CR ;
		if ($sMode == 1) {
			$channels{$client,"POPULATED"} = 0;  # need to populate the channel volume table
		}
	} else {
		$gGetPSModes{$client} = -1; #its the index menus looking for one setting
		$request= $sMode . $CR ;	
	}
	writemsg($request, $client, $url);
}

# ----------------------------------------------------------------------------
sub SendNetChannelLevel {
	my $client = shift;
	my $url = shift;
	my $zone = shift;
	my $channel = shift;
	my $value = shift;	
	my $request;	
	
	if ($zone == 0 ) {
		$request= "" ;
	} elsif ($zone == 1 ) {
		$request= "Z2" ;
	} elsif ($zone == 2 ) {
		$request= "Z3" ;
	} else {
		$request = "Z4" ;
	}
	$request = $request . $channel . " " . $value . $CR ;
	
	$log->debug("Calling writemsg for channel setting " . $request);
	writemsg($request, $client, $url);
}

# ----------------------------------------------------------------------------
sub SendNetAvpChannelLevels {
	my $client = shift;
	my $url = shift;
	my $zone = shift;
	my $timeout = 1;
	my $request;
	
	if ($zone == 0 ) {
		$request= "" ;
	} elsif ($zone == 1 ) {
		$request= "Z2" ;
	} elsif ($zone == 2 ) {
		$request= "Z3" ;
	} else {
		$request = "Z4" ;
	}
	$request =  $request . "CV?" . $CR ;
	
	$channels{$client,"POPULATED"} = 0; 

	$log->debug("Calling query for channel level values");	
	writemsg($request, $client, $url, $timeout);
}

# ----------------------------------------------------------------------------
sub LoopGetAvpSettings {
	my $client = shift;
	my $url = shift;
	Slim::Utils::Timers::killTimers( $client, \&SendTimerLoopRequest);
	Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + .1), \&SendTimerLoopRequest, $url);	
}

# ----------------------------------------------------------------------------
sub SendTimerLoopRequest {
	my $client = shift;
	my $url = shift;
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $zone = $cprefs->get('zone');
	my $request;
	my $timeout = 0.5;	
	
	if ($gInputQueryInProgress{$client} == 1) {  # wait for SI? command to complete
		$log->debug("Timer loop request: 'SI?' in progress - retry");	
		LoopGetAvpSettings($client, $url); 
	}	
	
	if ($avp == 0 && $gGetPSModes{$client} == 4) { #avr don't do this
		$gGetPSModes{$client} = 5; #skip it
	}

	if ($gGetPSModes{$client} == 7) { # subwoofer on/off not supported for now
		$gGetPSModes{$client} = 8; #skip it
	}
	
	$log->debug("Timer loop request: PSMode=" . $gGetPSModes{$client});	
	
	if ($gGetPSModes{$client} == 1) {
		$request= "MS?" . $CR ;
	} elsif ($gGetPSModes{$client} == 2) {
		if ($avp == 0) {
			$request= "PSMULTEQ: ?" . $CR ;
		} else {
			$request= "PSROOM EQ: ?" . $CR ;
		}
	} elsif ($gGetPSModes{$client} == 3) {
		if ($avp == 0) {
			$request= "PSDYNEQ ?" . $CR ;
		} else {
			$request= "PSDYN ?" . $CR ;
		}
	} elsif ($gGetPSModes{$client} == 4) { #avp only
		$request= "PSDYNSET ?" . $CR ;
	} elsif ($gGetPSModes{$client} == 5) {
		$request= "PSRSTR ?" . $CR ;
	} elsif ($gGetPSModes{$client} == 6) {
		$request= "PSREFLEV ?" . $CR ;
	} elsif ($gGetPSModes{$client} == 7) {
		$request= "PSSWR ?" . $CR ;
	} elsif ($gGetPSModes{$client} == 8) {
		if ($channels{$client,"POPULATED"} == 0) {  #need to populate the channel vol table
			if ($zone == 0 ) {
				$request= "" ;
			} elsif ($zone == 1 ) {
				$request= "Z2" ;
			} elsif ($zone == 2 ) {
				$request= "Z3" ;
			} else {
				$request = "Z4" ;
			}
			$request =  $request . "CV?" . $CR ;
		} else {
			$gGetPSModes{$client} = 0; #already populated, end gracefully
			return;
		}
	} else {
		$gGetPSModes{$client} = -1; #cancel it, we are done	
		return;
	}
	writemsg($request, $client, $url, $timeout);	  
}

# ----------------------------------------------------------------------------
sub SendNetAvpMuteStatus {
	my $client = shift;
	my $url = shift;
	my $timeout = 1;
	my $request = "MU?" . $CR ;	

	$log->debug("Calling query for mute status");	
	writemsg($request, $client, $url, $timeout);
}

# ----------------------------------------------------------------------------
sub SendNetAvpMuteToggle {
	my $client = shift;
	my $url = shift;
	my $zone = shift;
	my $muteToggle = shift;
	my $timeout = .500;
	my $request;
	
	if ($zone == 0 ) {
		$request= "" ;
	} elsif ($zone == 1 ) {
		$request= "Z2" ;
	} elsif ($zone == 2 ) {
		$request= "Z3" ;
	} else {
		$request = "Z4" ;
	}

	if ($muteToggle == 1) {
		$request = $request . "MUON" . $CR ;
	}
	else {
		$request = $request . "MUOFF" . $CR ;
	}
	
	$log->debug("Calling writemsg for Mute command");	
	writemsg($request, $client, $url, $timeout);
}

# ----------------------------------------------------------------------------
sub SendNetAvpPowerStatus {
	my $client = shift;
	my $url = shift;
	my $zone = shift;
	my $request;
	my $timeout = .500;
#	my $timeout = 2;

	$log->debug("Calling query for zone state");	
	if ($zone == 0 ) {
		$request= "ZM?" . $CR;
	} elsif ($zone == 1 ) {
		$request= "Z2?" . $CR ;
	} elsif ($zone == 2 ) {
		$request= "Z3?" . $CR ;
	} else {
		$request = "Z4?" . $CR ;
	}
	writemsg($request, $client, $url, $timeout);
}

# ----------------------------------------------------------------------------
sub SendNetAvpOn {
	my $client = shift;
	my $url = shift;
	my $zone = shift;
	my $request;
#	my $timeout = 1;
	my $timeout = 2;

	$log->debug("Calling writemsg for On command");	
	if ($zone == 0 ) {
		$request= "ZMON" . $CR;
	} elsif ($zone == 1 ) {
		$request= "Z2ON" . $CR ;
	} elsif ($zone == 2 ) {
		$request= "Z3ON" . $CR ;
	} else {
		$request = "Z4ON" . $CR ;
	}
	writemsg($request, $client, $url, $timeout);
}

# ----------------------------------------------------------------------------
sub SendNetAvpStandBy {
	my $client = shift;
	my $url = shift;
	my $zone = shift;
	my $request;
	
	$log->debug("Calling writemsg for Standby command");
	if ($zone == 0 ) {
		$request= "ZMOFF" . $CR ;
	} elsif ($zone == 1 ) {
		$request= "Z2OFF" . $CR ;
	} elsif ($zone == 2 ) {
		$request= "Z3OFF" . $CR ;
	} else {
		$request= "Z4OFF" . $CR ;
	}
	writemsg($request, $client, $url);
}

# ----------------------------------------------------------------------------
sub SendNetAvpQuickSelect {
	my $client = shift;
	my $url = shift;
	my $quickSelect = shift;
	my $zone = shift;
	my $timeout = shift;
	my $request;

	$log->debug("Calling writemsg for quick select command");	
	if ($zone == 0 ) {
		$request = "MS";
	} else {
		$zone++;
		$request = "Z" . $zone;
	}
	$request = $request . "QUICK" . $quickSelect . $CR;
	$log->debug("Request is: " . $request);
	writemsg($request, $client, $url, $timeout);
}

# ----------------------------------------------------------------------------
sub SendNetAvpSaveQuickSelect {  # save the Quick Select settings to AVR
	my $client = shift;
	my $url = shift;
	my $quickSelect = shift;
	my $request;

	$log->debug("Calling writemsg for quick select save command");	
	$request = "MSQUICK" . $quickSelect . " MEMORY" . $CR;
	$log->debug("Request is: " . $request);
	writemsg($request, $client, $url, 2);
}

# ----------------------------------------------------------------------------
sub SendNetAvpInputSource {  # for now, this is only for main zone
	my $client = shift;
	my $url = shift;
	my $zone = shift;
	my $request = "SI?" . $CR ;
	
	if ($zone != 0 ) {
		$log->debug("Input source query not valid for zone " . $zone . "\n" );
	} elsif ($gGetPSModes{$client} > 0 ) {  # menu settings in progress - retry
		$log->debug("Menu population in progress - retrying");	
		Slim::Utils::Timers::killTimers( $client, \&SendNetAvpInputSource);
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 1), \&SendNetAvpInputSource, $url);	
	} else {
		$gInputQueryInProgress{$client} = 1;
		$log->debug("Calling writemsg for input source query command");	
		writemsg($request, $client, $url, 1);
	}
}		

# ----------------------------------------------------------------------------
sub writemsg {
	my $request = shift;
	my $client = shift;
	my $url = shift;
	my $timeout = shift;	

#	$log->debug("DenonAVP Command url: " . $url);

	my $u = URI->new($url);
	my @pass = [ $request, $client ];

	if (!$timeout) {
		$timeout = 0.5;		
	}

	$self->write_async( {
		host        => $u->host,
		port        => $u->port,
		content_ref => \$request,
		Timeout     => $timeout,
		skipDNS     => 1,
		onError     => \&_error,
		onRead      => \&_read,
		passthrough => [ $url, @pass ],
		} );
		
	$log->debug("Sent AVP command request: " . $request);
}

# ----------------------------------------------------------------------------
sub _error {
	my $self  = shift;
	my $errormsg = shift;
	my $url   = shift;
	my $track = shift;
	my $args  = shift;
	
	$log->debug("error routine called");

	my @track = @$track;
	my $request = @track[0];
	my $client = @track[1];

	my $cprefs = $prefs->client($client);
	my $quickSelect = $cprefs->get('quickSelect');
	
	my $error = "error connecting to AVR: error=" . $errormsg . ", request=" . $request;
	$log->warn($error);
	
	$self->disconnect;

	if ($request =~ m/SI\?\r/) {  # input source query failed
		$log->debug("Calling retryInputSource\n");	
		$classPlugin->retryInputSource($client);
	} elsif ( $errormsg =~ m/(T|t)imed out/) {   # connect or request timed out
		if ($request =~ m/ZM\?\r/) {	 # main zone power status timed out
			$log->debug("Calling handlePowerOn\n");	
			$classPlugin->handlePowerOn($client);
		} elsif ($request =~ m/ZMON\r/ || $request =~ m/Z\d\ON\r/) {  # power on timed out
			$log->debug("Calling handlePowerOn2\n");	
			$classPlugin->handlePowerOn2($client);
		} elsif ($request =~ m/(MS|Z[2-4])QUICK\d\r/) {  # QS timed out
			$log->debug("Calling handleVolReq\n");	
			my $noRetry = 0;
			if (substr($request,7,1) ne $quickSelect) {  # retry only if main QS
				$noRetry = 1;
			}				
			$classPlugin->handleVolReq($client, $noRetry);
		} elsif	($request =~ m/(MV|Z[2-4])\?/) {  # Vol Req timed out	
			$log->debug("Calling handleVolReq\n");	
			$classPlugin->handleVolReq($client, 0);
		} elsif ($request =~ m/PSRSTR MODE\d/ ) {
			my $mode = substr($request,11,1);
			$log->debug("Retrying restorer mode setting for newer AVR's\n");	
#			$gNewAvr{$client} = 1;  # set up to use new mode setting API from now on
			Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + .1),
				\&SendNetAvpRestorerMode($client, $url, $mode, 1) );  # retry the restorer mode for newer AVR's	
#			SendNetAvpRestorerMode($client, $url, $mode, 1);  # retry the restorer mode for newer AVR's
		} elsif ($gGetPSModes{$client} > 0) {  # timed out getting the AVR menu settings
			$log->debug("Retrying AVR menu settings request\n");	
			LoopGetAvpSettings($client, $url);   # retry it
		}
	}
	else {
		$gGetPSModes{$client} = 0;  # we had an error so cancel anymore outstanding AVR menu requests
	}
}

sub getCRLine($$) {
	my $socket = shift;
	my $maxWait = shift;
	my $buffer = '';
	my $start = Time::HiRes::time();
	my $c;
	my $r;
	B: while ( (Time::HiRes::time() - $start) < $maxWait ) {
		$r = $socket->read($c,1);
		if ( $r < 1 ) { next B; }
		$buffer .= $c;
		if ( $c eq "\r" ) { return $buffer; }
	}
	return $buffer;
}

sub clearbuf($$) {
	
	return;		# this routine disabled due to problem on Windows platform

	my $socket = shift;
	my $maxWait = shift;
	my $c;
	my $r;
	my $i = 0;
	my $start = Time::HiRes::time();
	if (!defined($maxWait) || ($maxWait == 0) ) {
		$maxWait = .125;
	}
	my $end = $start + $maxWait;

	
#	$log->debug("clearbuf routine called: start=".$start," end=".$end);
	do {
		$r = $socket->read($c,1);
		if ($r > 0) {
			$i++;
		}	
	}
	while ( ($r > 0) && (Time::HiRes::time() < $end) );
	
	$log->debug("clearbuf cleared ".$i." bytes\n");
#	$log->debug("...time=" . Time::HiRes::time() );
}	
	
# ----------------------------------------------------------------------------
sub _read {
	my $self  = shift;
	my $url   = shift;
	my $track = shift;
	my $args  = shift;

	my $buf;
	my $buf2;
	my @track = @$track;
	my $i;
	my $sSM;
	my $request = @track[0];
	my $client = @track[1];
	my $len;
	my $subEvent;
	my $event;
	my $callbackOK = 0; 	# the returned message when the command was successful
	my $callbackError; 	# the returned message when the command was not successful


	$log->debug("read routine called");
	$buf = &getCRLine($self->socket,.125);
	my $read = length($buf);

	if ($read == 0) {
		$callbackOK = 0;
		$self->_error("End of file", $url, $track, $args);
		return;
	} else {
		$callbackOK = 1;
		$log->debug("Read ".$read."\n");
	}

	$log->debug("Buffer read ".$buf."\n");
	$log->debug("Client name: " . $client->name . "\n");	

	if ($request =~ m/CV/) { #if CV mode then need to read each item as a new line
		$buf2 = $buf;
		my @verbs;
		my $iGotFL = 0;
		while ($callbackOK) {
			$log->debug("CV Buffer read ".$buf2."\n");	
			if (substr($buf2,0,2) =~ m/Z\d/) {  #secondary zone
				$buf2 = substr($buf2,2);  # bump past the zone
			}
			$event = substr($buf2,0,2);
			if ($event eq "CV") {
				@verbs = split (/ /, $buf2);
				$channels{$client,$verbs[0]} = $verbs[1];
				if ($verbs[0] eq "CVFL") {
					$iGotFL = 1;
				}
			} elsif ($iGotFL == 1) {  # exit early as long as we got at least one
				&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
				last;
			}				
			$buf2 = &getCRLine($self->socket,.125);	
			$read = length($buf2);
			if ($read == 0) {
				$callbackOK = 0;
			} else {
				$callbackOK = 1;
			}
		}
		if ($iGotFL == 1) {
			$channels{$client,"POPULATED"} = 1;
		}

#		if ($channels{$client,"POPULATED"} == 1 ) {
#			$log->debug(Dumper(\%channels));
#		}
	}

	if ($gGetPSModes{$client} == -1 || ($gGetPSModes{$client} == 8 && $channels{$client,"POPULATED"} == 1)) {
		$log->debug("Disconnecting Comms Session. gGetPSModes:" . $gGetPSModes{$client} . "\n");		
		Slim::Utils::Timers::killTimers( $client, \&SendTimerLoopRequest);
		$self->disconnect;
		$gGetPSModes{$client} = 0;
	}

	# see what is coming back from the AVP
	my $command = substr($request,0,3);
	$log->debug("Command is:" .$request);

	$log->debug("Subcommand is:" .$command. "\n");
	if ($request =~ m/ZMON\r/ || $request =~ m/ZM\?\r/) {	# power on or status
		if ( ($buf eq 'ZMON'. $CR) || (substr($buf,0,2) eq 'CV') ) {  
			&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
			$self->disconnect;
			$log->debug("Calling HandlePowerOn2\n");	
			$classPlugin->handlePowerOn2($client);
		} elsif ($buf eq 'ZMOFF'. $CR) {
			$self->disconnect;
			$log->debug("Calling HandlePowerOn\n");	
			$classPlugin->handlePowerOn($client);
		}
	} elsif ($request =~ m/Z\d\ON\r/ ) {   # zone power on
		if ( ($buf =~ m/Z\d\ON\r/) || (substr($buf,0,2) eq 'CV') ) {	# zone is on
			&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
			$self->disconnect;
			$log->debug("Zone is powered on\n");
			$log->debug("Calling HandlePowerOn2\n");	
			$classPlugin->handlePowerOn2($client);
		}
		elsif ($buf =~ m/Z\d\OFF\r/) {	 # zone is off
			$self->disconnect;
			$log->debug("Calling HandlePowerOn for Zone\n");	
			$classPlugin->handlePowerOn($client);
		}	
	} elsif ($request =~ m/(MS|Z[2-4])QUICK\d\r/) {	# quick setting	
		$event = substr($buf,0,2);
		my $cprefs = $prefs->client($client);
		my $quickSelect = $cprefs->get('quickSelect');
		if ( $buf eq $request || $buf eq 'PWON' . $CR || substr($buf,0,5) eq 'MVMAX' 
		  || substr($buf,0,2) eq 'CV' || substr($buf,0,2) eq 'HD') {			  
#		  || substr($buf,0,2) eq 'CV' || substr($buf,0,2) eq 'HD' || substr($request,7,1) ne $quickSelect) {
			&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
			$self->disconnect;
			$classPlugin->handleVolReq($client, 0);
		} elsif ( $buf =~ m/(MV|Z[2-4])\d\d/) {	# see if the element is a volume
			if ( ($event eq 'MV' && substr($request,0,2) eq 'MS') || $event eq substr($request,0,2)) {   # make sure it's our volume
				$subEvent = substr($buf,2,3);
				# call the plugin routine to deal with the volume
				&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
				$self->disconnect;		
				$classPlugin->updateSqueezeVol($client, $subEvent);				 
			}
		} elsif ( ($event eq 'SI') && substr($request,0,2) eq 'MS' 
		  && substr($request,7,1) eq $quickSelect ) {  #check to see if the element is an input for the main QS
			$subEvent = substr($buf,2);  # go store the input
#			$self->disconnect;
			$classPlugin->handleInputQuery($client, $subEvent, 1);	
		}
	} elsif ($request =~ m/ZMOFF\r/ || $request =~ m/Z\d\OFF\r/ ) { #standby
		$log->debug("Disconnect socket after Standby"."\n");
		$self->disconnect;
	} elsif ($request =~ m/(MV|Z[2-4])\?/) {  # volume request
		if ($buf =~ m/(MV|Z[2-4])\d\d/) {	# see if the element is a volume
			$log->debug("Volume setting inquiry"."\n");
			$event = substr($buf,0,2);
			if ($event eq substr($request,0,2)) {   # make sure it's our volume
				$subEvent = substr($buf,2,3);
				# call the plugin routine to deal with the volume
#				clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
				$self->disconnect;		
				$classPlugin->updateSqueezeVol($client, $subEvent);	 
			}
		} elsif ( substr($buf,0,5) eq 'MVMAX' || substr($buf,0,2) eq 'CV') {  # in the weeds?
			&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
			$self->disconnect;
			$classPlugin->handleVolReq($client, 0);  # try again
		}
	} elsif ($request =~ m/MV/ || $request =~ m/Z\d\d\d/) {
		$log->debug("Process Volume Setting"."\n");
#		&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
		$self->disconnect;
	} elsif ($request =~ m/MU\?/) {
		$log->debug("Mute status inquiry"."\n");
		$event = substr($buf,0,2);
		if ($event eq 'MU') { #check to see if the element is a muting status
			$subEvent = substr($buf,2,2);  # get the status
			if ($subEvent eq 'OF' || $subEvent eq 'ON') {
#				$self->disconnect;
				$classPlugin->handleMutingToggle($client, $subEvent);	
			}								
		}				
	} elsif ($request =~ m/MUO/) {
		$log->debug("Process Mute response"."\n");
		$self->disconnect;
	} elsif ($request =~ m/SI\?/) {
		$log->debug("AVR input inquiry"."\n");
		if ( substr($buf,0,2) eq 'SI') { #check to see if the element is an input
			$subEvent = substr($buf,2);  # get the input
			&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
			$self->disconnect;
			$gInputQueryInProgress{$client} = 0;
			$classPlugin->handleInputQuery($client, $subEvent, 0);	
		} elsif ( substr($buf,0,2) eq 'CV' || substr($buf,0,5) eq 'MVMAX'
				  || substr($buf,0,2) eq 'HD') {  #give up if we start getting random stuff
			&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
			$self->disconnect;
#			$classPlugin->handleInputQuery($client, $subEvent);	
			$classPlugin->retryInputSource($client);  # try it again later
		}				
	} elsif ($request =~ m/MS/ || $request =~ m/^PS/ || $request =~ m/CV/) {
		my @events = split(/\r/,$buf); #break string into array
		my $iFound = 0;
		foreach $event (@events) { # loop through the event array parts
			$log->debug("The value of the array element is: " . $event . "\n");			
			$command = substr($event,0,2);
			if ($request =~ m/MS/ && $command eq 'MS') { #check to see if the element is a surround mode
				my $sModes_ref;
				my $sModes;
				my $cprefs = $prefs->client($client);
				my $avp = $cprefs->get('pref_Avp');
				if ($avp == 0) {
					$sModes_ref = \@surroundModes_r;
				} else {
					$sModes_ref = \@surroundModes;
				}				
				$subEvent = substr($events[0],0,5);
				
				$i=0;
				foreach $sModes (@$sModes_ref) {
					$sSM = substr($sModes,0,5);
					if (($subEvent eq $sSM)
					  || (substr($events[0],3,2) eq "CH" && $sSM eq "MS7CH")) {
						# call the surround mode plugin routine to set the value
						$log->debug("Surround Mode is: " . $sModes . "\n");
						$classPlugin->updateSurroundMode($client, $i);
#						$self->disconnect;
						$iFound = 1;
						last;
					}
					$i++;
				} # foreach (@$sModes)
				&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
				$self->disconnect;
			} elsif ($request =~ m/CV/) { #check to see if the element is a CV mode
				if ($channels{$client,"POPULATED"} == 1 ) {
					$log->debug("Process Channel volume lookup");
					$classPlugin->updateChannels($client);
					$iFound = 1;
				} else {
					&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
				}
				$self->disconnect;
			} elsif ($request =~ m/^PS/ && $command eq 'PS') { #check to see if the element is a PS mode
				$subEvent = substr($events[0],0,6);
				if ( $subEvent eq 'PSROOM') { #room modes
					$i=0;
					foreach (@roomModes) {
						if ($roomModes[$i] eq $events[0]) {
							# call the room mode plugin routine to set the value
							$log->debug("Room Mode is: " . $roomModes[$i] . "\n");
							$classPlugin->updateRoomEq($client, $i);
							$iFound = 1;
							last;
						} # if
						$i++;
					} # foreach roomModes
				} elsif ( $subEvent eq 'PSMULT') { #mult eq modes
					$i=0;
					foreach (@multEqModes) {
						if ($multEqModes[$i] eq $events[0]) {
							# call the room mode plugin routine to set the value
							$log->debug("Mult Eq Mode is: " . $multEqModes[$i] . "\n");
							$classPlugin->updateRoomEq($client, $i);
							$iFound = 1;
							last;
						} # if
						$i++;
					} # foreach multEqModes
				} elsif ($subEvent eq 'PSDYNS') { # night mode
					$i=0;
					foreach (@nightModes) {
						if ($nightModes[$i] eq $events[0]) {
							# call the night mode plugin routine to set the value
							$log->debug("Night Mode is: " . $nightModes[$i] . "\n");
							$classPlugin->updateNM($client, $i);
							$iFound = 1;
							last;
						} # if
						$i++;
					} # foreach nightModes
				} elsif ($subEvent eq 'PSDYNV') { # night mode avr
					$i=0;
					foreach (@nightModes_avr) {
						if ($nightModes_avr[$i] eq $events[0]) {
							# call the night mode plugin routine to set the value
							$log->debug("Night Mode is: " . $nightModes_avr[$i] . "\n");
							$classPlugin->updateNM($client, $i);
							$iFound = 1;
							last;
						} # if
						$i++;
					} # foreach nightModes_avr
				} elsif ($subEvent eq 'PSDYN ') { # dynamic volume
					$i=0;
					foreach (@dynamicVolModes) {
						if ($dynamicVolModes[$i] eq $events[0]) {
							# call the dynamic vol mode plugin routine to set the value
							$log->debug("Dynamic Volume Mode is: " . $dynamicVolModes[$i] . "\n");
							$classPlugin->updateDynEq($client, $i);
							$iFound = 1;
							last;
						} # if
						$i++;
					} # foreach dynamicVolModes
				} elsif ($subEvent eq 'PSDYNE') { # dynamic equalizer for avr
					$i=0;
					foreach (@dynamicEqModes) {
						if ($dynamicEqModes[$i] eq $events[0]) {
							# call the dynamic vol mode plugin routine to set the value
							$log->debug("Dynamic Eq Mode is: " . $dynamicEqModes[$i] . "\n");
							$classPlugin->updateDynEq($client, $i);
							$iFound = 1;
							last;
						} # if
						$i++;
					} # foreach dynamicEqModes
				} elsif ($subEvent eq 'PSRSTR') { # restorer
					if ($gNewAvr{$client} == 0) {  # if it's not a newer model or we don't know yet
						$i=0;
						foreach (@restorerModes) {
							if ($restorerModes[$i] eq $events[0])  {
								# call the restorer mode plugin routine to set the value
								$log->debug("Restorer Mode is: " . $restorerModes[$i] . "\n");
								$classPlugin->updateRestorer($client, $i);
								$iFound = 1;
								last;
							} # if
							$i++;
						} # foreach restorerModes
					}
					if ($iFound == 0) {   # not found or newer model - try the new AVR restorer modes
						$i=0;
						foreach (@restorerModes_new) {
							if ($restorerModes_new[$i] eq $events[0])  {
								# call the restorer mode plugin routine to set the value
								$log->debug("Restorer Mode is: " . $restorerModes_new[$i] . "\n");
								$classPlugin->updateRestorer($client, $i);
								$iFound = 1;
								$gNewAvr{$client} = 1;  # this is a newer model AVR
								last;
							} # if
							$i++;
						} # foreach restorerModes_new
					} 
				} elsif ($subEvent eq 'PSREFL') { # reference level
					$i=0;
					foreach (@refLevelModes) {
						if ($refLevelModes[$i] eq $events[0])  {
							# call the refence level plugin routine to set the value
							$log->debug("Reference level is: " . $refLevelModes[$i] . "\n");
							$classPlugin->updateRefLevel($client, $i);
							$iFound = 1;
							last;
						} # if
						$i++;
					} # foreach refLevelModes
				} elsif ($subEvent eq 'PSSWR ') { #subwoofer power state
					$i=0;
					foreach (@sWPowerModes) {
						if ($sWPowerModes[$i] eq $events[0])  {
							# call the sw power plugin routine to set the value
							$log->debug("Subwoofer state is: " . $sWPowerModes[$i] . "\n");
							$classPlugin->updateSw($client, $i);
							$iFound = 1;
							last;
						} # if
						$i++;
					} # foreach sWPowerModes
				}
				&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
				$self->disconnect;
			}
			else { 
				&clearbuf($self->socket,1);   # TESTING123 - test to get rid of spurious buffer contents 
				$self->disconnect;  # disconnect if nothing makes sense
			}				
		} # foreach (@events)
		
		# now see if we should loop the AVP settings
		if ($gGetPSModes{$client} !=0 ) {
			if ($iFound == 1) {  #if found, get the next one else retry the request
				$gGetPSModes{$client}++;
			}
			LoopGetAvpSettings($client, $url);
		}
	} # if ($request =~ m/MS/ || $request =~ m/^PS/) 
} # _read

1;