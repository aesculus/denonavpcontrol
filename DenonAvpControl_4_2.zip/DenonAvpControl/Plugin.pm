#	DenonAvpControl
#
#	Author:	Chris Couper <chris(dot)c(dot)couper(at)gmail(dot)com>
#	Credit To: Felix Mueller <felix(dot)mueller(at)gwendesign(dot)com>
#	Credit To: Sam Yahres <syahres(at)gmail(dot)com>
#
#	Copyright (c) 2003-2008 GWENDESIGN, 2008-2021 Chris Couper
#	All rights reserved.
#
#	----------------------------------------------------------------------
#	Function:	Turn Denon AVP Amplifier on and off (works for TP and SB)
#	----------------------------------------------------------------------
#	Technical:	To turn the amplifier on, sends AVP net AVON.
#			To turn the amplifier off, sends AVP net AVOFF.
#			To set the % volume of the amplifier per the % of theSB
#
#	----------------------------------------------------------------------
#	Installation:
#			- Copy the complete directory into the 'Plugins' directory
#			- Restart SlimServer
#			- Enable DenonAvpControl in the Web GUI interface
#			- Set:AvpIP Address, On, Off and Quick Delays, Max Volume, Quickselect
#	----------------------------------------------------------------------
#	History:
#
#	2009/02/14 v1.0	- Initial version
#	2009/02/23 v1.1	- Added zones and synching volume of amp with Squeezebox
#	2009/07/25 v1.2	- Minor changes to discard callbacks from unwanted players
#	2009/09/01 v1.3	- Changed the player registration process
#	2009/09/01 v1.4	- Changed to support SBS 7.4
#	2009/12/01 v1.5 - Added menus to allow the user to change audio settings
#	2010/08/07 v1.6 - Accomodate updates to AVP protocol and to use digital passthrough on iPeng
#	2010/08/15 v1.7 - Update to support .5 db steps in volume
#	2012/01/28 v1.8 - fixed error in maxVol fetch
#	2012/01/30 v1.9 - QuickSelect Issues, removed dead code, strings.txt update
#	2012/01/30 v1.9.1 - Supports multiple plugin instances, better comms handling, reference levels
#   2019/08/21 v1.9.2 - Moved to LMS, new zone 4 support
#	2020/05/14 v2.0 - Added quick selection delay for use during startup.  
#   2021/02/24 v2.1 - Retracted.
#   2021/02/24 v2.2 - Bug fixes.
#   2021/02/25 v2.3 - Install fix.
#   2021/03/15 v3.0 - Bug fixes, volume improvements
#   2021/04/03 v4.0	- Quick Select support for all zones, mute feature, new icons, bug fixes, new apps support
#   2021/05/27 v4.1	- Improved support for menu features, choice indicator for Denon AVP, Quick Select on double pause,
#					  Handle incremental volume change after mute to compensate for LMS (mis)behavior, 
#					  Allow volume synching in all zones, Support for switching between fixed and variable player output levels
#   2021/06/30 V4.2 - Surround speaker setting, channel level menus, SW on/off menu, bug fixes, clean up switching between fixed
#					  and variable output, skip powering off Denon if input source changed since power on, support changing the
#					  preamp volume level via the AVx menu when running with variable output.
#					  
#	----------------------------------------------------------------------
#
#	This program is free software; you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation; either version 2 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program; if not, write to the Free Software
#	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
#	02111-1307 USA
#
package Plugins::DenonAvpControl::Plugin;
use strict;
use base qw(Slim::Plugin::Base);

use Slim::Utils::Strings qw(string);
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Misc;

use File::Spec::Functions qw(:ALL);
use FindBin qw($Bin);

use Plugins::DenonAvpControl::DenonAvpComms;
use Plugins::DenonAvpControl::Settings;


use Data::Dumper; #used to debug array contents

# ----------------------------------------------------------------------------
# Global variables
# ----------------------------------------------------------------------------
my $surroundMode = -1;# Denon Surround Mode Index
my $roomEq = -1;		# Denon Room Equalizer Index
my $dynamicEq = -1;	# Denon Dynamic Equalizer Index
my $nightMode = -1;	# Denon Night Mode Index
my $restorer = -1;	# Denon Restorer Index
my $refLevel = -1;	# Denon Ref Level Index
my $subwoofer = -1;	# Denon subwoofer active
my $preLevel = -1;	# Denon preamp volume used for non fixed volume players
my $gMenuUpdate;	# Used to signal that no menu update should occur
my $getexternalvolumeinfoCoderef; #used to report use of external volume control

my %channels = ();
#my $gOrigVolCmdFuncRef;		# Original function reference in SC
my $gOrigPlayerPrefCmdFuncRef;  # Original function reference for playerpref command

# Per-client(player) persistent global variables
my %iOldPowerState;
my %iPowerOnInProgress;
my %iPowerOffInProgress;
my %avrInput;
my %outputLevelFixed;  # Used to indicate whether the player is using a fixed (100%) output level
my %gFixedVarToggleInProgress;  # Used in the pref callbacks to distinguish server from client requests
my %curVolume;  # Used to prevent unnecessary volume change commands
my %muteSwitch; # Used to detect vol up/down muting request
my %iInitialAvpVol;  # Used to restore AVR volume to initial QS or amp default volume
# ----------------------------------------------------------------------------
# References to other classes
# my $classPlugin = undef;

# ----------------------------------------------------------------------------
my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.denonavpcontrol',
	'defaultLevel' => 'ERROR',
	'description'  => 'PLUGIN_DENONAVPCONTROL_MODULE_NAME',
});

# ----------------------------------------------------------------------------
my $prefs = preferences('plugin.denonavpcontrol');

# ----------------------------------------------------------------------------
sub initPlugin {
	my $classPlugin = shift;

	# Not Calling our parent class prevents adds it to the player UI for the audio options
	 $classPlugin->SUPER::initPlugin();

	# Initialize settings classes
	my $classSettings = Plugins::DenonAvpControl::Settings->new( $classPlugin);

	# Install callback to get client setup
	Slim::Control::Request::subscribe( \&newPlayerCheck, [['client']],[['new']]);

	# init the DenonAvpComms plugin
	Plugins::DenonAvpControl::DenonAvpComms->new( $classPlugin);
	
	# Display the plugin version in the log file
	my $xmlname = catdir(Slim::Utils::PluginManager->allPlugins->{'DenonAvpControl'}->{'basedir'}, 'install.xml');
	my $xml = new XML::Simple;
	my $data = $xml->XMLin($xmlname);

#	$log->debug( "*** DenonAvpControl: install.xml\n" . Dumper($data) . "\n");
	$log->debug( "*** DenonAvpControl: initPlugin: Version " . $data->{version} . "\n");

	# getexternalvolumeinfo
	$getexternalvolumeinfoCoderef = Slim::Control::Request::addDispatch(['getexternalvolumeinfo'],[0, 0, 0, \&getexternalvolumeinfoCLI]);
	$log->debug( "*** DenonAvpControl: getexternalvolumeinfoCoderef: " . $getexternalvolumeinfoCoderef . "\n");

	# register callback for playerpref changes
	$gOrigPlayerPrefCmdFuncRef = Slim::Control::Request::addDispatch(['playerpref', '_prefname', '_newvalue'], [1, 0, 1, \&playerPrefCommand]);
	$log->debug( "*** DenonAvpControl: playerPrefCommand callback registered.\n");
	
	# Register dispatch methods for Audio menu options
	$log->debug("Getting the menu requests". "\n");
	
	#        |requires Client
	#        |  |is a Query
	#        |  |  |has Tags
	#        |  |  |  |Function to call
	#        C  Q  T  F

	Slim::Control::Request::addDispatch(['avpTop'],[1, 1, 0, \&avpTop]);
	Slim::Control::Request::addDispatch(['avpSM'],[1, 1, 0, \&avpSM]);
	Slim::Control::Request::addDispatch(['avpRmEq'],[1, 1, 0, \&avpRmEq]);
	Slim::Control::Request::addDispatch(['avpDynEq'],[1, 1, 0, \&avpDynEq]);
	Slim::Control::Request::addDispatch(['avpNM'],[1, 1, 0, \&avpNM]);
	Slim::Control::Request::addDispatch(['avpRes'],[1, 1, 0, \&avpRes]);
	Slim::Control::Request::addDispatch(['avpRefLvl'],[1, 1, 0, \&avpRefLvl]);
	Slim::Control::Request::addDispatch(['avpSwState'],[1, 1, 0, \&avpSwState]);
	Slim::Control::Request::addDispatch(['avpChannels'],[1, 1, 0, \&avpChannels]);
	Slim::Control::Request::addDispatch(['avpLvl'],[1, 1, 0, \&avpLvl]);
	Slim::Control::Request::addDispatch(['avpSetSM', '_surroundMode', '_oldSurroundMode'],[1, 1, 0, \&avpSetSM]);
	Slim::Control::Request::addDispatch(['avpSetRmEq', '_roomEq', '_oldRoomEq'],[1, 1, 0, \&avpSetRmEq]);
	Slim::Control::Request::addDispatch(['avpSetDynEq', '_dynamicEq', '_oldDynamicEq'],[1, 1, 0, \&avpSetDynEq]);
	Slim::Control::Request::addDispatch(['avpSetNM', '_nightMode', '_oldNightMode'],[1, 1, 0, \&avpSetNM]);
	Slim::Control::Request::addDispatch(['avpSetRes', '_restorer', '_oldRestorer'],[1, 1, 0, \&avpSetRes]);
	Slim::Control::Request::addDispatch(['avpSetRefLvl', '_refLevel', '_oldRefLevel'],[1, 1, 0, \&avpSetRefLvl]);
	Slim::Control::Request::addDispatch(['avpSetSw', '_subwoofer', '_oldSubwoofer'],[1, 1, 0, \&avpSetSw]);
	Slim::Control::Request::addDispatch(['avpSetChannels', '_channel', '_level'],[1, 1, 0, \&avpSetChannels]);
#	Slim::Control::Request::addDispatch(['avpSetLvl', '_level', '_oldLevel'],[1, 1, 0, \&avpSetLvl]);
	Slim::Control::Request::addDispatch(['avpSetLvl', '_level'],[1, 1, 0, \&avpSetLvl]);
}

# ----------------------------------------------------------------------------
sub newPlayerCheck {
	my $request = shift;
	my $client = $request->client();

    if ( !defined($client) ) {
		$log->debug( "*** DenonAvpControl: NewPlayerCheck entered without a valid client. \n");
		return;
	}

	$log->debug( "*** DenonAvpControl: ".$client->name()." is: " . $client);

	# Do nothing if client is not a Receiver or Squeezebox
	if( !(($client->isa( "Slim::Player::Receiver")) || ($client->isa( "Slim::Player::Squeezebox2")))) {
		$log->debug( "*** DenonAvpControl: Not a receiver or a squeezebox b \n");
		#now clear callback for those clients that are not part of the plugin
		clearCallback();
		return;
	}

	#init the client
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $quickSelect = $cprefs->get('quickSelect');
	my $gZone = $cprefs->get('zone');
	my $gSpeakers = $cprefs->get('speakers');
	my $pluginEnabled = $cprefs->get('pref_Enabled');
	my $audioEnabled = $cprefs->get('pref_AudioMenu');

	# Do nothing if plugin is disabled for this client
	if ( !defined( $pluginEnabled) || $pluginEnabled == 0) {
		$log->debug( "*** DenonAvpControl: Plugin Not Enabled for: ".$client->name()."\n");
		#now clear callback for those clients that are not part of the plugin
		clearCallback();
		return;
	} else {
		$log->debug( "*** DenonAvpControl: Plugin Enabled: \n");
		$log->debug( "*** DenonAvpControl: Quick Select: " . $quickSelect . "\n");
		$log->debug( "*** DenonAvpControl: zone: " . $gZone . "\n");
		$log->debug( "*** DenonAvpControl: speakers: " . $gSpeakers . "\n");
		$log->debug( "*** DenonAvpControl: IP Address: " . $avpIPAddress . "\n");
		
		$avrInput{$client} = "";		
		$outputLevelFixed{$client} = !preferences('server')->client($client)->get('digitalVolumeControl');  # initialize fixed output level flag
		my $forv = $outputLevelFixed{$client} ? 'Fixed' : 'Variable';
		$log->debug("*** DenonAvpControl: Player output level is: " . $forv . "\n");	
		$log->debug("*** DenonAvpControl: Player model is: " . $client->modelName() . "\n");
		
		$gFixedVarToggleInProgress{$client} = 0; 
		$curVolume{$client} = -1; 
		$muteSwitch{$client} = ' ';

		# Install callbacks to get client state changes
		Slim::Control::Request::subscribe( \&commandCallback, [['power', 'play', 'playlist', 'pause', 'client', 'mixer']], $client);
		Slim::Control::Request::subscribe( \&prefSetCallback, [['prefset']], $client);
		
#		$log->debug( "*** DenonAvpControl: client data: " . Dumper($client) . "\n");

#		$log->debug("*** DenonAvpControl: Getting max volume.\n");
#		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpChannelLevels($client, $avpIPAddress);
			
		#player menu
		if ($audioEnabled == 1 && $gZone==0) {
			$log->debug("Calling the plugin menu register". "\n");
			# Create SP menu under audio settings	
			my $icon = 'plugins/DenonAvpControl/html/images/denon_control.png';
			my @menu = ({
				stringToken   => getDisplayName(),
				id     => 'pluginDenonAvpControl',
				menuIcon => $icon,
				weight => 9,
				actions => {
					go => {
						player => 0,
						cmd	 => [ 'avpTop' ],
					}
				}
			});
			my @menu2 = ({
				stringToken   => getDisplayName(),
				id     => 'pluginDenonAvpControl_a',
				"icon" => $icon,
				weight => 9,
				actions => {
					go => {
						player => 0,
						cmd	 => [ 'avpTop' ],
					}
				}
			});
			Slim::Control::Jive::registerPluginMenu(\@menu, 'settingsPlayer' ,$client);	
			Slim::Control::Jive::registerPluginMenu(\@menu2, 'settings' ,$client);
		};
	}	
}

# ----------------------------------------------------------------------------
sub getDisplayName {
#	return 'PLUGIN_DENONAVPCONTROL_MODULE_NAME';
	return 'PLUGIN_DENONAVPCONTROL';
}

# ----------------------------------------------------------------------------
sub shutdownPlugin {
	Slim::Control::Request::unsubscribe(\&newPlayerCheck);
	clearCallback();
}

# ----------------------------------------------------------------------------
sub clearCallback {

	$log->debug( "*** DenonAvpControl:Clearing command callback" . "\n");
	Slim::Control::Request::unsubscribe(\&commandCallback);
	Slim::Control::Request::unsubscribe(\&prefSetCallback);

	# Give up rerouting
}

# ----------------------------------------------------------------------------
# Handlers for player based menu integration
# ----------------------------------------------------------------------------

# Generates the top menus as elements of the Player Audio menu
sub avpTop {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	
	my $pluginEnabled = $cprefs->get('pref_Enabled');
	my $iPower = $client->power();
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $avp = $cprefs->get('pref_Avp');

	# Do nothing if plugin is disabled for this client or the power is off
	if ( !defined( $pluginEnabled) || $pluginEnabled == 0 || $iPower == 0 || $iPowerOnInProgress{$client} ) {
		$log->debug( "Plugin Not Enabled for menu: \n");
		return;
	}
	
	$gMenuUpdate = 0; #suspend updating menus from avp
	$log->debug("Adding the menu elements to the audio menu". "\n");
	if ($avp) {
		$log->debug( "Will use AVP menu commands. \n");
	} else {
		$log->debug( "Will use AVR menu commands \n");
	}
	my $surroundIcon = 'plugins/DenonAvpControl/html/images/surround_modes.png';
	my $roomEqIcon = 'plugins/DenonAvpControl/html/images/room_eq.png';
	my $dynamicEqIcon = 'plugins/DenonAvpControl/html/images/dynamic_sound.png';
	my $dynamicVolIcon = 'plugins/DenonAvpControl/html/images/dynamic_vol.png';
	my $restorerIcon = 'plugins/DenonAvpControl/html/images/restorer.png';
	my $refIcon = 'plugins/DenonAvpControl/html/images/sliders_sm.png';
	my $chnIcon = 'plugins/DenonAvpControl/html/images/channel.png';
	my $swIcon = 'plugins/DenonAvpControl/html/images/subwoofer.png';
	my $volIcon = 'plugins/DenonAvpControl/html/images/volume.png';
	my @menu = ();
	if ($outputLevelFixed{$client} == 0) {
		push @menu,	{
				text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO0'),
				id      => 'preLevel',
				"icon" => $volIcon,
				actions  => {
					go  => {
						player => 0,
						cmd    => [ 'avpLvl' ],
						params	=> {
							menu => 'avpLvl',
						},
					},
				},
			};
	}
	push @menu,	{
			text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO1'),
			id      => 'surroundmode',
			"icon" => $surroundIcon,
			actions  => {
				go  => {
					player => 0,
					cmd    => [ 'avpSM' ],
					params	=> {
						menu => 'avpSM',
					},
				},
			},
		};
	push @menu,	{
			text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO2'),
			id      => 'roomequalizer',
			"icon" => $roomEqIcon,
			actions  => {
				go  => {
					player => 0,
					cmd    => [ 'avpRmEq' ],
					params	=> {
						menu => 'avpRmEq',
					},
				},
			},
		};
	push @menu,	{
			text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO3'),
			id      => 'dynamicequalizer',
			"icon" => $dynamicEqIcon ,
			actions  => {
				go  => {
					player => 0,
					cmd    => [ 'avpDynEq' ],
					params	=> {
						menu => 'avpDynEq',
					},
				},
			},
		};
	if ($avp == 1) {
		push @menu,	{
			text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO4'),
			id      => 'nightmode',
			"icon" => $dynamicVolIcon,
			actions  => {
				go  => {
					player => 0,
					cmd    => [ 'avpNM' ],
					params	=> {
						menu => 'avpNM',
					},
				},
			},
		};
	}
	push @menu,	{
			text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO5'),
			id      => 'restorer',
			"icon" => $restorerIcon,
			actions  => {
				go  => {
					player => 0,
					cmd    => [ 'avpRes' ],
					params	=> {
						menu => 'avpRes',
					},
				},
			},
		};
	push @menu,	{
			text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO6'),
			id      => 'reflevel',
			"icon" => $refIcon,
			actions  => {
				go  => {
					player => 0,
					cmd    => [ 'avpRefLvl' ],
					params	=> {
						menu => 'avpRefLvl',
					},
				},
			},
		};
#	push @menu,	{
#			text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO7'),
#			id      => 'subwoofer',
#			"icon" => $swIcon,
#			actions  => {
#				go  => {
#					player => 0,
#					cmd    => [ 'avpSwState' ],
#					params	=> {
#						menu => 'avpSwState',
#					},
#				},
#			},
#		};
	push @menu,	{
			text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO8'),
			id      => 'channels',
			"icon" => $chnIcon,
			actions  => {
				go  => {
					player => 0,
					cmd    => [ 'avpChannels' ],
					params	=> {
						menu => 'avpChannels',
					},
				},
			},
		};

	my $numitems = scalar(@menu);
	
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	$request->addResult("window", { "windowStyle" => "icon_list" });
	my $cnt = 0;
	for my $eachPreset (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachPreset);
		$cnt++;
	}
	
	$log->debug("done with main menu setup");
	$request->setStatusDone();
	
	# now check with the AVP to set the values of the modes
	Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress);
}


# Generates the Surround Mode menu, which is a list of all surround modes
sub avpSM {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	
	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate = 1; # update menus from avp

	$log->debug("The value of surroundMode is:" . $surroundMode . "\n");
	if ($avp == 0) {
		while ($i <13) { #set the radio to the first item as default
			if ($i == $surroundMode) {
				$check = 1;
			} else {
				$check = 0;
			};
			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_SURMDR'.($i+1)),
				radio => $check,
				actions  => {
					do  => {
						player => 0,
						cmd    => [ 'avpSetSM', $i , $surroundMode],
					},
				},
			};
					
			$i++;
		}
	} else {
		while ($i <15) { #set the radio to the first item as default
			if ($i == $surroundMode) {
				$check = 1;
			} else {
				$check = 0;
			};
			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_SURMD'.($i+1)),
				radio => $check,
				actions  => {
					do  => {
						player => 0,
						cmd    => [ 'avpSetSM', $i , $surroundMode],
					},
				},
			};
					
			$i++;
		}			
	}
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	$request->setStatusDone();
	# check if menu not initialized and call AVP to see what mode its in
	if ($surroundMode == -1) {
		# call the AVP to get mode
		Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "MS?");
	}
}

# Generates the Room equalizer menu
sub avpRmEq {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate = 1; # update menus from avp

	$log->debug("The value of roomEq is:" . $roomEq . "\n");

	if ($surroundMode < 2) {
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_DIRECT_MSG')
		}
	} else {
		while ($i < 5) {

			if ($i == $roomEq) {
				$check = 1;
			} else {
				$check = 0;
			};

			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_RMEQ'.($i + 1)),
				radio => $check,
				actions  => {
					do  => {
						player => 0,
						cmd    => [ 'avpSetRmEq', $i, $roomEq ],
					},
				},
			};
					
			$i++;
		}
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	$request->setStatusDone();
	# check if menu not initialized and call AVP to see what mode its in
	if ($roomEq == -1) {
		if ($avp == 0) {
			# call the AVR to get mode
			Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSMULTEQ: ?");
		} else {
			# call the AVP to get mode
			Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSROOM EQ: ?");
		}
	}
}

# Generates the Dynamic equalizer menu
sub avpDynEq {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate = 1; # update menus from avp
	
	$log->debug("The value of dynamicEq is:" . $dynamicEq . "\n");
	
	my $stop = 3;
	if ($avp == 0) {$stop = 2};
	if ($surroundMode < 2) {
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_DIRECT_MSG')
		}
	} else {
		while ($i <$stop) {

			if ($i == $dynamicEq) {
				$check = 1;
			} else {
				$check = 0;
			};

			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_DYNVOL'.($i + 1)),
				radio => $check,
				actions  => {
					do  => {
						player => 0,
						cmd    => [ 'avpSetDynEq', $i, $dynamicEq ],
					},
				},
			};
					
			$i++;
		}
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	$request->setStatusDone();
	# check if menu not initialized and call AVP to see what mode its in
	if ($dynamicEq == -1) {
		if ($avp == 0) {
			# call the AVR to get mode
			Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSDYNEQ ?");
		} else {
			# call the AVP to get mode
			Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSDYN ?");
		}
	}
}

# Generates the Night Mode menu
sub avpNM {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate = 1; # update menus from avp
	
	$log->debug("The value of nightMode is:" . $nightMode . "\n");
	
	if ($surroundMode < 2) {
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_DIRECT_MSG')
		}
	} else {
		if ($dynamicEq != 2) {
			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_NIGHT_MSG'),
			};
		};
		while ($i < 3) {
			if ($i == $nightMode) {
				$check = 1;
			} else {
				$check = 0;
			};
			if ($dynamicEq == 2) {
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_NIGHT'.($i + 1)),
					radio => $check,
					actions  => {
						do  => {
							player => 0,
							cmd    => [ 'avpSetNM', $i, $nightMode ],
						},
					},
				};
			} else {
				#no actions because no Vol set
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_NIGHT'.($i + 1)),
					radio => $check,
					actions  => {
					},
				};
			}				
			$i++;
		}
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();

	# check if menu not initialized and call AVP to see what mode its in
	if ($nightMode == -1) {
		if ($avp == 1) {
			# call the AVP to get mode
			Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSDYNSET ?");
		}
	}

}

# Generates the Restorer menu
sub avpRes {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate = 1; # update menus from avp

	$log->debug("The value of restorer is:" . $restorer . "\n");

	if ($surroundMode < 2) {
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_DIRECT_MSG')
		}
	} else {
		while ($i <4) {
			if ($i == $restorer) {
				$check = 1;
			} else {
				$check = 0;
			};
			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_REST'.($i + 1)),
				radio => $check,
			 actions  => {
			   do  => {
					player => 0,
					cmd    => [ 'avpSetRes' , $i, $restorer],
					params => {
					},
				},
			 },
			};
					
			$i++;
		}
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	$request->setStatusDone();

	# check if menu not initialized and call AVP to see what mode its in
	if ($restorer == -1) {
		# call the AVP to get mode
		Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSRSTR ?");
	}
}

# Generates the Reference Level menu
sub avpRefLvl {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate = 1; # update menus from avp
	
	$log->debug("The value of refLevel is:" . $refLevel . "\n");
	
	if ($surroundMode < 2) {
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_DIRECT_MSG')
		}
	} else {
		if ($dynamicEq == 0) { # not active when dynamic eq is off
			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_REF_LEVEL_MSG'),
			};
			while ($i <4) {
				if ($i == $refLevel) {
					$check = 1;
				} else {
					$check = 0;
				};
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_REF_LEVEL'.($i * 5)),
					radio => $check,
				};
						
				$i++;
			}
		} else {
			while ($i <4) {
				if ($i == $refLevel) {
					$check = 1;
				} else {
					$check = 0;
				};
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_REF_LEVEL'.($i * 5)),
					radio => $check,
					actions  => {
						do  => {
							player => 0,
							cmd    => [ 'avpSetRefLvl' , $i, $refLevel],
							params => {
							},
						},
					},
				};
						
				$i++;
			}
		}
	}

	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	$request->setStatusDone();

	# check if menu not initialized and call AVP to see what mode its in
	if ($refLevel == -1) {
		# call the AVP to get mode
		Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSREFLEV ?");
	}
}

# Generates the SW State menu
sub avpSwState {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate = 1; # update menus from amp
	
	$log->debug("The value of subwoofer is:" . $subwoofer . "\n");
	
	while ($i<2) {
		if ($i == $subwoofer) {
			$check = 1;
		} else {
			$check = 0;
		};
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_SW'.($i+1)),
			radio => $check,
			actions  => {
				do  => {
					player => 0,
					cmd    => [ 'avpSetSw', $i , $subwoofer],
				},
			},
		};
		$i++;
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	$request->setStatusDone();

	# check if menu not initialized and call AVP to see what mode its in
	if ($subwoofer == -1) {
		# call the AVP to get mode
		Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSSWR ?");
	}
}

#Generates the Preamp Level menu for non fixed volume players
sub avpLvl {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my @menu = ();

	my $level = int($preLevel);
	
	if ($level > 99) { #3 digits for .5 db numbers
		$level = int($level / 10);  #remove .5 db if present
	}
	
	my $max = 80 + $cprefs->get('maxVol');	# max volume user wants AVP to be set to
	
	$gMenuUpdate = 1; # update menus from amp	
	
	$log->debug("The value of preLevel is: " . $level . "\n");
	
	#determine if user is using db or 0-100 for volume settings  ????
	
	push @menu, {
		text => $client->string('PLUGIN_DENONAVPCONTROL_VOLUME') . " (0-" .$max. "):  [" .$level."]",
	};

	push @menu, {
		slider	=> 1,
		min 	=> 0,
		max		=> $max,
		label	=> 'Volume',
		#help    => 'help text',
		adjust 	=> 1,
		initial	=> $level,
		actions	=> {
			do  => {
				player => 0,
				cmd    => [ 'avpSetLvl' ],
				params => {
					valtag => 'value',
				},
			},
		},
	};
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();	
	
	# check if menu not initialized and call AVP to get the volume
	if ($preLevel == -1) {
		# call the AVP to get volume
		$log->debug("Calling SendNetAvpVolSetting...\n");		
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpVolSetting($client, $avpIPAddress, 0);
	}
}

#gets the channel level setting from the AVP value
sub getChannelLevel {
	my $avp_param = shift;
	my $avp_lvl = $channels{$avp_param} + 0;
	my $value = 0;

	if ($avp_lvl > 99) { #3 digits for .5 db numbers
		$value = int($avp_lvl / 10) - 50; #remove .5 db if present
	} else {
		$value = $avp_lvl - 50;
	}
	$value = sprintf("%+d", $value);
	return $value;
}

# Generates the Channels Level menu
sub avpChannels {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $speakers = $cprefs->get('speakers');
	my $avp = $cprefs->get('pref_Avp');
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	#$log->debug("Speakers are:" .$speakers . "\n");
	my @menu = ();
	my $parm;
	my $level = '0';
	
	$gMenuUpdate = 1; # update menus from amp
	
		$parm = 'CVFL';
		#$log->debug("The param is:" .$parm . "\n");
		$level = getChannelLevel($parm);
		#$log->debug("The value param is:" .$level . "\n");


		push @menu, {
		text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		};		
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			label	=> 'Left',
			#help    => 'help text',
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
		$parm = 'CVFR';
		$level = getChannelLevel($parm);
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		};
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			#text	=> 'Right',
			#help    => NO_HELP_STRING_YET,
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
		$parm = 'CVC';
		$level = getChannelLevel($parm);

		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		};
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			#text	=> 'Center',
			#help    => NO_HELP_STRING_YET,
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
		if ($avp) {
			$parm = 'CVSW1';		
		} else {
			$parm = 'CVSW';
		}
		$level = getChannelLevel($parm);
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		};
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
		
	if ($speakers > 0) {
		$parm = 'CVSL';
		$level = getChannelLevel($parm);
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		};
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
		$parm = 'CVSR';
		$level = getChannelLevel($parm);
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . " [".$level."dB]",
		};
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
	} #if ($speakers > 0)
	if ($speakers == 2) { #front height
		$parm = 'CVFHL';
		$level = getChannelLevel($parm);
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		};
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
		$parm = 'CVFHR';
		$level = getChannelLevel($parm);
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		};
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
	} elsif ($speakers == 3) { #front wide
		$parm = 'CVFWL';
		$level = getChannelLevel($parm);
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		};
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
		$parm = 'CVFWR';
		$level = getChannelLevel($parm);
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		};
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
	} elsif ($speakers == 4) { #back
		$parm = 'CVSBL';
		$level = getChannelLevel($parm);
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		};
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
		$parm = 'CVSBR';
		$level = getChannelLevel($parm);
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		};
		push @menu, {
			slider => 1,
			min 	=> -12 + 0,
			max		=> 12,
			adjust 	=> 1,
			initial	=> $level,
			actions	=> {
				do  => {
					player => 0,
					cmd    => [ 'avpSetChannels', $parm ],
					params => {
						valtag => 'value',
					},
				},
			},
		};
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();

}

# ----------------------------------------------------------------------------
# Callback to grab client playerpref changes
# ----------------------------------------------------------------------------
sub playerPrefCommand {
	my $request = shift;
	
	# Do nothing if request is not defined
	if(!defined( $request)) {
		$log->debug( "*** DenonAvpControl: playerPrefCommand() Request is not defined \n");
		return;
	}
	
	my $client = $request->client();
	
	# Do nothing if client is not defined
	if(!defined( $client)) {
		$log->debug( "*** DenonAvpControl: playerPrefCommand() Client is not defined \n");
		$request->setStatusBadDispatch();
		return;
	}
	
	my $prefName = $request->getParam('_prefname');
	
#	$log->debug( "*** DenonAvpControl: request: " . Dumper($request) . "\n");
	$log->debug( "*** DenonAvpControl: Player: " . $client->name() . ", Prefname: " . $prefName . "\n");

	if ( $client->power() && ($prefName eq "digitalVolumeControl") ) {
		my $tempLevelFixed = !($request->getParam('_newvalue'));
		if ($tempLevelFixed ne $outputLevelFixed{$client}) {
#			$outputLevelFixed{$client} = $tempLevelFixed;
			my $cprefs = $prefs->client($client);
			my $gZone = $cprefs->get('zone');
			my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
			if ( $tempLevelFixed ) {  # changing from variable to fixed, so mute AVR
				Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpMuteToggle($client, $avpIPAddress, $gZone, 1);  # mute the AVR	
			} 
			else {  # changing from fixed to variable, so unmute AVR if needed
				if ($curVolume{$client} <= 0) {
					Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpMuteToggle($client, $avpIPAddress, $gZone, 0);  # unmute the AVR	
#					Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpVol($client, $avpIPAddress, "UP", $gZone);
				}
			}	
			$gFixedVarToggleInProgress{$client} = 1;  # so we can finish this in prefSetCallback
		}
		# call original function after a delay
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + .5), \&playerPrefCmdFuncRef, $request);
	}
	else {
		&{$gOrigPlayerPrefCmdFuncRef}($request);  # call original function
	}
}	

# ----------------------------------------------------------------------------
# Call original playerPref function
# ----------------------------------------------------------------------------
sub playerPrefCmdFuncRef {
	my $client = shift;
	my $request = shift;
	
	&{$gOrigPlayerPrefCmdFuncRef}($request);  # call original function
}

# ----------------------------------------------------------------------------
# Callback to get server prefset changes
# ----------------------------------------------------------------------------
sub prefSetCallback {
	my $request = shift;
	my $client = $request->client();
	
	# Do nothing if client is not defined
	if(!defined( $client)) {
		$log->debug( "*** DenonAvpControl: prefSetCallback() Client is not defined \n");
		return;
	}
		
	my $nameSpace = $request->getParam('_namespace');
	my $prefName = $request->getParam('_prefname');
	
#	$log->debug( "*** DenonAvpControl: request: " . Dumper($request) . "\n");
#	$log->debug( "*** DenonAvpControl: Player: " . $client->name() . ", NameSpace: " . $nameSpace . ", PrefName: " . $prefName . "\n");

	if ( !$client->power() ) {  # ignore if player is not on
		$log->debug( "*** DenonAvpControl: prefSetCallback() Player is powered off \n");
		return;
	}

	if ( ($nameSpace eq "server") && ($prefName eq "digitalVolumeControl") ) {
		my $tempLevelFixed = !($request->getParam('_newvalue'));
		if ($tempLevelFixed ne $outputLevelFixed{$client}) {
			$outputLevelFixed{$client} = $tempLevelFixed;
			my $forv = $tempLevelFixed ? 'Fixed' : 'Variable';
			$log->debug("*** DenonAvpControl: prefSetCallback() New player output level is: $forv \n");	
			my $cprefs = $prefs->client($client);
			my $gZone = $cprefs->get('zone');
			my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
			if ( $tempLevelFixed ) {  # changing from variable to fixed, so sync AVR preamp volume to client
				if (!$gFixedVarToggleInProgress{$client} ) {  # only need to do this if coming from server
					Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpMuteToggle($client, $avpIPAddress, $gZone, 1);  # mute the AVR
				}					
				$log->debug("*** DenonAvpControl: prefSetCallback() Syncing AVR and client volumes\n");	
				my $sbVolume = calculateSBVolume($client, $iInitialAvpVol{$client});
				handleVolSet( $client, $sbVolume);  # set volume level to initial value
			}
			else {   # changing from fixed to variable, so unmute AVR if necessary and reset curVolume
				if (!$gFixedVarToggleInProgress{$client} ) {  # only need to do this if coming from server
					if ($curVolume{$client} <= 0) {
						Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpMuteToggle($client, $avpIPAddress, $gZone, 0);  # unmute the AVR	
					}
				}
				if ($gZone == 0) {  # set preamp volume for audio menu
					$preLevel = abs($curVolume{$client});
				}					
				$curVolume{$client} = 0; 
			}
			$gFixedVarToggleInProgress{$client} = 0;
#			avpTop();  #regenerate menu 	
		}
	}
}	

# ----------------------------------------------------------------------------
# Callback to get client state changes
# ----------------------------------------------------------------------------
sub commandCallback {
	my $request = shift;
	
	$log->debug( "*** DenonAvpControl: commandCallback() p0: " . $request->{'_request'}[0] . "\n");
	$log->debug( "*** DenonAvpControl: commandCallback() p1: " . $request->{'_request'}[1] . "\n");

	my $client = $request->client();
	
	# Do nothing if client is not defined
	if(!defined( $client)) {
		$log->debug( "*** DenonAvpControl: commandCallback() Client is not defined \n");
		return;
	}
	
	my $cprefs = $prefs->client($client);
	my $gZone = $cprefs->get('zone');
	my $DenonVol;		# Denon Volume setting
	my $quickSelect = $cprefs->get('quickSelect');
	my $timersRemoved;

	my $gPowerOnDelay = $cprefs->get('delayOn');	# Delay to turn on amplifier after player has been turned on (in seconds)
	my $gPowerOffDelay = $cprefs->get('delayOff');	# Delay to turn off amplifier after player has been turned off (in seconds)
	my $volumeSynch = $cprefs->get('pref_VolSynch');
	my $iPower = $client->power();

 	$log->debug( "*** DenonAvpControl: commandCallback() Player: " . $client->name() . "\n");
	
	# Get power on and off commands
	# Sometimes we do get only a power command, sometimes only a play/pause command and sometimes both
	if ( $request->isCommand([['power']])
	 || $request->isCommand([['play']])
	 || $request->isCommand([['pause']])
	 || $request->isCommand([['playlist'], ['newsong']]) ) {
		$log->debug("*** DenonAvpControl: power request1: $request \n");
		
		# Check with last known power state -> if different switch modes
		if ( $iOldPowerState{$client} ne $iPower) {

			$iOldPowerState{$client} = $iPower;
			$log->debug("*** DenonAvpControl: commandCallback() Power: $iPower \n");

			if( $iPower == 1) {
				# If player is turned on within delay, kill delayed power off timer
				Slim::Utils::Timers::killTimers( $client, \&handlePowerOff); 

				$iPowerOnInProgress{$client} = 1;
				$iPowerOffInProgress{$client} = 0;
				$iInitialAvpVol{$client} = 25;

				# Set timer to power on amplifier after a delay
				if ( $gPowerOnDelay == 0 ) {
					$gPowerOnDelay = 1;
				}

				# Delay minimum of 3 seconds for commands other than power on
				if ( !$request->isCommand([['power']]) && $gPowerOnDelay < 3) {
					$gPowerOnDelay = 3;
				}
				
				# Check to see if player is set to fixed or variable output level
				$outputLevelFixed{$client} = !preferences('server')->client($client)->get('digitalVolumeControl');
				my $forv = $outputLevelFixed{$client} ? 'Fixed' : 'Variable';
				$log->debug("*** DenonAvpControl: commandCallback() Player output level is: $forv \n");

				if ( $gZone == 0) {    # Check status for main zone only
					Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $gPowerOnDelay), \&handlePowerStatus); 
				} else {
					Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $gPowerOnDelay), \&handleSendPowerOn); 
				}				
			} else {
				# If player is turned off within delay, kill delayed power on timer
				if ( $gZone == 0) {
					Slim::Utils::Timers::killTimers( $client, \&handlePowerStatus); 
				} else {
					Slim::Utils::Timers::killTimers( $client, \&handleSendPowerOn); 
				}
				
				# Set timer to power off amplifier after a delay
				if ( $gPowerOffDelay == 0 ) {
					$gPowerOffDelay = 1;
				}
				if ( $iPowerOnInProgress{$client}) {
					$gPowerOffDelay += 10;  # allow time for power on to finish
				}
				Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $gPowerOffDelay), \&handlePowerOff); 
			}
		} elsif ( $iPower == 1 && !($iPowerOnInProgress{$client})) {     
		  	if ( $request->isCommand([['playlist'], ['newsong']]) && $outputLevelFixed{$client} && $volumeSynch ) { 
				# Kill outstanding volume requests
				Slim::Utils::Timers::killTimers( $client, \&handleVolumeRequest); 
				Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 1), \&handleVolumeRequest);
			} elsif ( $request->isCommand([['pause']]) && $quickSelect != 0 ) {   # check for 2 pauses in .5 secs for Quick Select
				# kill any dummy pauses that may be going on within the timer
				$timersRemoved = Slim::Utils::Timers::killTimers( $client, \&handleDummyPause);
				if ( $timersRemoved ) {
					$iPowerOnInProgress{$client} = 1;  # block other commands until QS completes
					$iInitialAvpVol{$client} = 25;
					$avrInput{$client} = "" ;
					$log->debug("*** DenonAvpControl: Dummy pause timers killed: $timersRemoved \n");
					Slim::Utils::Timers::killTimers( $client, \&handleQuickSelect); 
					Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 1), \&handleQuickSelect, 2);
				} else {
					# delay the dummy pause by .5 second to check for Quick Select
					Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + .5), \&handleDummyPause);
				}
			}				
		}
	# Get clients volume adjustment
	} elsif ( $request->isCommand([['mixer'], ['volume']]) && $outputLevelFixed{$client} ) {
		#check to make sure this is not us making the request first
		my $selfInitiated = $request->getResult('denonavpcontrolInitiated');
		if ( !$selfInitiated && $iPower == 1 && !($iPowerOnInProgress{$client})) {
			my $volAdjust = $request->getParam('_newvalue');

			$log->debug("*** DenonAvpControl:new SB vol: $volAdjust  \n");
			
			my $char1 = substr($volAdjust,0,1);
			
			#if it's an incremental adjustment, get the new volume from the client
			if (($char1 eq '-') || ($char1 eq '+')) {
				if ($curVolume{$client} < 0) {
					$volAdjust += abs($curVolume{$client});  # compensate for LMS setting volume to 0 after mute
					my $request = $client->execute([('mixer', 'volume', $volAdjust)]);
					# Add a result so we can detect our own volume adjustments, to prevent a feedback loop
					$request->addResult('denonavpcontrolInitiated', 1);
				}
				else {
					$volAdjust = $client->volume(); 
				}
				$log->debug("*** DenonAvpControl:current SB volume: $volAdjust  \n");
				if ($muteSwitch{$client} eq ' ') {
					$muteSwitch{$client} = $char1;  # first vol up/down
				} elsif ($muteSwitch{$client} ne $char1) {   # possible mute request
					$muteSwitch{$client} = 'm';
				}
			}
			else {  
				$muteSwitch{$client} = ' ';
				
				# special case to catch SB Touch firmware bug that sets vol to 100 when output level is fixed
				if ( ($client->modelName() eq 'Squeezebox Touch') && $volAdjust == 100) {
					$log->debug("*** DenonAvpControl:SB Touch volume set to 100%: changing to initial value  \n");
					my $sbVolume = calculateSBVolume($client, $iInitialAvpVol{$client});
					handleVolSet( $client, $sbVolume);  # set volume level to initial value
					return;
				}
			}

			$DenonVol = calculateAvrVolume($client, $volAdjust);
			
			# kill any volume changes that may be going on within the timer
			$timersRemoved = Slim::Utils::Timers::killTimers( $client, \&handleVolChanges);

			if ($timersRemoved && $muteSwitch{$client} eq 'm') {   # mute was requested
				$log->debug("*** DenonAvpControl: Volume change timers killed: $timersRemoved \n");
				# Kill outstanding mute requests
				Slim::Utils::Timers::killTimers( $client, \&handleMutingToggle); 
				handleMutingToggle( $client );
			} else {
				# Kill outstanding mute requests
				Slim::Utils::Timers::killTimers( $client, \&handleMutingToggle); 
				# delay the volume changes by .5 second to give the AVP time to catch up
				Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + .5), \&handleVolChanges, $DenonVol);	
			}				
		}
	} elsif ( $request->isCommand([['mixer'], ['muting']]) && $outputLevelFixed{$client}) {
		if ( $iPower == 1 && !($iPowerOnInProgress{$client}) ) {
			$log->debug("*** DenonAvpControl: Muting toggle request: \n");
			# Kill outstanding mute requests
			Slim::Utils::Timers::killTimers( $client, \&handleMutingToggle); 
			# kill any volume changes that may be going on within the timer
			$timersRemoved = Slim::Utils::Timers::killTimers( $client, \&handleVolChanges);
			# delay the muting toggle by a second to give the SB time to catch up
			Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + .5), \&handleMutingToggle );
		}
	}		
}

# ----------------------------------------------------------------------------
sub calculateAvrVolume {
	my $client = shift;
	my $volAdjust = shift;
	my $cprefs = $prefs->client($client);
	my $gZone = $cprefs->get('zone');
	my $DenonVol;
	
	$volAdjust = abs($volAdjust);  # safety valve
	my $maxVolume = $cprefs->get('maxVol');	# max volume user wants AVP to be set to
	$log->debug("*** DenonAvpControl: Max AVR volume: $maxVolume \n");
	my $subVol = sprintf("%3d",(80 + $maxVolume) * sqrt($volAdjust));
	$log->debug("*** DenonAvpControl: Raw subVol: $subVol \n");
	$log->debug("*** DenonAvpControl: MaxVol: $channels{'MVMAX'} \n");
	my $width = 2;
	if ( $gZone == 0 ) {  # 0.5dB increments only supported for main zone
		my $digit = int(substr($subVol,2,1));
		$subVol = int(($subVol+2)/10);  #round up for values of .8 and .9
		if (($digit>2) && ($digit<8)) {
			$subVol = $subVol*10 + 5;
			$width = 3;
		}
	} else {  # other zones
		$subVol = int(($subVol+5)/10);
	}
			
	$DenonVol = sprintf("%0*d",$width,$subVol); 			
	$log->debug("*** DenonAvpControl: Calc Vol: $DenonVol \n");
	
	return $DenonVol;
}

# ----------------------------------------------------------------------------
sub handleDummyPause {
	my $client = shift;
#	$log->debug("*** DenonAvpControl: handling Dummy Pause \n");
	my $timersRemoved = Slim::Utils::Timers::killTimers( $client, \&handleDummyPause);
}

# ----------------------------------------------------------------------------
sub handleMutingToggle {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $zone = $cprefs->get('zone');
	my $muteOnOff;

	my $sbVolume = $client->volume();  # see if client muting is currently on
	$log->debug("*** DenonAvpControl: Current SB volume: $sbVolume \n");
	
	if (($sbVolume <= 0) || ($muteSwitch{$client} eq 'm')) {  # need to mute
		$muteSwitch{$client} = ' ';
		$muteOnOff = 1;
		if ($sbVolume < 0 ) {
			$curVolume{$client} = $sbVolume;
		} else {
			$curVolume{$client} = 0;   #reset current volume
		}
	} else {   # need to unmute
		$muteOnOff = 0;
	}

	$log->debug("*** DenonAvpControl: handling Muting Toggle \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpMuteToggle($client, $avpIPAddress, $zone, $muteOnOff);
}

# ----------------------------------------------------------------------------
sub handleVolSet {
	my $client = shift;
	my $newVol = shift;
	
	$log->debug("*** DenonAvpControl: VolChange: $newVol \n");
	$client->execute([('mixer', 'volume', $newVol)]);
}

# ----------------------------------------------------------------------------
sub handleVolChanges {
	my $client = shift;
	my $DenonVol = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $zone = $cprefs->get('zone');

	my $timersRemoved = Slim::Utils::Timers::killTimers( $client, \&handleVolChanges);
#	$log->debug("*** DenonAvpControl: TESTING::: Volume change timers killed: $timersRemoved \n");

	$log->debug("*** DenonAvpControl: VolChange: $DenonVol \n");

	$muteSwitch{$client} = ' ';  # reset the mute switch

	if ($DenonVol != $curVolume{$client} ) {  # only send volume changes
		$curVolume{$client} = $DenonVol;
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpVol($client, $avpIPAddress, $DenonVol, $zone);
	}
}

# ----------------------------------------------------------------------------
sub handleSendPowerOn {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $zone = $cprefs->get('zone');
	
	$log->debug("*** DenonAvpControl: handling Send Power ON \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpOn($client, $avpIPAddress, $zone);
}

# ----------------------------------------------------------------------------
sub handlePowerOn {
	my $class = shift;
	my $client = shift;
	
	$log->debug("*** DenonAvpControl: handling Power ON \n");
	Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 1), \&handleSendPowerOn); 
}

# ----------------------------------------------------------------------------
sub handlePowerOn2 {
	my $class = shift;
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $quickSelect = $cprefs->get('quickSelect');
	my $gZone = $cprefs->get('zone');
	my $gQuickDelay = $cprefs->get('delayQuick');	# Delay to set Quick setting (in seconds)

	$log->debug("*** DenonAvpControl: handling Power ON 2\n");

	$avrInput{$client} = ""; 
	
	if ( $quickSelect != 0 ) {
		# only if quick select is turned on
		if ( $gQuickDelay < 2) {  #Denon doc says to wait at least a second after PWON
			$gQuickDelay = 2;
		}
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $gQuickDelay), \&handleQuickSelect, 5); 
#	} elsif ( $outputLevelFixed{$client} ) {
	} else {
		# no quick select so synch volumes
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 2), \&handleVolumeRequest); 
	}
}

# ----------------------------------------------------------------------------
sub handlePowerStatus {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $zone = $cprefs->get('zone');

	$log->debug("*** DenonAvpControl: handling Power ON Status \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpPowerStatus($client, $avpIPAddress, $zone);
}
# ----------------------------------------------------------------------------
sub handleVolumeRequest {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $gZone = $cprefs->get('zone');

	$log->debug( "*** DenonAvpControl: this vol player: " . $client . "\n");

	#now check with the AVP and get its current volume to set the SC volume
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpVolSetting($client, $avpIPAddress, $gZone);
	# /updateSqueezeVol will set the SB with the current amp setting	
}
# ----------------------------------------------------------------------------

sub handleVolReq {
	my $class = shift;
	my $client = shift;
	my $iDelay = 2;

	if ( $outputLevelFixed{$client} || $iPowerOnInProgress{$client}) {  # only if player is set to fixed output level (or power on)
		$log->debug( "*** DenonAvpControl: vol req from comms: " . $client . "\n");
		if ( $iPowerOnInProgress{$client} == 2 ) {  # this is a retry
			$iDelay = 0.5;
		}
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $iDelay), \&handleVolumeRequest ); 
		$iPowerOnInProgress{$client} = 2;  # indicates that we already waited 2 seconds after QS
	}
}

# ----------------------------------------------------------------------------
sub handlePowerOff {
	my $client = shift;
	my $force = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $zone = $cprefs->get('zone');
	
	if ( !$force && $zone == 0 && ( $avrInput{$client} ne "" || $iPowerOnInProgress{$client} ) ) {
		$log->debug("*** DenonAvpControl: handling main zone Power OFF, checking input source \n");
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpInputSource($client, $avpIPAddress, $zone);
	} else {
		$log->debug("*** DenonAvpControl: handling Power OFF \n");
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpStandBy($client, $avpIPAddress, $zone);
	}
	
	if ( !$force ) {
		$iPowerOnInProgress{$client} = 0;
		$iPowerOffInProgress{$client} = 1;
		$outputLevelFixed{$client} = 0;
	}
}

# ----------------------------------------------------------------------------
sub handleQuickSelect {
	my $client = shift;
	my $timeout = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $quickSelect = $cprefs->get('quickSelect');
	my $zone = $cprefs->get('zone');

	$log->debug("*** DenonAvpControl: handling quick select \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpQuickSelect($client, $avpIPAddress, $quickSelect, $zone, $timeout);
}

# ----------------------------------------------------------------------------
sub handleInputQuery {
	my $class = shift;
	my $client = shift;
	my $avrInput = shift;
	
	$log->debug("*** DenonAvpControl: handling input query response: " . $avrInput . "\n");
	
	if ( ($iPowerOffInProgress{$client}) ) {
		if ( $avrInput eq $avrInput{$client} ) {  # only power off if it's the same input we started with
			$log->debug("*** DenonAvpControl: handling main zone Power OFF \n");
			Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 1), \&handlePowerOff, 1 ); 
		} else {
			$log->debug("*** DenonAvpControl: input changed; skipping Power OFF\n");
		}
		$avrInput{$client} = "" ;
		$iPowerOffInProgress{$client} = 0;
	} else {
		$avrInput{$client} = $avrInput;  # store the input source
		$iPowerOnInProgress{$client} = 0; 

	}
}		

# ----------------------------------------------------------------------------
sub handleInputSource {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $zone = $cprefs->get('zone');
	my $onOff = $iPowerOffInProgress{$client} ? "OFF" : "ON / Quick Select";

	$log->debug("*** DenonAvpControl: handling main zone Power " . $onOff . ", checking input source \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpInputSource($client, $avpIPAddress, $zone);
#	$iPowerOnInProgress{$client} = 0; 
}
		
# ----------------------------------------------------------------------------
sub retryInputSource {  # called from comms error routine after failed 'SI' command
	my $class = shift;
	my $client = shift;
	
	$log->debug("*** DenonAvpControl: retrying failed input source query \n");
	Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 1), \&handleInputSource ); 
}
		
# ----------------------------------------------------------------------------
sub updateSqueezeVol { #used to sync SB vol with AVP
	my $class = shift;
	my $client = shift;
	my $avpVol = shift;
	my $cprefs = $prefs->client($client);
	my $zone = $cprefs->get('zone');

	$log->debug("*** DenonAvpControl: handling response to vol request \n");

	if ( $iPowerOnInProgress{$client} ) {  #store inital volume for use later
		$log->debug("*** DenonAvpControl: saving initial AVP volume value \n");	
		$iInitialAvpVol{$client} = int($avpVol);
	}
	
	if ( $iPowerOnInProgress{$client} && ($zone == 0) && $avrInput{$client} eq "" ) {  # store input source for main zone only during power on
		my $iDelay = 3;  # time to delay before checking input source
		if ( $iPowerOnInProgress{$client} == 2 ) {  # we already waited 2 secs after QS
			$iDelay = 1;
		}
		$log->debug("*** DenonAvpControl: setting timer to store AVR input \n");
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $iDelay), \&handleInputSource ); 
	} else {
		$iPowerOnInProgress{$client} = 0; 
	}
	
	if ( !$outputLevelFixed{$client} ) {   # only if player is set at variable output level
		if ($zone == 0) {  # only if main zone 
#			$iPowerOnInProgress{$client} = 0; 
			$preLevel = int($avpVol);
			$log->debug("*** DenonAvpControl: New preamp level is: " . $preLevel . "\n");
			if ($gMenuUpdate) {
				Slim::Control::Request::executeRequest( $client, [ 'avpLvl' ] ); 
			}
		}
		return;
	}

	$log->debug( "*** DenonAvpControl: The Client is: " . $client . "\n");
	$log->debug( "*** DenonAvpControl: avp vol: " . $avpVol . "\n");
	
	$curVolume{$client} = $avpVol;   # store current AVR volume

	my $volAdjust = calculateSBVolume($client, $avpVol);
				
	my $request = $client->execute([('mixer', 'volume', $volAdjust)]);
	# Add a result so we can detect our own volume adjustments, to prevent a feedback loop
	$request->addResult('denonavpcontrolInitiated', 1);
}

# ----------------------------------------------------------------------------
sub calculateSBVolume {  # convert AVR volume to SB value (0-100)
	my $client = shift;
	my $avpVol = shift;
	
	# change the AVR volume to the SB value
	my $maxVolume = $prefs->client($client)->get('maxVol');	# max volume user wants AVP to be set to
	$log->debug("*** DenonAvpControl: max volume: $maxVolume \n");
	if ( (length($avpVol) < 3) || (substr($avpVol,2,1) ne '5') ) {
		$avpVol = substr($avpVol,0,2) * 10;
	}
	
	my $volAdjust = sprintf("%d", (($avpVol / (80 + $maxVolume))**2) + 0.5);
	if ($volAdjust > 100) {
		$volAdjust = 100;
	}
	$log->debug("*** DenonAvpControl: New SB Vol for AVP: " . $volAdjust . "\n");
	
	return $volAdjust;
}

# ----------------------------------------------------------------------------
sub avpSetSM { # used to set the AVP surround mode
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);

	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	my $sMode = $request->getParam('_surroundMode'); #surround mode index
	my $sOldMode = $request->getParam('_oldSurroundMode'); #old surround mode index
	if ($sMode != $surroundMode) { #change the value
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpSurroundMode($client, $avpIPAddress, $sMode);
		$surroundMode = $ sMode;
	}
	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateSurroundMode { #used to sync Surround Mode with AVP
	my $class = shift;
	my $client = shift;
	$surroundMode = shift; #will auto pick avp or avr
#	my $request;

	$log->debug("*** DenonAvpControl: New SM is: " . $surroundMode. "\n");
	
	if ($gMenuUpdate) {
		Slim::Control::Request::executeRequest( $client, [ 'avpSM' ] ); 
	}
}


# ----------------------------------------------------------------------------
sub avpSetRmEq { # used to set the AVP room equalizer mode
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my $sMode = $request->getParam('_roomEq'); #Room eq index
	my $sOldMode = $request->getParam('_oldRoomEq'); #Room eq index
	$log->debug("sMode: $sMode \n");
	if ($sMode != $roomEq) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpRoomMode($client, $avpIPAddress, $sMode);
		$roomEq = $ sMode;
	}
	$log->debug("roomEq: $roomEq \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateRoomEq { #used to sync Room EQ with AVP
	my $class = shift;
	my $client = shift;
	$roomEq = shift;
	$log->debug("*** DenonAvpControl: New Room EQ is: " . $roomEq. "\n");

	if ($gMenuUpdate) {
		Slim::Control::Request::executeRequest( $client, [ 'avpRmEq' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetDynEq{ # used to set the AVP dynamic equalizer mode
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my $sMode = $request->getParam('_dynamicEq'); #dynamic equalizer mode
	my $sOldMode = $request->getParam('_oldDynamicEq'); # old dynamic equalizer mode
	$log->debug("sMode: $sMode \n");
	if ($sMode != $dynamicEq) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetDynamicEq($client, $avpIPAddress, $sMode);
		$dynamicEq = $sMode;
	}

	$log->debug("dynamicEq: $dynamicEq \n");

	$request->setStatusDone();

	# update the plugin menu
	$log->debug("Refreshing menus after DynEq setting");
	Slim::Control::Jive::refreshPluginMenus($client);
}

# ----------------------------------------------------------------------------
sub updateDynEq { #used to sync Dynamic EQ with AVP
	my $class = shift;
	my $client = shift;
	$dynamicEq = shift;
	$log->debug("*** DenonAvpControl: Dynamic EQ is: " . $dynamicEq. "\n");

	if ($gMenuUpdate) {
		Slim::Control::Request::executeRequest( $client, [ 'avpDynEq' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetNM { # used to set the AVP Night mode
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my $sMode = $request->getParam('_nightMode'); #night mode index
	my $sOldMode = $request->getParam('_oldNightMode'); # old night mode index
	if ($sMode != $nightMode) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpNightMode($client, $avpIPAddress, $sMode);
		$nightMode = $sMode;
	}
	$log->debug("nightMode: $nightMode \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateNM { #used to sync Night Mode with AVP
	my $class = shift;
	my $client = shift;
	$nightMode = shift;
	$log->debug("*** DenonAvpControl: Night Mode is: " . $nightMode. "\n");

	if ($gMenuUpdate) {
		Slim::Control::Request::executeRequest( $client, [ 'avpNM' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetRes { # used to set the AVP restorer mode
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my $sMode = $request->getParam('_restorer'); #restorer index
	my $sOldMode = $request->getParam('_oldRestorer'); # old restorer index
	if ($sMode != $restorer) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpRestorerMode($client, $avpIPAddress, $sMode);
		$restorer = $sMode;
	}

	$log->debug("restorer: $restorer \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateRestorer { #used to sync Restorer with AVP
	my $class = shift;
	my $client = shift;
	$restorer = shift;
	$log->debug("*** DenonAvpControl: Restorer Mode is: " . $restorer. "\n");

	if ($gMenuUpdate) {
		Slim::Control::Request::executeRequest( $client, [ 'avpRes' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetRefLvl { # used to set the AVP reference level mode
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my $sMode = $request->getParam('_refLevel'); #ref level index
	my $sOldMode = $request->getParam('_oldRefLevel'); # old ref level index
	if ($sMode != $refLevel) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetRefLevel($client, $avpIPAddress, $sMode);
		$refLevel = $sMode;
	}

	$log->debug("ref level: $refLevel \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateRefLevel { #used to sync reference level with AVP
	my $class = shift;
	my $client = shift;
	$refLevel = shift;
	$log->debug("*** DenonAvpControl: Reference Level is: " . $refLevel. "\n");

	if ($gMenuUpdate) {
		Slim::Control::Request::executeRequest( $client, [ 'avpRefLvl' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetSw { # used to set the AVP Subwoofer state
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my $sMode = $request->getParam('_subwoofer'); #Subwoofer index
	my $sOldMode = $request->getParam('_oldSubwoofer'); # old Subwoofer index
	if ($sMode != $subwoofer) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetSwState($client, $avpIPAddress, $sMode);
		$subwoofer = $sMode;
	}

	$log->debug("subwoofer: $subwoofer \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateSw { #used to sync SW state with AVP
	my $class = shift;
	my $client = shift;
	$subwoofer = shift;
	$log->debug("*** DenonAvpControl: Subwoofer state is: " . $subwoofer. "\n");

	if ($gMenuUpdate) {
		Slim::Control::Request::executeRequest( $client, [ 'avpSw' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetLvl { # used to set the AVP preamp level for variable mode
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";

	my $level = $request->getParam('_level'); # AVR volume
	
	$level =~ m/(-?\d+)/; #remove label
	$level = $1;
	
	$log->debug("*** DenonAvpControl: Preamp level change request: " . $preLevel . "->" . $level . "\n");
	
	if ( !$outputLevelFixed{$client} && ($level != $preLevel) ) {
		$preLevel = $level;			
		$level = sprintf("%0*d",2,$level); 			
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpVol($client, $avpIPAddress, $level, 0 );
	}

	$log->debug("preamp level: $preLevel \n");
	
	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub avpSetChannels { # used to set the AVP channels
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress') . ":23";
	
	my $channel = $request->getParam('_channel'); #the channel call
	my $level = $request->getParam('_level'); #channel level
	
	$log->debug("*** DenonAvpControl: Channel change: " . $channel. "->" . $level . "\n");

	Plugins::DenonAvpControl::DenonAvpComms::SendNetChannelLevel($client, $avpIPAddress, $channel, $level);
	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateChannels { #used to sync channels level with AVP
	my $class = shift;
	my $client = shift;
	
	my $hashRef = Plugins::DenonAvpControl::DenonAvpComms::getChannelsHash();
	
	%channels = %$hashRef;
	
	if ($gMenuUpdate) {
		Slim::Control::Request::executeRequest( $client, [ 'avpChannels' ] ); 
	}
}

# ----------------------------------------------------------------------------
# used to determine if connection used is digital
# We don't care if the user wants to use this in analog or non 100%
sub denonAvpInit {
	my $client = shift;
}

# ----------------------------------------------------------------------------
# determine if this player is using the DenonAvpControl plugin and its enabled
sub usingDenonAvpControl() {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $pluginEnabled = $cprefs->get('pref_Enabled');

	# cannot use DS if no digital out (as with Baby)
	if ( (!$client->hasDigitalOut()) || ($client->model() eq 'baby')) {
		return 0;
	}
 	if ($pluginEnabled == 1) {
		return 1;
	}
	return 0;
}

# ----------------------------------------------------------------------------
# external volume indication support code
# used by iPeng and other controllers
sub getexternalvolumeinfoCLI {
	my @args = @_;
	&reportOnOurPlayers();
	if ( defined($getexternalvolumeinfoCoderef) ) {
		# chain to the next implementation
		return &$getexternalvolumeinfoCoderef(@args);
	}
	# else we're authoritative
	my $request = $args[0];
	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub reportOnOurPlayers() {
	# loop through all currently attached players
	foreach my $client (Slim::Player::Client::clients()) {
		if (&usingDenonAvpControl($client) ) {
			# using our volume control, report on our capabilities
			$log->debug("Note that ".$client->name()." uses us for external volume control");
			Slim::Control::Request::notifyFromArray($client, ['getexternalvolumeinfo', 0,   1,   string(&getDisplayName())]);
#			Slim::Control::Request::notifyFromArray($client, ['getexternalvolumeinfo', 'relative:0', 'precise:1', 'plugin:DenonAvpControl']);
			# precise:1		can set exact volume
			# relative:1		can make relative volume changes
			# plugin:DenonSerial	this plugin's name
		}
	}
}
	
# --------------------------------------- external volume indication code -------------------------------
# end with something for plugin to do
1;
