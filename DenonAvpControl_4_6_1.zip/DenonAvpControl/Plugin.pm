#	DenonAvpControl
#
#	Author:	Chris Couper <chris(dot)c(dot)couper(at)gmail(dot)com>
#	Credit To: Felix Mueller <felix(dot)mueller(at)gwendesign(dot)com>
#	Credit To: Sam Yahres <syahres(at)gmail(dot)com>
#
#	Copyright (c) 2003-2008 GWENDESIGN, 2008-2021 Chris Couper
#	All rights reserved.
#
#	----------------------------------------------------------------------
#	Function:	Turn Denon AVP Amplifier on and off (works for TP and SB)
#	----------------------------------------------------------------------
#	Technical:	To turn the amplifier on, sends AVP net AVON.
#			To turn the amplifier off, sends AVP net AVOFF.
#			To set the % volume of the amplifier per the % of theSB
#
#	----------------------------------------------------------------------
#	Installation:
#			- Copy the complete directory into the 'Plugins' directory
#			- Restart SlimServer
#			- Enable DenonAvpControl in the Web GUI interface
#			- Set:AvpIP Address, On, Off and Quick Delays, Max Volume, Quickselect
#	----------------------------------------------------------------------
#	History:
#
#	2009/02/14 v1.0	- Initial version
#	2009/02/23 v1.1	- Added zones and synching volume of amp with Squeezebox
#	2009/07/25 v1.2	- Minor changes to discard callbacks from unwanted players
#	2009/09/01 v1.3	- Changed the player registration process
#	2009/09/01 v1.4	- Changed to support SBS 7.4
#	2009/12/01 v1.5 - Added menus to allow the user to change audio settings
#	2010/08/07 v1.6 - Accomodate updates to AVP protocol and to use digital passthrough on iPeng
#	2010/08/15 v1.7 - Update to support .5 db steps in volume
#	2012/01/28 v1.8 - fixed error in maxVol fetch
#	2012/01/30 v1.9 - QuickSelect Issues, removed dead code, strings.txt update
#	2012/01/30 v1.9.1 - Supports multiple plugin instances, better comms handling, reference levels
#   2019/08/21 v1.9.2 - Moved to LMS, new zone 4 support
#	2020/05/14 v2.0 - Added quick selection delay for use during startup.  
#   2021/02/24 v2.1 - Retracted.
#   2021/02/24 v2.2 - Bug fixes.
#   2021/02/25 v2.3 - Install fix.
#   2021/03/15 v3.0 - Bug fixes, volume improvements
#   2021/04/03 v4.0	- Quick Select support for all zones, mute feature, new icons, bug fixes, new apps support
#   2021/05/27 v4.1	- Improved support for menu features, choice indicator for Denon AVP, Quick Select on double pause,
#					  Handle incremental volume change after mute to compensate for LMS (mis)behavior, 
#					  Allow volume synching in all zones, Support for switching between fixed and variable player output levels
#   2021/06/30 V4.2 - Surround speaker setting, channel level menu (all zones), SW on/off menu, bug fixes, clean up switching between fixed
#					  and variable output, skip powering off Denon if input source changed since power on, support changing the
#					  preamp volume level via the AVx menu when running in variable output mode (all zones).
#   2021/09/14 V4.2.1 - Add sanity range check for channel level volumes and prevent timing problem in Comms when retrieving them
#   2021/10/17 V4.3	- Added new Quick Select function to audio menu and made changes to repopulate the menu each time a 
#					  Quick Select is done rather than waiting until the menu is invoked by the user. Add support for 
#					  Quick Select 4 and 5 in the plugin menu. Various bug fixes.
#   2021/12/01 V4.3.2 - Minor changes and a bug fix to the Quick Select audio menu function.
#					  Delay playback during power on until the AVR is completely powered on and ready.
#   2021/12/10 V4.3.3 - Fix a Windows-specific bug in DenonAvpComms.pm, introduced in V4.3.2.
#	2022/01/20 V4.4 - Add the ability in the Quick Select menu to save the current AVR audio settings to the Quick Select command
#					  defined for the active player. Add support for a syntax change in the PSRSTR command introduced in 
#					  the newer (X-series) AVR's. Prevent the player from setting the absolute volume to 100% when running with 
#					  volume fixed at 100% as a workaround for a bug in some implementations of the player firmware/software.
#	2022/02/07 V4.4.1 - Add the ability to specify an alternate port with the IP address in the menu for use with AVR's having
#					  only a serial port and using a network bridge such as ser2net. Added secondary zone support for updating the
#					  Quick Select definition and fixed some bugs in secondary zone initialization logic. Added a pop-up message
#					  to be displayed when the AVR audio settings menu is selected for a player which is either turned off or not
#					  finished initializing.
#	2022/04/02 V4.5 - Added full support for Marantz AVR's by supporting the Smart Select command. For now, this is done by selecting
#					  'Marantz AVR' in the 'AVP/AVR Type' plugin menu option. Added automatic AVR make/model detection via the 'SYMO'
#					  command. Extended the Quick Select audio settings menu to support updating any of the Quick Select definitions
#					  and not just the one being used by the current player. Display the AVR model, IP Address and Zone in the top
#					  level of the audio settings menu. Updated the plugin setup menu to indicate that both Denon and Marantz AVR's are
#					  supported.
#	2022/05/15 V4.5.1 - Change code to refresh the channel level table after each Quick Select, since the channel levels are saved
#					  separately for each AVR input and the input might change with the QS. Extend the recenty added feature that 
#					  bypasses powering off the AVR during "player off" if the AVR input is not the one associated with the player so 
#					  that it works for secondary zones as well. Add a timeout retry counter and exit command processing after ten (10)
#					  consecutive timeouts in case of the AVR going offline. Display the current Surround Mode at the top of the channel
#					  volume menu and don't show channels that aren't active for that mode, i.e. the center channel for "Stereo" mode.
#					  Use the "refresh" nextWindow attribute for slider menu controls so that the new values are immediately shown
#					  after an update.  Also "refresh" the menu after saving a Quick Select command definition so that the one that
#                     was saved continues to be selected. Various bug fixes and changes.
#	2022/06/01 V4.6 - Add a Source Input Select option to the Audio settings menu. Input sources may be changed on the fly and  
#					  the Channel Level table will be updated to reflect the levels associated with that input. Reorder the Audio
#					  settings menu to better group the submenus by function and frequency of use. When a new player registers with 
#					  the plugin and is already powered "on", power it off first in order to avoid later confusion as to its status.
#					  Last but by no means least, fix a longstanding bug whereby the newPlayerCheck() callback function was registered
#					  to receive all ['client'] requests instead of only ['client','new'] ones, resulting in some strange behavior.
#					  Also cleaned up a lot of loose ends in the code.
#	2022/07/11 V4.6.1 - Add an AVR Power On/Off control to the Audio settings menu and allow the menu to be used even when the LMS player
#					  is turned off. The AVR Power On button will bypass the Quick Select function and simply turn the AVR on, store the
#					  source input, sync the volume, and repopulate the Audio settings menu variables. Make changes to support Material Skin
#					  as a new menu client, including collaborating on a way to avoid loading the Audio Settings menu for non-plugin players 
#					  by inserting an array of player MAC addresses in the menu that the client can use to filter on. Prevent SqueezePlay 
#					  players from trying to handle the Audio Settings menu. Customize menu functionality based on client app capability.
#					  For example, don't create slider control menus (Preamp and Channel levels) for Squeeze Ctrl, which can't handle them.
#					  Smooth out the volume control by streamlining the calculations and fine-tuning the buffering of requests. 
#					  Restart playback from the beginning of the current song instead of the beginning of the playlist when powering on
#					  via a "Play" command. Various bug fixes.
					  
#	----------------------------------------------------------------------
#
#	This program is free software; you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation; either version 2 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program; if not, write to the Free Software
#	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
#	02111-1307 USA
#
package Plugins::DenonAvpControl::Plugin;
use strict;
use base qw(Slim::Plugin::Base);

use Slim::Utils::Strings qw(string);
use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::Misc;

use File::Spec::Functions qw(:ALL);
use FindBin qw($Bin);

use Plugins::DenonAvpControl::DenonAvpComms;
use Plugins::DenonAvpControl::Settings;


use Data::Dumper; #used to debug array contents

# ----------------------------------------------------------------------------
# Global variables
# ----------------------------------------------------------------------------
my $getexternalvolumeinfoCoderef; #used to report use of external volume control

#my $gOrigVolCmdFuncRef;		# Original function reference in SC
my $gOrigPlayerPrefCmdFuncRef;  # Original function reference for playerpref command

my %clientTable;  # Table of all clients, indexed by IP Addr, Zone, and QS

my $gPluginClients;  # Number of currently registered clients

# Per-client(player) persistent global variables
my %gIPAddress;
my %iPowerState;
my %iPowerOnInProgress;
my %iPowerOffInProgress;
my %iPaused; 		# indicates whether playback has been temporarily paused during power on
my %avrQSInput;		# AVR input associated with the player's defined Quick Select
my %curAvrSource;	# The current AVR input
my %outputLevelFixed;  # Used to indicate whether the player is using a fixed (100%) output level
my %gFixedVarToggleInProgress;  # Used in the pref callbacks to distinguish server from client requests
my %curVolume;  # Used to prevent unnecessary volume change commands
my %muteSwitch; # Used to detect vol up/down muting request
my %iInitialAvpVol; # Used to restore AVR volume to initial QS or amp default volume

# The following global hash variables are for use in the audio menu, hashed by client unless otherwise noted
my @clientIds = (); # Array of MAC addresses used by some client apps to filter players using the menu
my %gClientReg = (); # Hash table of flags indicating whether this MAC is registered
my %gModelInfo;  	# AVR make/model string returned from "SYMO" command, hashed by ipAddress
my %gInputTablePopulated;  # Used to indicate that an AVR input table has been populated, hashed by ipAddress
my %channels = ();	# Channel Volume table, hashed by client and channel
my %inputs = ();	# Internal input name array, hashed by ipAddress and index
my %inputIndex;		# Index to active input hash table entry for current client
my %surroundMode;	# Denon Surround Mode Index
my %roomEq;			# Denon Room Equalizer Index
my %dynamicEq;		# Denon Dynamic Equalizer Index
my %nightMode;		# Denon Night Mode Index
my %restorer;		# Denon Restorer Index
my %refLevel;		# Denon Ref Level Index
my %subwoofer;		# Denon subwoofer active
my %preLevel;		# Denon preamp volume used for non fixed volume players
my %qSelect;		# Denon Quick Select last used for this player
my %gAllowQSUpdate;	# Used to block multiple QS updates from one menu instance
my %gMenuUpdate;	# Used to signal that no menu update should occur
my %gMenuPopulated;	# Used to indicate whether the menu should be re-populated
my %gRefreshCVTable;# Used to indicate if the channel volume table should be refreshed

# ----------------------------------------------------------------------------
# References to other classes
# my $classPlugin = undef;

# ----------------------------------------------------------------------------
my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.denonavpcontrol',
	'defaultLevel' => 'ERROR',
	'description'  => 'PLUGIN_DENONAVPCONTROL_MODULE_NAME',
});

# ----------------------------------------------------------------------------
my $prefs = preferences('plugin.denonavpcontrol');

# ----------------------------------------------------------------------------
sub initPlugin {
	my $classPlugin = shift;

	# Not Calling our parent class prevents adds it to the player UI for the audio options
	 $classPlugin->SUPER::initPlugin();

	# Initialize settings classes
	my $classSettings = Plugins::DenonAvpControl::Settings->new( $classPlugin);

	# Install callback to get client setup
	Slim::Control::Request::subscribe( \&newPlayerCheck, [['client'],['new']]);

	# init the DenonAvpComms plugin
	Plugins::DenonAvpControl::DenonAvpComms->new( $classPlugin);
	
	# Display the plugin version in the log file
	my $xmlname = catdir(Slim::Utils::PluginManager->allPlugins->{'DenonAvpControl'}->{'basedir'}, 'install.xml');
	my $xml = new XML::Simple;
	my $data = $xml->XMLin($xmlname);

#	$log->debug( "*** DenonAvpControl: install.xml\n" . Dumper($data) . "\n");
	$log->debug( "*** DenonAvpControl: initPlugin: Version " . $data->{version} . "\n");

	# getexternalvolumeinfo
	$getexternalvolumeinfoCoderef = Slim::Control::Request::addDispatch(['getexternalvolumeinfo'],[0, 0, 0, \&getexternalvolumeinfoCLI]);
	$log->debug( "*** DenonAvpControl: getexternalvolumeinfoCoderef: " . $getexternalvolumeinfoCoderef . "\n");

	# register callback for playerpref changes
	$gOrigPlayerPrefCmdFuncRef = Slim::Control::Request::addDispatch(['playerpref', '_prefname', '_newvalue'], [1, 0, 1, \&playerPrefCommand]);
	$log->debug( "*** DenonAvpControl: playerPrefCommand callback registered.\n");

	$gPluginClients	= 0;  # init the number of active clients
	
	# Register dispatch methods for Audio menu options
	$log->debug("Getting the menu requests". "\n");
	
	#        |requires Client
	#        |  |is a Query
	#        |  |  |has Tags
	#        |  |  |  |Function to call
	#        C  Q  T  F

	Slim::Control::Request::addDispatch(['avpTop'],[1, 1, 0, \&avpTop]);
	Slim::Control::Request::addDispatch(['avpSM'],[1, 1, 0, \&avpSM]);
	Slim::Control::Request::addDispatch(['avpRmEq'],[1, 1, 0, \&avpRmEq]);
	Slim::Control::Request::addDispatch(['avpDynEq'],[1, 1, 0, \&avpDynEq]);
	Slim::Control::Request::addDispatch(['avpNM'],[1, 1, 0, \&avpNM]);
	Slim::Control::Request::addDispatch(['avpRes'],[1, 1, 0, \&avpRes]);
	Slim::Control::Request::addDispatch(['avpRefLvl'],[1, 1, 0, \&avpRefLvl]);
	Slim::Control::Request::addDispatch(['avpSwState'],[1, 1, 0, \&avpSwState]);
	Slim::Control::Request::addDispatch(['avpChannels'],[1, 1, 0, \&avpChannels]);
	Slim::Control::Request::addDispatch(['avpLvl'],[1, 1, 0, \&avpLvl]);
	Slim::Control::Request::addDispatch(['avpQuickSelect'],[1, 1, 0, \&avpQuickSelect]);
	Slim::Control::Request::addDispatch(['avpSourceSelect'],[1, 1, 0, \&avpSourceSelect]);
	Slim::Control::Request::addDispatch(['avpSetSM', '_surroundMode', '_oldSurroundMode'],[1, 1, 0, \&avpSetSM]);
	Slim::Control::Request::addDispatch(['avpSetRmEq', '_roomEq', '_oldRoomEq'],[1, 1, 0, \&avpSetRmEq]);
	Slim::Control::Request::addDispatch(['avpSetDynEq', '_dynamicEq', '_oldDynamicEq'],[1, 1, 0, \&avpSetDynEq]);
	Slim::Control::Request::addDispatch(['avpSetNM', '_nightMode', '_oldNightMode'],[1, 1, 0, \&avpSetNM]);
	Slim::Control::Request::addDispatch(['avpSetRes', '_restorer', '_oldRestorer'],[1, 1, 0, \&avpSetRes]);
	Slim::Control::Request::addDispatch(['avpSetRefLvl', '_refLevel', '_oldRefLevel'],[1, 1, 0, \&avpSetRefLvl]);
	Slim::Control::Request::addDispatch(['avpSetSw', '_subwoofer', '_oldSubwoofer'],[1, 1, 0, \&avpSetSw]);
	Slim::Control::Request::addDispatch(['avpSetChannels', '_channel', '_level'],[1, 1, 0, \&avpSetChannels]);
	Slim::Control::Request::addDispatch(['avpSetLvl', '_level'],[1, 1, 0, \&avpSetLvl]);
	Slim::Control::Request::addDispatch(['avpSetQuickSelect', '_quickSelect'],[1, 1, 0, \&avpSetQuickSelect]);
	Slim::Control::Request::addDispatch(['avpSaveQuickSelect', '_quickSelect'],[1, 1, 0, \&avpSaveQuickSelect]);
	Slim::Control::Request::addDispatch(['avpSetSource', '_source'],[1, 1, 0, \&avpSetSource]);
	Slim::Control::Request::addDispatch(['avpPowerToggle', '_onOff', '_menuPopulated'],[1, 1, 0, \&avpPowerToggle]);
#	Slim::Control::Request::addDispatch(['avpPowerOn'],[1, 1, 0, \&avpPowerOn]);
#	Slim::Control::Request::addDispatch(['avpPowerOff'],[1, 1, 0, \&avpPowerOff]);
}

# ----------------------------------------------------------------------------
sub newPlayerCheck {
	my $request = shift;
	my $client = $request->client();

    if ( !defined($client) ) {
		$log->debug( "*** DenonAvpControl: NewPlayerCheck entered without a valid client. \n");
#		$log->debug( "*** DenonAvpControl: request data: " . Dumper($request) . "\n");		
		return;
	}

	$log->debug( "*** DenonAvpControl: ".$client->name()." is: " . $client);

	# Do nothing if client is not a Receiver or Squeezebox
	if( !(($client->isa( "Slim::Player::Receiver")) || ($client->isa( "Slim::Player::Squeezebox2")))) {
		$log->debug( "*** DenonAvpControl: Not a receiver or a squeezebox b \n");
		#now clear callback for those clients that are not part of the plugin
		clearCallback();
		return;
	}

	#init the client
	my $cprefs = $prefs->client($client);
	my $pluginEnabled = $cprefs->get('pref_Enabled');

	# Do nothing if plugin is disabled for this client
	if ( !defined( $pluginEnabled) || $pluginEnabled == 0) {
		$log->debug( "*** DenonAvpControl: Plugin Not Enabled for: ".$client->name()."\n");
		#now clear callback for those clients that are not part of the plugin
		clearCallback();
		return;
	} else {
		my $avpIPAddress = "HTTP://" . $cprefs->get('avpAddress');
		if ( !($avpIPAddress =~ m/:\d+/) ) {  # only add the telnet port if one is not provided
			$avpIPAddress = $avpIPAddress . ":23";
		}
		
		my $quickSelect = $cprefs->get('quickSelect');
		my $gZone = $cprefs->get('zone');
		my $gSpeakers = $cprefs->get('speakers');
		my $audioEnabled = $cprefs->get('pref_AudioMenu');
		my $avrType = $cprefs->get('pref_Avp');
		my $clientid = $client->id;
		
		$log->debug( "*** DenonAvpControl: Plugin Enabled: \n");
		$log->debug( "*** DenonAvpControl: Quick Select: " . $quickSelect . "\n");
		$log->debug( "*** DenonAvpControl: Zone: " . $gZone . "\n");
		$log->debug( "*** DenonAvpControl: Speakers: " . $gSpeakers . "\n");
		$log->debug( "*** DenonAvpControl: Audio Menu Enabled: " . $audioEnabled . "\n");
		$log->debug( "*** DenonAvpControl: AVR Type: " . $avrType . "\n");
		$log->debug( "*** DenonAvpControl: IP Address: " . $avpIPAddress . "\n");
		$log->debug( "*** DenonAvpControl: MAC Address: " . $client->macaddress() . "\n");
		$log->debug( "*** DenonAvpControl: Client ID: " . $clientid . "\n");
		
		$avrQSInput{$client} = "";		
		$outputLevelFixed{$client} = !preferences('server')->client($client)->get('digitalVolumeControl');  # initialize fixed output level flag
		my $forv = $outputLevelFixed{$client} ? 'Fixed' : 'Variable';
		$log->debug("*** DenonAvpControl: Player output level is: " . $forv . "\n");	
		$log->debug("*** DenonAvpControl: Player model is: " . $client->modelName() . "\n");

		# initialize per-client global state variables
		$gIPAddress{$client} = $avpIPAddress;
		$gFixedVarToggleInProgress{$client} = 0; 
		$curVolume{$client} = -1; 
		$curAvrSource{$client} = "";
 		$muteSwitch{$client} = ' ';
		$iPowerOnInProgress{$client} = 0;
		$iPowerOffInProgress{$client} = 0;
		$iPowerState{$client} = -1;
		
		if ($client->power()) {    # turn the player off if currently on, to avoid confusion
			$iPowerState{$client} = 0;
			my $request = $client->execute([('power', 0)]);
		}
		
		# Install callbacks to get client state changes
		Slim::Control::Request::subscribe( \&commandCallback, [['power', 'play', 'playlist', 'pause', 'client', 'mixer']], $client);
		Slim::Control::Request::subscribe( \&prefSetCallback, [['prefset']], $client);
				
#		$log->debug( "*** DenonAvpControl: client data: " . Dumper($client) . "\n");

#		$log->debug("*** DenonAvpControl: Getting max volume.\n");
#		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpChannelLevels($client, $avpIPAddress, $gZone);
			
		#player menu
		if ($audioEnabled) {
			if (!$gClientReg{$clientid} ) {  # if this is a previously unregistered player
				$gClientReg{$clientid} = 1;
				push (@clientIds, $clientid);   # update the clientid array
				$log->debug("*** DenonAvpControl: added Client ID to clientid array\n");
				$log->debug("*** DenonAvpControl: Client ID table is: @clientIds \n");				
			}
			
			$log->debug("Calling the plugin menu register". "\n");
			# Create SP menu under audio settings	
			my $icon = 'plugins/DenonAvpControl/html/images/denon_control.png';
			my @menu = ({
#				stringToken   => getDisplayName(),
				stringToken   => $client->string('PLUGIN_DENONAVPCONTROL_MENU_HEADING'),
				id     => 'pluginDenonAvpControl',
				menuIcon => $icon,
				weight => 9,
				actions => {
					go => {
#						player => 0,
						player => \@clientIds,
						cmd	 => [ 'avpTop' ],
					}
				}
			});
			my @menu2 = ({
#				stringToken   => getDisplayName(),
				stringToken   => $client->string('PLUGIN_DENONAVPCONTROL_MENU_HEADING'),
				id     => 'pluginDenonAvpControl_a',
				"icon" => $icon,
				weight => 9,
				actions => {
					go => {
#						player => 0,
						player => \@clientIds,
						cmd	 => [ 'avpTop' ],
					}
				}
			});
			Slim::Control::Jive::registerPluginMenu(\@menu, 'settingsPlayer' , $client);	
			Slim::Control::Jive::registerPluginMenu(\@menu2, 'settings' , $client);
			
			# initialize per-client global menu variables
			$gMenuPopulated{$client} = 0;
			$preLevel{$client} = -1;
			$surroundMode{$client} = -1;
			$roomEq{$client} = -1;
			$dynamicEq{$client}	= -1;
			$nightMode{$client} = -1;
			$restorer{$client} = -1;
			$refLevel{$client} = -1;	
			$subwoofer{$client} = -1;				
			$qSelect{$client} = $quickSelect;
			$inputIndex{$client} = -1;
		}
		
		# get the model info from the AVR
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + (5 * $gPluginClients) + 0.5 ), \&getAvpModelInfo); 

		if ( !exists $clientTable{$avpIPAddress,$gZone,$quickSelect} ) {
			# add the client to the client table
			$clientTable{$avpIPAddress,$gZone,$quickSelect} = $client->name();
			$gPluginClients += 1;   #increment the number of registered clients
			$log->debug("Number of registered plugin players = " . $gPluginClients . "\n");	
		}
	}	
}

# ----------------------------------------------------------------------------
sub getDisplayName {
#	return 'PLUGIN_DENONAVPCONTROL_MODULE_NAME';
	return 'PLUGIN_DENONAVPCONTROL';
}

# ----------------------------------------------------------------------------
sub shutdownPlugin {
	Slim::Control::Request::unsubscribe(\&newPlayerCheck);
	clearCallback();
}

# ----------------------------------------------------------------------------
sub clearCallback {

	$log->debug( "*** DenonAvpControl:Clearing command callback" . "\n");
	Slim::Control::Request::unsubscribe(\&commandCallback);
	Slim::Control::Request::unsubscribe(\&prefSetCallback);

	# Give up rerouting
}

# ----------------------------------------------------------------------------
# Handlers for player based menu integration
# ----------------------------------------------------------------------------

# Generates the top menus as elements of the Player Audio menu
sub avpTop {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	
	my $pluginEnabled = $cprefs->get('pref_Enabled');
	my $audioEnabled = $cprefs->get('pref_AudioMenu');	
	
	my $iPower = $iPowerState{$client};
	my $clientApp = $client->controllerUA;

	my @menu = ();	
	my $avrIcon = 'plugins/DenonAvpControl/html/images/denon_control.png';

	# Display a menu message if the plugin or the settings menu is disabled for this client
	if ( !defined( $pluginEnabled) || $pluginEnabled == 0 || $audioEnabled == 0 || $clientApp =~ m/^SqueezePlay/ ) {
		$log->debug( "Plugin/menu Not Enabled: skipping menu for " . $client->name() . "\n");
#		my $message = $client->string('PLUGIN_DENONAVPCONTROL_MENU_NOT_ACTIVE'); 
#		$client->showBriefly( { 'jive' => { 'text' => [ $message ], } },{'duration' => 2, 'scroll' => 1, 'block' => 1 } );
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_MENU_NOT_ACTIVE'),
			"icon" => $avrIcon,
		};
		
		my $numitems = scalar(@menu);
		$request->addResult("count", $numitems);
		$request->addResult("offset", 0);
#		$request->addResult("window", { "windowStyle" => "icon_list" });
	
		my $cnt = 0;
		for my $eachPreset (@menu[0..$#menu]) {
			$request->setResultLoopHash('item_loop', $cnt, $eachPreset);
			$cnt++;
		}		
		$request->setStatusDone();
		return;
	}

	my $avpIPAddress = $gIPAddress{$client};
	my $gZone = $cprefs->get('zone');
	my $avp = $cprefs->get('pref_Avp');
	my $menuText = "";
	
	$gMenuUpdate{$client} = 0; #suspend updating menus from avp

	$log->debug("Adding the menu elements to the audio menu.\n" );
	$log->debug("Client UA string is: " . $clientApp );
	if ($avp == 1) {
		$log->debug( "Will use AVP menu commands. \n");
	} else {
		$log->debug( "Will use AVR menu commands. \n");
	}
	
	my $surroundIcon = 'plugins/DenonAvpControl/html/images/surround_modes.png';
	my $roomEqIcon = 'plugins/DenonAvpControl/html/images/room_eq.png';
	my $dynamicEqIcon = 'plugins/DenonAvpControl/html/images/dynamic_sound.png';
	my $dynamicVolIcon = 'plugins/DenonAvpControl/html/images/dynamic_vol.png';
	my $restorerIcon = 'plugins/DenonAvpControl/html/images/restorer.png';
	my $refIcon = 'plugins/DenonAvpControl/html/images/sliders_sm.png';
	my $chnIcon = 'plugins/DenonAvpControl/html/images/channel.png';
	my $swIcon = 'plugins/DenonAvpControl/html/images/subwoofer.png';
	my $volIcon = 'plugins/DenonAvpControl/html/images/volume.png';
	my $qsIcon = 'plugins/DenonAvpControl/html/images/subwoofer.png';
	my $sourceIcon = 'plugins/DenonAvpControl/html/images/select_source.png';
	
	my $showSettings = 1;

	if ( ($iPower != 1 || $iPowerOnInProgress{$client} ) && !$gMenuPopulated{$client} ) {
		$showSettings = 0;    # this is for future use if a limited menu is allowed while powered off
	}

	my $PwrOn = 1;
	if ( (!$showSettings || $curAvrSource{$client} eq "") && !$iPowerOnInProgress{$client} ) {
		$PwrOn = 0;
	}

	my $modelInfo = "Model: " . $gModelInfo{$avpIPAddress};  # Display the model name & region
	
	if ( !($clientApp =~ m/^Squeeze-Control/) ) { 
		$modelInfo .= "\n";
	} else {
		$modelInfo .= "  ";    # Put everything on one line for Squeeze Ctrl
	}

#	if ( !($client->controllerUA =~ m/^iPeng/) && $avpIPAddress =~ /HTTP:\/\/([\d|.]+):\d+/ ) {
	if ( 0 ) {  	# skip the IP address for now
		$modelInfo .= "IP Address: " . $1;
		if ( ($clientApp =~ m/^Squeezer/ ) ) { 
			$modelInfo .= "\n";
		} else {
			$modelInfo .= "  ";
		}	
	}
		
	$modelInfo .= "Zone: ";

	if ($gZone > 0) {
		$modelInfo .= ($gZone+1);
	} else {
		$modelInfo .= "Main";
	}

	my $iMenu = 0;
	if ($showSettings && ($curAvrSource{$client} ne "") ) {
		$iMenu = 1;
	}
	
	$modelInfo .= "   Power: ";
	
	if ($PwrOn == 0) {
		$modelInfo .= "OFF";
	} elsif ($iMenu == 0) {
		$modelInfo .= "INIT";
	} else {
		$modelInfo .= "ON";
	}
	
	if ( ($clientApp =~ m/^iPeng/ ) ) {  # use checkbox control for iPeng only
		push @menu,	{
				text => $modelInfo,
				id      => 'avpInfo',
				"icon" => $avrIcon,
				nextWindow => 'refresh',
				checkbox => $iMenu,
				actions  => {
					on  => {
						player => 0,
						cmd    => [ 'avpPowerToggle', 0, $iMenu ],
					},
					off  => {
						player => 0,
						cmd    => [ 'avpPowerToggle', 1, $iMenu ],
					},
				},
			};
	} else {   # use radio button for other clients
		push @menu,	{
				text => $modelInfo,
				id      => 'avpInfo',
				windowId   => 'avpInfo',
				"icon" => $avrIcon,#				nextWindow => 'parent',
				nextWindow => 'refresh',
				radio => $iMenu,
				actions  => {
					do  => {
						player => 0,
						cmd    => [ 'avpPowerToggle', $PwrOn, $iMenu ],
					},
				},
			};
	}
	
	if ($iMenu) {
		if ( !($clientApp =~ m/^Squeeze-Control/) ) {   # skip slider controls for Squeeze Ctrl client
			if ($outputLevelFixed{$client} == 0) {
				$menuText = $client->string('PLUGIN_DENONAVPCONTROL_AUDIO0');
				if ($gZone > 0) {
					$menuText .= "\nZone: " . ($gZone+1);
				}

				push @menu,	{
						text => $menuText,
						id      => 'preLevel',
						"icon" => $volIcon,
						actions  => {
							go  => {
								player => 0,
								cmd    => [ 'avpLvl' ],
								params	=> {
									menu => 'avpLvl',
								},
							},
						},
					};
			}
			
			$menuText = $client->string('PLUGIN_DENONAVPCONTROL_AUDIO8');  # channel levels
			if ($gZone > 0) {
				$menuText .= "\nZone: " . ($gZone+1);
			}

			push @menu,	{
					text => $menuText,
					id      => 'channels',
					"icon" => $chnIcon,
					actions  => {
						go  => {
							player => 0,
							cmd    => [ 'avpChannels' ],
							params	=> {
								menu => 'avpChannels',
							},
						},
					},
				};
		}
		
		$menuText = $client->string('PLUGIN_DENONAVPCONTROL_AUDIO9');  # quick select
		if ($gZone > 0) {
			$menuText .= "\nZone: " . ($gZone+1);
		}
	
		push @menu,	{
				text => $menuText,
				id      => 'quickselect',
				"icon" => $swIcon,
				actions  => {
					go  => {
						player => 0,
						cmd    => [ 'avpQuickSelect' ],
						params	=> {
							menu => 'avpQuickSelect',
						},
					},
				},
			};
			
		$menuText = $client->string('PLUGIN_DENONAVPCONTROL_AUDIO10');  # source select
		if ($gZone > 0) {
			$menuText .= "\nZone: " . ($gZone+1);
		}
	
		push @menu,	{
				text => $menuText,
				id      => 'sourceSelect',
				"icon" => $sourceIcon,
				actions  => {
					go  => {
						player => 0,
						cmd    => [ 'avpSourceSelect' ],
						params	=> {
							menu => 'avpSourceSelect',
						},
					},
				},
			};
			
		if ($gZone == 0) {  # only for main zone		
			push @menu,	{
					text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO1'),
					id      => 'surroundmode',
					"icon" => $surroundIcon,
					actions  => {
						go  => {
							player => 0,
							cmd    => [ 'avpSM' ],
							params	=> {
								menu => 'avpSM',
							},
						},
					},
				};
				
			push @menu,	{
					text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO2'),
					id      => 'roomequalizer',
					"icon" => $roomEqIcon,
					actions  => {
						go  => {
							player => 0,
							cmd    => [ 'avpRmEq' ],
							params	=> {
								menu => 'avpRmEq',
							},
						},
					},
				};
				
			push @menu,	{
					text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO3'),
					id      => 'dynamicequalizer',
					"icon" => $dynamicEqIcon ,
					actions  => {
						go  => {
							player => 0,
							cmd    => [ 'avpDynEq' ],
							params	=> {
								menu => 'avpDynEq',
							},
						},
					},
				};
				
			if ($avp == 1) {   # only for AVP
				push @menu,	{
					text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO4'),
					id      => 'nightmode',
					"icon" => $dynamicVolIcon,
					actions  => {
						go  => {
							player => 0,
							cmd    => [ 'avpNM' ],
							params	=> {
								menu => 'avpNM',
							},
						},
					},
				};
			}
			
			push @menu,	{
					text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO5'),
					id      => 'restorer',
					"icon" => $restorerIcon,
					actions  => {
						go  => {
							player => 0,
							cmd    => [ 'avpRes' ],
							params	=> {
								menu => 'avpRes',
							},
						},
					},
				};
				
			push @menu,	{
					text => $client->string('PLUGIN_DENONAVPCONTROL_AUDIO6'),
					id      => 'reflevel',
					"icon" => $refIcon,
					actions  => {
						go  => {
							player => 0,
							cmd    => [ 'avpRefLvl' ],
							params	=> {
								menu => 'avpRefLvl',
							},
						},
					},
				};
		
		}  # main zone
		
	}  # player is on and initialized
	
	my $numitems = scalar(@menu);
	$log->debug("Done setting up menu items: numitems=" . $numitems . "\n");
	
	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	$request->addResult("window", { "windowStyle" => "icon_list" });
	
	my $cnt = 0;
	for my $eachPreset (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachPreset);
		$cnt++;
	}
	
	if (!$PwrOn || !$showSettings || $curAvrSource{$client} eq "") {
		$log->debug( "Player not on or not initialized: skipping full menu for " . $client->name() . "\n");	
	} elsif (!$gMenuPopulated{$client} ) {   # only first time through after powered on or subsequent Quick Select
		$log->debug("done with main menu setup");
		if ($gZone == 0) {   # main menu for the main zone only
			# now check with the AVP to set the values of the settings
			Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, $gRefreshCVTable{$client});
		} else {   # get channel levels only for other zones
			Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpChannelLevels($client, $avpIPAddress, $gZone);
		}
		$gMenuPopulated{$client} = 1;
	}
	
	$request->setStatusDone();
}


# Generates the Surround Mode menu, which is a list of all surround modes
sub avpSM {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $avpIPAddress = $gIPAddress{$client};
		
	my @menu = ();	
	my $i = 0;
	my $check;
	$gMenuUpdate{$client} = 1; # update menus from avp

	$log->debug("The value of surroundMode is:" . $surroundMode{$client} . "\n");
	if ($avp != 1) {  # AVR's only
		while ($i <13) { #set the radio to the first item as default
			if ($i == $surroundMode{$client}) {
				$check = 1;
			} else {
				$check = 0;
			};
			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_SURMDR'.($i+1)),
				radio => $check,
				actions  => {
					do  => {
						player => 0,
						cmd    => [ 'avpSetSM', $i , $surroundMode{$client}],
					},
				},
			};
					
			$i++;
		}
	} else {
		while ($i <15) { #set the radio to the first item as default
			if ($i == $surroundMode{$client}) {
				$check = 1;
			} else {
				$check = 0;
			};
			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_SURMD'.($i+1)),
				radio => $check,
				actions  => {
					do  => {
						player => 0,
						cmd    => [ 'avpSetSM', $i , $surroundMode{$client}],
					},
				},
			};
					
			$i++;
		}			
	}
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();
	
	# check if menu not initialized and call AVP to see what mode its in
	if ($surroundMode{$client} == -1) {
		# call the AVP to get mode
		Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "MS?");
	}
}

# Generates the Room equalizer menu
sub avpRmEq {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $avpIPAddress = $gIPAddress{$client};

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate{$client} = 1; # update menus from avp

	$log->debug("The value of roomEq is:" . $roomEq{$client} . "\n");

	if ($surroundMode{$client} < 2) {
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_DIRECT_MSG')
		}
	} else {
		while ($i < 5) {

			if ($i == $roomEq{$client}) {
				$check = 1;
			} else {
				$check = 0;
			};

			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_RMEQ'.($i + 1)),
				radio => $check,
				actions  => {
					do  => {
						player => 0,
						cmd    => [ 'avpSetRmEq', $i, $roomEq{$client} ],
					},
				},
			};
					
			$i++;
		}
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();
	
	# check if menu not initialized and call AVP to see what mode its in
	if ($roomEq{$client} == -1) {
		if ($avp != 1) {
			# call the AVR to get mode
			Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSMULTEQ: ?");
		} else {
			# call the AVP to get mode
			Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSROOM EQ: ?");
		}
	}
}

# Generates the Dynamic equalizer menu
sub avpDynEq {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $avpIPAddress = $gIPAddress{$client};

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate{$client} = 1; # update menus from avp
	
	$log->debug("The value of dynamicEq is:" . $dynamicEq{$client} . "\n");
	
	my $stop = 3;
	if ($avp != 1) {$stop = 2};   # for AVR's
	if ($surroundMode{$client} < 2) {
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_DIRECT_MSG')
		}
	} else {
		while ($i <$stop) {

			if ($i == $dynamicEq{$client}) {
				$check = 1;
			} else {
				$check = 0;
			};

			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_DYNVOL'.($i + 1)),
				radio => $check,
				actions  => {
					do  => {
						player => 0,
						cmd    => [ 'avpSetDynEq', $i, $dynamicEq{$client} ],
					},
				},
			};
					
			$i++;
		}
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();
	
	# check if menu not initialized and call AVP to see what mode its in
	if ($dynamicEq{$client} == -1) {
		if ($avp != 1) {
			# call the AVR to get mode
			Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSDYNEQ ?");
		} else {
			# call the AVP to get mode
			Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSDYN ?");
		}
	}
}

# Generates the Night Mode menu
sub avpNM {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avp = $cprefs->get('pref_Avp');
	my $avpIPAddress = $gIPAddress{$client};

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate{$client} = 1; # update menus from avp
	
	$log->debug("The value of nightMode is:" . $nightMode{$client} . "\n");
	
	if ($surroundMode{$client} < 2) {
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_DIRECT_MSG')
		}
	} else {
		if ($dynamicEq{$client} != 2) {
			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_NIGHT_MSG'),
			};
		};
		while ($i < 3) {
			if ($i == $nightMode{$client}) {
				$check = 1;
			} else {
				$check = 0;
			};
			if ($dynamicEq{$client} == 2) {
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_NIGHT'.($i + 1)),
					radio => $check,
					actions  => {
						do  => {
							player => 0,
							cmd    => [ 'avpSetNM', $i, $nightMode{$client} ],
						},
					},
				};
			} else {
				#no actions because no Vol set
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_NIGHT'.($i + 1)),
					radio => $check,
					actions  => {
					},
				};
			}				
			$i++;
		}
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();

	# check if menu not initialized and call AVP to see what mode its in
	if ($nightMode{$client} == -1) {
		if ($avp == 1) {
			# call the AVP to get mode
			Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSDYNSET ?");
		}
	}

}

# Generates the Restorer menu
sub avpRes {
	my $request = shift;
	my $client = $request->client();
	my $avpIPAddress = $gIPAddress{$client};

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate{$client} = 1; # update menus from avp

	$log->debug("The value of restorer is:" . $restorer{$client} . "\n");

	if ($surroundMode{$client} < 2) {
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_DIRECT_MSG')
		}
	} else {
		while ($i < 4) {
			if ($i == $restorer{$client}) {
				$check = 1;
			} else {
				$check = 0;
			};
			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_REST'.($i + 1)),
				radio => $check,
			 actions  => {
			   do  => {
					player => 0,
					cmd    => [ 'avpSetRes' , $i, $restorer{$client}],
					params => {
					},
				},
			 },
			};
					
			$i++;
		}
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();

	# check if menu not initialized and call AVP to see what mode its in
	if ($restorer{$client} == -1) {
		# call the AVP to get mode
		Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSRSTR ?");
	}
}

# Generates the Reference Level menu
sub avpRefLvl {
	my $request = shift;
	my $client = $request->client();
	my $avpIPAddress = $gIPAddress{$client};

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate{$client} = 1; # update menus from avp
	
	$log->debug("The value of refLevel is:" . $refLevel{$client} . "\n");
	
	if ($surroundMode{$client} < 2) {
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_DIRECT_MSG')
		}
	} else {
		if ($dynamicEq{$client} == 0) { # not active when dynamic eq is off
			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_REF_LEVEL_MSG'),
			};
			while ($i <4) {
				if ($i == $refLevel{$client}) {
					$check = 1;
				} else {
					$check = 0;
				};
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_REF_LEVEL'.($i * 5)),
					radio => $check,
				};
						
				$i++;
			}
		} else {
			while ($i <4) {
				if ($i == $refLevel{$client}) {
					$check = 1;
				} else {
					$check = 0;
				};
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_REF_LEVEL'.($i * 5)),
					radio => $check,
					actions  => {
						do  => {
							player => 0,
							cmd    => [ 'avpSetRefLvl' , $i, $refLevel{$client}],
							params => {
							},
						},
					},
				};
						
				$i++;
			}
		}
	}

	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();

	# check if menu not initialized and call AVP to see what mode its in
	if ($refLevel{$client} == -1) {
		# call the AVP to get mode
		Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSREFLEV ?");
	}
}

# Generates the SW State menu
sub avpSwState {
	my $request = shift;
	my $client = $request->client();
	my $avpIPAddress = $gIPAddress{$client};

	my @menu = ();
	my $i = 0;
	my $check;
	$gMenuUpdate{$client} = 1; # update menus from amp
	
	$log->debug("The value of subwoofer is:" . $subwoofer{$client} . "\n");
	
	while ($i<2) {
		if ($i == $subwoofer{$client}) {
			$check = 1;
		} else {
			$check = 0;
		};
		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_SW'.($i+1)),
			radio => $check,
			actions  => {
				do  => {
					player => 0,
					cmd    => [ 'avpSetSw', $i , $subwoofer{$client}],
				},
			},
		};
		$i++;
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();

	# check if menu not initialized and call AVP to see what mode its in
	if ($subwoofer{$client} == -1) {
		# call the AVP to get mode
		Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, "PSSWR ?");
	}
}

# Generates the Quick Select menu
sub avpQuickSelect {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $gZone = $cprefs->get('zone');
	my $avp = $cprefs->get('pref_Avp');
	my $avpIPAddress = $gIPAddress{$client};
	$log->debug("Quick Select menu routine entered..." );
	
	$log->debug("The value of qSelect is:" . $qSelect{$client} . "\n");

#	if ($channels{$client,"POPULATED"} == 0 ) {  # wait until channel table is populated
#		$log->debug("Channel table not populated: exiting");
#		$request->setStatusDone();	
#		return;
#	}
	
	my @menu = ();
	my $i = 1;
	my $check;
	my $sText;
	my $lmt = 6;	
	
	$gMenuUpdate{$client} = 1; # update menus from avp
	$gAllowQSUpdate{$client} = 1;  # allow only one QS update without intervening QS execution

	if ($avp == 1) { # less items for AVP
        $lmt = 4;
    }
	while ($i < $lmt) {
		if ($i == $qSelect{$client}) {
			$check = 1;
		} else {
			$check = 0;
		};
		
		my $tClient = $clientTable{$avpIPAddress,$gZone,$i};  # Check for a QS client in this zone
		if ($tClient ne "") {
			$sText = " (" . $tClient . ")" ;   # show the client name in the list
		} else {
			$sText = "";
		}
			

		push @menu, {
			text => $client->string('PLUGIN_DENONAVPCONTROL_QUICK'.$i) . $sText,
			radio => $check,
			actions  => {
				do  => {
					player => 0,
					cmd    => [ 'avpSetQuickSelect', $i ],
				},
			},
		};
				
		$i++;
	}

	$sText = $client->string('PLUGIN_DENONAVPCONTROL_QUICK_SAVE1') . "\n   " . $client->string('PLUGIN_DENONAVPCONTROL_QUICK_SAVE2');
	# Allow the user to update the active Quick Select settings
	push @menu, {
		text => $sText,
		radio => 0,
		nextWindow => 'refresh',
		actions  => {
			do  => {
				player => 0,
				cmd    => [ 'avpSaveQuickSelect', $qSelect{$client} ],
			},
		},
	};
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();
}

# Generates the Source Select menu
sub avpSourceSelect {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $gZone = $cprefs->get('zone');
	my $avpIPAddress = $gIPAddress{$client};
	my $curSource = $curAvrSource{$client};
	my $numInputs = $inputs{$avpIPAddress,0};

	$log->debug("Source Select menu routine entered..." );
#	$log->debug("The current source is:" . $curSource . ":\n");
	
	my @menu = ();
	my $i = 1;
	my $check;
		
	$gMenuUpdate{$client} = 1; # update menus from avp

	while ($i <= $numInputs) {
#		$log->debug("Table entry #" . $i . " is: " . $inputs{$avpIPAddress,$i} . "\n");		
		my ($avrSource, $userSource) = split (/\|/, $inputs{$avpIPAddress,$i});
#		$log->debug($avrSource . "," . $userSource . "\n");		
		if ($avrSource eq $curSource) {    # if this is the currently active input
			$check = 1;
		} else {
			$check = 0;
		};			

		push @menu, {
			text => $userSource,
			radio => $check,
			actions  => {
				do  => {
					player => 0,
					cmd    => [ 'avpSetSource', $avrSource ],
				},
			},
		};
				
		$i++;
	}
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();
}

#Generates the Preamp Level menu for non fixed volume players
sub avpLvl {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};

	$log->debug("Preamp level menu routine entered..." );

	my $level = int($preLevel{$client});
	
	if ($level > 99) { #3 digits for .5 db numbers
		$level = int($level / 10);  #remove .5 db if present
	}
	
	my $max = 80 + $cprefs->get('maxVol');	# max volume user wants AVP to be set to
	
	$gMenuUpdate{$client} = 1; # update menus from amp	
	
	$log->debug("The value of preLevel is: " . $level . "\n");
	
	#determine if user is using db or 0-100 for volume settings  ????

	my @menu = ();
	
	push @menu, {
		text => $client->string('PLUGIN_DENONAVPCONTROL_VOLUME') . " (0-" .$max. "):  [" .$level."]",
	};

	push @menu, {
		slider	=> 1,
		min 	=> 0,
		max		=> $max,
		label	=> 'Volume',
		#help    => 'help text',
		adjust 	=> 1,
		initial	=> $level,
		sliderIcons => 'volume',
		nextWindow => 'refresh',
		actions	=> {
			do  => {
				player => 0,
				cmd    => [ 'avpSetLvl' ],
				params => {
					valtag => 'value',
				},
#				nextWindow => 'refresh',
			},
		},
	};
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	# check if menu not initialized and call AVP to get the volume
	if ($preLevel{$client} == -1) {
		# call the AVP to get volume
		$log->debug("Calling SendNetAvpVolSetting...\n");		
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpVolSetting($client, $avpIPAddress, 0);
	}
	
	$request->setStatusDone();	
}

#gets the channel level setting from the AVP value
sub getChannelLevel {
	my $client = shift;
	my $avp_param = shift;
	my $avp_lvl = $channels{$client,$avp_param};
	my $value = 0;

	if ($avp_lvl < 38 || $avp_lvl > 615) {
		return 'ERROR';
	}
	
	if ($avp_lvl > 99) { #3 digits for .5 db numbers
		$value = int($avp_lvl / 10) - 50; #remove .5 db if present
	} else {
		$value = $avp_lvl - 50;
	}
	$value = sprintf("%+d", $value);
	return $value;
}

# Generates the Channels Level menu
sub avpChannels {
	my $request = shift;
	my $client = $request->client();
	my $cprefs = $prefs->client($client);
	my $speakers = $cprefs->get('speakers');
	my $zone = $cprefs->get('zone');
	my $avp = $cprefs->get('pref_Avp');
	my $avpIPAddress = $gIPAddress{$client};
	
	$log->debug("Channel levels menu routine entered..." );	
		
	my @menu = ();
	my $parm;
	my $level = '0';

	if ($channels{$client,"POPULATED"} == 0 ) {  #table not populated
		$log->debug("Channel table not populated: exiting");
		$request->setStatusDone();	
		return;
	}
	
	$gMenuUpdate{$client} = 1; # update menus from amp
	
	if ($zone == 0) {
		my $menuText = "Mode: ";
		my $i = $surroundMode{$client};
		if ($avp == 1) {
			$menuText .= $client->string('PLUGIN_DENONAVPCONTROL_SURMD'.($i+1));
		} else {
			$menuText .= $client->string('PLUGIN_DENONAVPCONTROL_SURMDR'.($i+1));
		}
			
		push @menu,	{
			text => $menuText,
			id      => 'surroundInfo',
		};			
	}
	
	$parm = 'CVFL';
	#$log->debug("The param is:" .$parm . "\n");
	$level = getChannelLevel($client,$parm);
	#$log->debug("The value param is:" .$level . "\n");

#	$log->debug("Level of FL speaker is: " . $level. "\n");

	push @menu, {
		text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		nextWindow => 'refresh',
	};		
	push @menu, {
		slider	=> 1,
		min 	=> -12 + 0,
		max		=> 12,
		label	=> 'Left',
		#help    => 'help text',
		adjust 	=> 1,
		initial	=> $level,
		sliderIcons => 'volume',
		nextWindow => 'refresh',
		actions	=> {
			do  => {
				player => 0,
				cmd    => [ 'avpSetChannels', $parm ],
				params => {
					valtag => 'value',
				},
			},
		},
	};
	
	$parm = 'CVFR';
	$level = getChannelLevel($client,$parm);
	
	push @menu, {
		text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
		nextWindow => 'refresh',
	};
	push @menu, {
		slider => 1,
		min 	=> -12 + 0,
		max		=> 12,
		#text	=> 'Right',
		#help    => NO_HELP_STRING_YET,
		adjust 	=> 1,
		initial	=> $level,
		sliderIcons => 'volume',
		nextWindow => 'refresh',
		actions	=> {
			do  => {
				player => 0,
				cmd    => [ 'avpSetChannels', $parm ],
				params => {
					valtag => 'value',
				},
			},
		},
	};
	
	if ($zone == 0) {  # main zone only
		if ($surroundMode{$client} > 2 ) { # center channel if not PURE/DIRECT or STEREO
			$parm = 'CVC';
			$level = getChannelLevel($client,$parm);

			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
				nextWindow => 'refresh',
			};
			push @menu, {
				slider => 1,
				min 	=> -12 + 0,
				max		=> 12,
				#text	=> 'Center',
				#help    => NO_HELP_STRING_YET,
				adjust 	=> 1,
				initial	=> $level,
				sliderIcons => 'volume',
				nextWindow => 'refresh',
				actions	=> {
					do  => {
						player => 0,
						cmd    => [ 'avpSetChannels', $parm ],
						params => {
							valtag => 'value',
						},
					},
				},
			};
		};  # center channel
		
		if ($surroundMode{$client} > 1 ) {  # ignore the remaining channels for PURE/DIRECT		
			if ($avp == 1) {
				$parm = 'CVSW1';		
			} else {
				$parm = 'CVSW';
			}
			$level = getChannelLevel($client,$parm);

			
			push @menu, {
				text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
				nextWindow => 'refresh',
			};
			push @menu, {
				slider => 1,
				min 	=> -12 + 0,
				max		=> 12,
				adjust 	=> 1,
				initial	=> $level,
				sliderIcons => 'volume',
				nextWindow => 'refresh',
				actions	=> {
					do  => {
						player => 0,
						cmd    => [ 'avpSetChannels', $parm ],
						params => {
							valtag => 'value',
						},
					},
				},
			};
			
			if ($speakers > 0) {
				$parm = 'CVSL';
				$level = getChannelLevel($client,$parm);
				
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
				};
				push @menu, {
					slider => 1,
					min 	=> -12 + 0,
					max		=> 12,
					adjust 	=> 1,
					initial	=> $level,
					sliderIcons => 'volume',
					nextWindow => 'refresh',
					actions	=> {
						do  => {
							player => 0,
							cmd    => [ 'avpSetChannels', $parm ],
							params => {
								valtag => 'value',
							},
						},
					},
				};
				$parm = 'CVSR';
				$level = getChannelLevel($client,$parm);
				
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . " [".$level."dB]",
				};
				push @menu, {
					slider => 1,
					min 	=> -12 + 0,
					max		=> 12,
					adjust 	=> 1,
					initial	=> $level,
					sliderIcons => 'volume',
					nextWindow => 'refresh',
					actions	=> {
						do  => {
							player => 0,
							cmd    => [ 'avpSetChannels', $parm ],
							params => {
								valtag => 'value',
							},
						},
					},
				};
			} #if ($speakers > 0)
		
			if ($speakers == 2) { #front height
				$parm = 'CVFHL';
				$level = getChannelLevel($client,$parm);
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
				};
				push @menu, {
					slider => 1,
					min 	=> -12 + 0,
					max		=> 12,
					adjust 	=> 1,
					initial	=> $level,
					sliderIcons => 'volume',
					nextWindow => 'refresh',
					actions	=> {
						do  => {
							player => 0,
							cmd    => [ 'avpSetChannels', $parm ],
							params => {
								valtag => 'value',
							},
						},
					},
				};
				
				$parm = 'CVFHR';
				$level = getChannelLevel($client,$parm);
				
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
				};
				push @menu, {
					slider => 1,
					min 	=> -12 + 0,
					max		=> 12,
					adjust 	=> 1,
					initial	=> $level,
					sliderIcons => 'volume',
					nextWindow => 'refresh',
					actions	=> {
						do  => {
							player => 0,
							cmd    => [ 'avpSetChannels', $parm ],
							params => {
								valtag => 'value',
							},
						},
					},
				};
			} elsif ($speakers == 3) { #front wide
				$parm = 'CVFWL';
				$level = getChannelLevel($client,$parm);
				
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
				};
				push @menu, {
					slider => 1,
					min 	=> -12 + 0,
					max		=> 12,
					adjust 	=> 1,
					initial	=> $level,
					sliderIcons => 'volume',
					nextWindow => 'refresh',
					actions	=> {
						do  => {
							player => 0,
							cmd    => [ 'avpSetChannels', $parm ],
							params => {
								valtag => 'value',
							},
						},
					},
				};
				
				$parm = 'CVFWR';
				$level = getChannelLevel($client,$parm);
				
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
				};
				push @menu, {
					slider => 1,
					min 	=> -12 + 0,
					max		=> 12,
					adjust 	=> 1,
					initial	=> $level,
					sliderIcons => 'volume',
					nextWindow => 'refresh',
					actions	=> {
						do  => {
							player => 0,
							cmd    => [ 'avpSetChannels', $parm ],
							params => {
								valtag => 'value',
							},
						},
					},
				};
			} elsif ($speakers == 4) { #back
				$parm = 'CVSBL';
				$level = getChannelLevel($client,$parm);
				
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
				};
				push @menu, {
					slider => 1,
					min 	=> -12 + 0,
					max		=> 12,
					adjust 	=> 1,
					initial	=> $level,
					sliderIcons => 'volume',
					nextWindow => 'refresh',
					actions	=> {
						do  => {
							player => 0,
							cmd    => [ 'avpSetChannels', $parm ],
							params => {
								valtag => 'value',
							},
						},
					},
				};
				
				$parm = 'CVSBR';
				$level = getChannelLevel($client,$parm);
				
				push @menu, {
					text => $client->string('PLUGIN_DENONAVPCONTROL_'.$parm) . "  [".$level."dB]",
				};
				push @menu, {
					slider => 1,
					min 	=> -12 + 0,
					max		=> 12,
					adjust 	=> 1,
					initial	=> $level,
					sliderIcons => 'volume',
					nextWindow => 'refresh',
					actions	=> {
						do  => {
							player => 0,
							cmd    => [ 'avpSetChannels', $parm ],
							params => {
								valtag => 'value',
							},
						},
					},
				};
			}
		}
	}  # if zone == 0
	
	my $numitems = scalar(@menu);

	$request->addResult("count", $numitems);
	$request->addResult("offset", 0);
	my $cnt = 0;
	
	for my $eachItem (@menu[0..$#menu]) {
		$request->setResultLoopHash('item_loop', $cnt, $eachItem);
		$cnt++;
	}
	
	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
# Callback to grab client playerpref changes
# ----------------------------------------------------------------------------
sub playerPrefCommand {
	my $request = shift;
	
	# Do nothing if request is not defined
	if(!defined( $request)) {
		$log->debug( "*** DenonAvpControl: playerPrefCommand() Request is not defined \n");
		return;
	}
	
	my $client = $request->client();
	
	# Do nothing if client is not defined
	if(!defined( $client)) {
		$log->debug( "*** DenonAvpControl: playerPrefCommand() Client is not defined \n");
		$request->setStatusBadDispatch();
		return;
	}
	
	my $prefName = $request->getParam('_prefname');
	
#	$log->debug( "*** DenonAvpControl: request: " . Dumper($request) . "\n");
	$log->debug( "*** DenonAvpControl: Player: " . $client->name() . ", Prefname: " . $prefName . "\n");

	if ( $client->power() && ($prefName eq "digitalVolumeControl") ) {
		my $tempLevelFixed = !($request->getParam('_newvalue'));
		if ($tempLevelFixed ne $outputLevelFixed{$client}) {
#			$outputLevelFixed{$client} = $tempLevelFixed;
			my $cprefs = $prefs->client($client);
			my $gZone = $cprefs->get('zone');
			my $avpIPAddress = $gIPAddress{$client};
			if ( $tempLevelFixed ) {  # changing from variable to fixed, so mute AVR
				Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpMuteToggle($client, $avpIPAddress, $gZone, 1);  # mute the AVR	
			} 
			else {  # changing from fixed to variable, so unmute AVR if needed
				if ($curVolume{$client} <= 0) {
					Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpMuteToggle($client, $avpIPAddress, $gZone, 0);  # unmute the AVR	
#					Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpVol($client, $avpIPAddress, "UP", $gZone);
				}
			}	
			$gFixedVarToggleInProgress{$client} = 1;  # so we can finish this in prefSetCallback
		}
		# call original function after a delay
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + .5), \&playerPrefCmdFuncRef, $request);
	}
	else {
		&{$gOrigPlayerPrefCmdFuncRef}($request);  # call original function
	}
}	

# ----------------------------------------------------------------------------
# Call original playerPref function
# ----------------------------------------------------------------------------
sub playerPrefCmdFuncRef {
	my $client = shift;
	my $request = shift;
	
	&{$gOrigPlayerPrefCmdFuncRef}($request);  # call original function
}

# ----------------------------------------------------------------------------
# Callback to get server prefset changes
# ----------------------------------------------------------------------------
sub prefSetCallback {
	my $request = shift;
	my $client = $request->client();
	
	# Do nothing if client is not defined
	if(!defined( $client)) {
		$log->debug( "*** DenonAvpControl: prefSetCallback() Client is not defined \n");
		return;
	}
		
	my $nameSpace = $request->getParam('_namespace');
	my $prefName = $request->getParam('_prefname');
	
#	$log->debug( "*** DenonAvpControl: request: " . Dumper($request) . "\n");
#	$log->debug( "*** DenonAvpControl: Player: " . $client->name() . ", NameSpace: " . $nameSpace . ", PrefName: " . $prefName . "\n");

	if ( !$client->power() ) {  # ignore if player is not on
		$log->debug( "*** DenonAvpControl: prefSetCallback() Player " . $client->name() . " is powered off \n");
		return;
	}

	if ( ($nameSpace eq "server") && ($prefName eq "digitalVolumeControl") ) {
		my $tempLevelFixed = !($request->getParam('_newvalue'));
		if ($tempLevelFixed ne $outputLevelFixed{$client}) {
			$outputLevelFixed{$client} = $tempLevelFixed;
			my $forv = $tempLevelFixed ? 'Fixed' : 'Variable';
			$log->debug("*** DenonAvpControl: prefSetCallback() New player output level is: $forv \n");	
			my $cprefs = $prefs->client($client);
			my $gZone = $cprefs->get('zone');
			my $avpIPAddress = $gIPAddress{$client};
			if ( $tempLevelFixed ) {  # changing from variable to fixed, so sync AVR preamp volume to client
				if (!$gFixedVarToggleInProgress{$client} ) {  # only need to do this if coming from server
					Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpMuteToggle($client, $avpIPAddress, $gZone, 1);  # mute the AVR
				}					
				$log->debug("*** DenonAvpControl: prefSetCallback() Syncing AVR and client volumes\n");	
				my $sbVolume = calculateSBVolume($client, $iInitialAvpVol{$client});
				handleVolSet( $client, $sbVolume);  # set volume level to initial value
			}
			else {   # changing from fixed to variable, so unmute AVR if necessary and reset curVolume
				if (!$gFixedVarToggleInProgress{$client} ) {  # only need to do this if coming from server
					if ($curVolume{$client} <= 0) {
						Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpMuteToggle($client, $avpIPAddress, $gZone, 0);  # unmute the AVR	
					}
				}
				if ($gZone == 0) {  # set preamp volume for audio menu
					$preLevel{$client} = abs($curVolume{$client});
				}					
				$curVolume{$client} = 0; 
			}
			$gFixedVarToggleInProgress{$client} = 0;
		}
	}
}	

# ----------------------------------------------------------------------------
# Callback to get client state changes
# ----------------------------------------------------------------------------
sub commandCallback {
	my $request = shift;
	
	$log->debug( "*** DenonAvpControl: commandCallback() p0: " . $request->{'_request'}[0] . "\n");
	$log->debug( "*** DenonAvpControl: commandCallback() p1: " . $request->{'_request'}[1] . "\n");

	my $client = $request->client();
	
	# Do nothing if client is not defined
	if(!defined( $client)) {
		$log->debug( "*** DenonAvpControl: commandCallback() Client is not defined \n");
		return;
	}
	
	my $cprefs = $prefs->client($client);
	my $gZone = $cprefs->get('zone');
#	my $DenonVol;		# Denon Volume setting
	my $quickSelect = $cprefs->get('quickSelect');
	my $timersRemoved;

	my $gPowerOnDelay = $cprefs->get('delayOn');	# Delay to turn on amplifier after player has been turned on (in seconds)
	my $gPowerOffDelay = $cprefs->get('delayOff');	# Delay to turn off amplifier after player has been turned off (in seconds)
	my $volumeSynch = $cprefs->get('pref_VolSynch');
	my $iPower = $client->power();
	my $avpIPAddress = $gIPAddress{$client};

 	$log->debug( "*** DenonAvpControl: commandCallback() Player: " . $client->name() . "\n");
	
	# Get power on and off commands
	# Sometimes we do get only a power command, sometimes only a play/pause command and sometimes both
	if ( $request->isCommand([['power']])
	 || $request->isCommand([['play']])
	 || $request->isCommand([['pause']])
	 || $request->isCommand([['playlist'], ['play']])
	 || $request->isCommand([['playlist'], ['newsong']]) ) {
		$log->debug("*** DenonAvpControl: power request1: $request \n");
		
		# Check with last known power state -> if different switch modes
		if ( $iPowerState{$client} != $iPower) {

			$iPowerState{$client} = $iPower;
			$log->debug("*** DenonAvpControl: commandCallback() Power: $iPower \n");

			if( $iPower == 1) {
				# If player is turned on within delay, kill delayed power off timer
				Slim::Utils::Timers::killTimers( $client, \&handlePowerOff); 

				$iPowerOnInProgress{$client} = 1;
				$iPowerOffInProgress{$client} = 0;
				$gMenuPopulated{$client} = 0;
				$iPaused{$client} = 0;
				$gRefreshCVTable{$client} = 1;  # refresh the channel volume table
				
				$iInitialAvpVol{$client} = calculateAvrVolume($client, 25);  # default to 25%
				$qSelect{$client} = $quickSelect;				

				# Set timer to power on amplifier after a delay
				if ( $gPowerOnDelay == 0 ) {
					$gPowerOnDelay = 1;
				}

				# Delay minimum of 3 seconds for commands other than power on
				if ( !$request->isCommand([['power']]) && $gPowerOnDelay < 3) {
					$gPowerOnDelay = 3;
				}
				
				# Check to see if player is set to fixed or variable output level
				$outputLevelFixed{$client} = !preferences('server')->client($client)->get('digitalVolumeControl');
				my $forv = $outputLevelFixed{$client} ? 'Fixed' : 'Variable';
				$log->debug("*** DenonAvpControl: commandCallback() Power On for AVP/AVR model: $gModelInfo{$avpIPAddress}" );
				$log->debug("*** DenonAvpControl: commandCallback() Player output level is: $forv \n");

				if ( $gZone == 0) {    # Check status for main zone only
					Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $gPowerOnDelay), \&handlePowerStatus); 
				} else {
					Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $gPowerOnDelay), \&handleSendPowerOn); 
				}				
			} else {
				# If player is turned off within delay, kill delayed power on timer
				if ( $gZone == 0) {
					Slim::Utils::Timers::killTimers( $client, \&handlePowerStatus); 
				} else {
					Slim::Utils::Timers::killTimers( $client, \&handleSendPowerOn); 
				}
				
				# Set timer to power off amplifier after a delay
				if ( $gPowerOffDelay == 0 ) {
					$gPowerOffDelay = 1;
				}
				if ( $iPowerOnInProgress{$client}) {
					$gPowerOffDelay += 10;  # allow time for power on to finish
				}
				Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $gPowerOffDelay), \&handlePowerOff); 
			}
		} elsif ( $iPowerOnInProgress{$client}) {   # pause playback during power on
	#		if ( !$request->isCommand([['pause']]) && !$iPaused{$client} ) {   # only for play and playlist (not pause)
			if ( !$request->isCommand([['pause']]) ) {   # only for power, play and playlist (not pause)
				$log->debug("*** DenonAvpControl: commandCallback() Pausing playback during power-on \n");
				$client->execute([('pause', '1')]);
				$iPaused{$client} = 1;
			}
		} elsif ( $iPower == 1 ) {    # handle volume syncing and double-pause QS after power is on
		  	if ( $request->isCommand([['playlist'], ['newsong']]) && $outputLevelFixed{$client} && $volumeSynch ) { 
				# Kill outstanding volume requests
				Slim::Utils::Timers::killTimers( $client, \&handleVolumeRequest); 
				Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 1), \&handleVolumeRequest);
			} elsif ( $request->isCommand([['pause']]) && $quickSelect != 0 ) {   # check for 2 pauses in .5 secs for Quick Select
				# kill any dummy pauses that may be going on within the timer
				$timersRemoved = Slim::Utils::Timers::killTimers( $client, \&handleDummyPause);
				if ( $timersRemoved ) {
					$iPowerOnInProgress{$client} = 1;  # block other commands until QS completes
					$iInitialAvpVol{$client} = calculateAvrVolume($client, 25);
					$avrQSInput{$client} = "" ;
					$gMenuPopulated{$client} = 0;
					$gRefreshCVTable{$client} = 1;  # refresh the channel volume table
					$log->debug("*** DenonAvpControl: Dummy pause timers killed: $timersRemoved \n");
					Slim::Utils::Timers::killTimers( $client, \&handleQuickSelect); 
					Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 1), \&handleQuickSelect, 2);
				} else {
					# delay the dummy pause by .5 second to check for Quick Select
					Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + .5), \&handleDummyPause);
				}
			}				
		}
	# Get clients volume adjustment
	} elsif ( $request->isCommand([['mixer'], ['volume']]) && $outputLevelFixed{$client} ) {
		#check to make sure this is not us making the request first
		my $selfInitiated = $request->getResult('denonavpcontrolInitiated');
#		if ( !$selfInitiated && $iPower == 1 && !($iPowerOnInProgress{$client})) {
		if ( !$selfInitiated && !$iPowerOnInProgress{$client} && $curAvrSource{$client} ne "") {
			my $volAdjust = $request->getParam('_newvalue');

			$log->debug("*** DenonAvpControl:new SB vol: $volAdjust  \n");
			
			my $char1 = substr($volAdjust,0,1);
			
			#if it's an incremental adjustment, get the new volume from the client
			if (($char1 eq '-') || ($char1 eq '+')) {
				if ($curVolume{$client} < 0) {
					$volAdjust += abs($curVolume{$client});  # compensate for LMS setting volume to 0 after mute
					my $request = $client->execute([('mixer', 'volume', $volAdjust)]);
					# Add a result so we can detect our own volume adjustments, to prevent a feedback loop
					$request->addResult('denonavpcontrolInitiated', 1);
				}
				else {
					$volAdjust = $client->volume(); 
				}
				$log->debug("*** DenonAvpControl:current SB volume: $volAdjust  \n");
				if ($muteSwitch{$client} eq ' ') {
					$muteSwitch{$client} = $char1;  # first vol up/down
				} elsif ($muteSwitch{$client} ne $char1) {   # possible mute request
					$muteSwitch{$client} = 'm';
				}
			}
			else {  
				$muteSwitch{$client} = ' ';
				
				$volAdjust = $client->volume();   # TESTING - don't depend on client app for volume
				
				# special case to catch SB Touch firmware bug that sets vol to 100 when output level is fixed
#				if ( ($client->modelName() eq 'Squeezebox Touch') && $volAdjust == 100) {
				if ( $volAdjust == 100) {  # a user reported getting a volume request of 100 from a Squeezelite player
					$log->debug("*** DenonAvpControl:Volume set to 100% for $client->modelName() : changing to initial value  \n");
					my $sbVolume = calculateSBVolume($client, $iInitialAvpVol{$client});
					handleVolSet( $client, $sbVolume);  # set volume level to initial value
					return;
				}
			}

			# kill any volume changes that may be going on within the timer
			$timersRemoved = Slim::Utils::Timers::killTimers( $client, \&handleVolChanges);

			if ($timersRemoved && $muteSwitch{$client} eq 'm') {   # mute was requested
				$log->debug("*** DenonAvpControl: Volume change timers killed: $timersRemoved \n");
				# Kill outstanding mute requests
				Slim::Utils::Timers::killTimers( $client, \&handleMutingToggle); 
				handleMutingToggle( $client );
			} else {
				# Kill outstanding mute requests
				Slim::Utils::Timers::killTimers( $client, \&handleMutingToggle); 
				# delay the volume changes by a small interval to give the AVR time to catch up
				Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + .25), \&handleVolChanges, $volAdjust);
#				handleVolChanges( $client, $volAdjust);
			}				
		}
	} elsif ( $request->isCommand([['mixer'], ['muting']]) && $outputLevelFixed{$client}) {
#		if ( $iPower == 1 && !($iPowerOnInProgress{$client}) ) {
		if ( !$iPowerOnInProgress{$client} && $curAvrSource{$client} ne "") {
			$log->debug("*** DenonAvpControl: Muting toggle request: \n");
			# Kill outstanding mute requests
			Slim::Utils::Timers::killTimers( $client, \&handleMutingToggle); 
			# kill any volume changes that may be going on within the timer
			$timersRemoved = Slim::Utils::Timers::killTimers( $client, \&handleVolChanges);
			# delay the muting toggle to give the SB time to catch up
			Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + .25), \&handleMutingToggle );
		}
	}		
}

# ----------------------------------------------------------------------------
sub calculateAvrVolume {
	my $client = shift;
	my $volAdjust = shift;
	my $cprefs = $prefs->client($client);
	my $gZone = $cprefs->get('zone');
	my $DenonVol;
	
	$volAdjust = abs($volAdjust);  # safety valve
	my $maxVolume = $cprefs->get('maxVol');	# max volume user wants AVP to be set to
	$log->debug("*** DenonAvpControl: Max AVR volume: $maxVolume \n");
	my $subVol = sprintf("%3d",(80 + $maxVolume) * sqrt($volAdjust));
	$log->debug("*** DenonAvpControl: Client volume: $volAdjust \n");	
	$log->debug("*** DenonAvpControl: Raw subVol: $subVol \n");
#	$log->debug("*** DenonAvpControl: MaxVol: $channels{$client,'MVMAX'} \n");
	my $width = 2;
	if ( $gZone == 0 ) {  # 0.5dB increments only supported for main zone
		my $digit = int(substr($subVol,2,1));
		$subVol = int(($subVol+2)/10);  #round up for values of .8 and .9
		if (($digit>2) && ($digit<8)) {
			$subVol = $subVol*10 + 5;
			$width = 3;
		}
	} else {  # other zones
		$subVol = int(($subVol+5)/10);
	}
			
	$DenonVol = sprintf("%0*d",$width,$subVol); 			
	$log->debug("*** DenonAvpControl: Calc Vol: $DenonVol \n");
	
	return $DenonVol;
}

# ----------------------------------------------------------------------------
sub handleDummyPause {
	my $client = shift;
#	$log->debug("*** DenonAvpControl: handling Dummy Pause \n");
	my $timersRemoved = Slim::Utils::Timers::killTimers( $client, \&handleDummyPause);
}

# ----------------------------------------------------------------------------
sub handleMutingToggle {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};
	my $zone = $cprefs->get('zone');
	my $muteOnOff;

	my $sbVolume = $client->volume();  # see if client muting is currently on
	$log->debug("*** DenonAvpControl: Current SB volume: $sbVolume \n");
	
	if (($sbVolume <= 0) || ($muteSwitch{$client} eq 'm')) {  # need to mute
		$muteSwitch{$client} = ' ';
		$muteOnOff = 1;
		if ($sbVolume < 0 ) {
			$curVolume{$client} = $sbVolume;
		} else {
			$curVolume{$client} = 0;   #reset current volume
		}
	} else {   # need to unmute
		$muteOnOff = 0;
	}

	$log->debug("*** DenonAvpControl: handling Muting Toggle \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpMuteToggle($client, $avpIPAddress, $zone, $muteOnOff);
}

# ----------------------------------------------------------------------------
sub handleVolSet {
	my $client = shift;
	my $newVol = shift;
	
	$log->debug("*** DenonAvpControl: VolChange: $newVol \n");
	$client->execute([('mixer', 'volume', $newVol)]);
}

# ----------------------------------------------------------------------------
sub handleVolChanges {
	my $client = shift;
	my $volAdjust = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};
	my $zone = $cprefs->get('zone');

	my $timersRemoved = Slim::Utils::Timers::killTimers( $client, \&handleVolChanges);
#	$log->debug("*** DenonAvpControl: TESTING::: Volume change timers killed: $timersRemoved \n");

	my $DenonVol = calculateAvrVolume($client, $volAdjust);

	$log->debug("*** DenonAvpControl: VolChange: $DenonVol \n");

	$muteSwitch{$client} = ' ';  # reset the mute switch

	if ($DenonVol != $curVolume{$client} ) {  # only send volume changes
		$curVolume{$client} = $DenonVol;
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpVol($client, $avpIPAddress, $DenonVol, $zone);
	}
}

# ----------------------------------------------------------------------------
sub handleSendPowerOn {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};
	my $zone = $cprefs->get('zone');
	
	$log->debug("*** DenonAvpControl: handling Send Power ON \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpOn($client, $avpIPAddress, $zone, 1);
}

# ----------------------------------------------------------------------------
sub handlePowerOn {
	my $class = shift;
	my $client = shift;
	
	$log->debug("*** DenonAvpControl: handling Power ON \n");
	Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 1), \&handleSendPowerOn); 
}

# ----------------------------------------------------------------------------
sub handlePowerOn2 {
	my $class = shift;
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};
	my $quickSelect = $cprefs->get('quickSelect');
	my $gZone = $cprefs->get('zone');
	my $gQuickDelay = $cprefs->get('delayQuick');	# Delay to set Quick setting (in seconds)

	$log->debug("*** DenonAvpControl: handling Power ON 2\n");

	$avrQSInput{$client} = ""; 
	
	if ( $quickSelect != 0 ) {
		# only if quick select is turned on
		if ( $gQuickDelay < 2) {  #Denon doc says to wait at least a second after PWON
			$gQuickDelay = 2;
		}
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $gQuickDelay), \&handleQuickSelect, 5); 
	} else {
		# no quick select so synch volumes
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 2), \&handleVolumeRequest); 
	}
}

# ----------------------------------------------------------------------------
sub handlePowerStatus {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};
	my $zone = $cprefs->get('zone');

	$log->debug("*** DenonAvpControl: handling Power ON Status \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpPowerStatus($client, $avpIPAddress, $zone);
}

# ----------------------------------------------------------------------------
sub handleVolumeRequest {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};
	my $gZone = $cprefs->get('zone');

	$log->debug( "*** DenonAvpControl: this vol player: " . $client . "\n");

	#now check with the AVP and get its current volume to set the SC volume
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpVolSetting($client, $avpIPAddress, $gZone);
	# /updateSqueezeVol will set the SB with the current amp setting	
}
# ----------------------------------------------------------------------------

sub handleVolReq {
	my $class = shift;
	my $client = shift;
	my $noRetry = shift;
	my $iDelay = 1;   # changed this from 2 for testing

	if ( $noRetry == 1) {  # an alternate QS command timed out
		$iPowerOnInProgress{$client} = 0;
		$gMenuPopulated{$client} = 1;   # no need to repopulate the menu
	} elsif ( $outputLevelFixed{$client} || $iPowerOnInProgress{$client}) {  # only if player is set to fixed output level (or power on)
		$log->debug( "*** DenonAvpControl: vol req from comms: " . $client . "\n");
		if ( $iPowerOnInProgress{$client} == 2 ) {  # this is a retry
			$iDelay = 0.5;
		}
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $iDelay), \&handleVolumeRequest ); 
		$iPowerOnInProgress{$client} = 2;  # indicates that we already waited after QS
	}
}

# ----------------------------------------------------------------------------
sub handlePowerOff {
	my $client = shift;
	my $force = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};
	my $zone = $cprefs->get('zone');
	
	if ( !$force && ( $avrQSInput{$client} ne "" || $iPowerOnInProgress{$client} ) ) {
		$log->debug("*** DenonAvpControl: handling zone Power OFF, checking input source \n");
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpInputSource($client, $avpIPAddress, $zone);
	} else {
		$log->debug("*** DenonAvpControl: handling Power OFF \n");
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpStandBy($client, $avpIPAddress, $zone);
		$curAvrSource{$client} = "";  # clear the current source
	}
	
	if ( !$force ) {
		$iPowerOnInProgress{$client} = 0;
		$iPowerOffInProgress{$client} = 1;
#		$outputLevelFixed{$client} = 0;      #NEXTRELEASE  - comment this line out
	}
}

# ----------------------------------------------------------------------------
sub handleQuickSelect {
	my $client = shift;
	my $timeout = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};
	my $quickSelect = $cprefs->get('quickSelect');
	my $zone = $cprefs->get('zone');

	$log->debug("*** DenonAvpControl: handling quick select \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpQuickSelect($client, $avpIPAddress, $quickSelect, $zone, $timeout);
	$qSelect{$client} = $quickSelect;
}

# ----------------------------------------------------------------------------
sub handleInputQuery {
	my $class = shift;
	my $client = shift;
	my $avrInput = shift;
	my $earlyDetection = shift;
	
	$log->debug("*** DenonAvpControl: handling input query response: " . $avrInput . "\n");
	
	$curAvrSource{$client} = $avrInput;   # store the current source
	
	if ( ($iPowerOffInProgress{$client}) ) {
		if ( $avrInput eq $avrQSInput{$client} ) {  # only power off if it's the same input we started with
			$log->debug("*** DenonAvpControl: handling main zone Power OFF \n");
			Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 1), \&handlePowerOff, 1 ); 
		} else {
			$log->debug("*** DenonAvpControl: input changed; skipping Power OFF\n");
		}
		$avrQSInput{$client} = "" ;
		$iPowerOffInProgress{$client} = 0;
	} else {
		if ($avrQSInput{$client} eq "") {   # if this is from the primary QS
			$avrQSInput{$client} = $avrInput;  # store the input source
		}
		if ($earlyDetection == 0) {  # not coming from the QS command response
			if ( $iPaused{$client} ) {  # if we paused playback during power on processing, restart it
				$log->debug("*** DenonAvpControl: Resuming paused playback after power-on \n");
				$client->execute([('playlist', 'jump', '+0')]);
				$client->execute([('play')]);
				$iPaused{$client} = 0;
			}
			$iPowerOnInProgress{$client} = 0;  # re-open command processing
		}
	}
}		

# ----------------------------------------------------------------------------
sub handleInputSource {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};
	my $zone = $cprefs->get('zone');
	my $onOff = $iPowerOffInProgress{$client} ? "OFF" : "ON / Quick Select";

	$log->debug("*** DenonAvpControl: handling zone Power " . $onOff . ", checking input source \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpInputSource($client, $avpIPAddress, $zone);
#	$iPowerOnInProgress{$client} = 0; 
}
		
# ----------------------------------------------------------------------------
sub retryInputSource {  # called from comms error routine after failed 'SI' command
	my $class = shift;
	my $client = shift;
	
	$log->debug("*** DenonAvpControl: retrying failed input source query \n");
	Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + .3), \&handleInputSource ); 
}
		
# ----------------------------------------------------------------------------
sub updateSqueezeVol { #used to sync SB vol with AVP
	my $class = shift;
	my $client = shift;
	my $avpVol = shift;
	my $avpIPAddress = $gIPAddress{$client};
	my $cprefs = $prefs->client($client);
	my $zone = $cprefs->get('zone');
	my $audioEnabled = $cprefs->get('pref_AudioMenu');
	my $iDelay = 0;
	
	$log->debug("*** DenonAvpControl: handling response to vol request \n");

	if ( $iPowerOnInProgress{$client} ) {  #volume sync from Quick Select
		$log->debug("*** DenonAvpControl: saving initial AVR volume value (" . int($avpVol) . ")\n");	
		$iInitialAvpVol{$client} = int($avpVol);  #store inital volume for use later
		if ($audioEnabled) {  # audio menus in use
			my $modelInfo = $gModelInfo{$avpIPAddress};
			if ( $modelInfo eq "" || $modelInfo eq "unknown" || $modelInfo eq "inprogress") {  # get the model info if not yet available
				$log->debug("*** DenonAvpControl: getting AVP/AVR model string from device \n");
				Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 0.3), \&getAvpModelInfo); 
				$iDelay = 5;  # allow more time before (re-)populating the menu
			}
			else {
				$iDelay = 0.3;
			}
			Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $iDelay ), \&getAvpSettings, $zone ); 
		}		
	}
			
	if ( !$outputLevelFixed{$client} ) {   # only if player is set at variable output level
#		$iPowerOnInProgress{$client} = 0; 
		$preLevel{$client} = int($avpVol);
		$log->debug("*** DenonAvpControl: New preamp level is: " . $preLevel{$client} . "\n");
		if ($gMenuUpdate{$client}) {
			Slim::Control::Request::executeRequest( $client, [ 'avpLvl' ] ); 
		}
	} else {
		$log->debug( "*** DenonAvpControl: The client is: " . $client . "\n");
		$log->debug( "*** DenonAvpControl: AVR vol: " . $avpVol . "\n");
	
		$curVolume{$client} = $avpVol;   # store current AVR volume

		my $volAdjust = calculateSBVolume($client, $avpVol);
				
		my $request = $client->execute([('mixer', 'volume', $volAdjust)]);
		# Add a result so we can detect our own volume adjustments, to prevent a feedback loop
		$request->addResult('denonavpcontrolInitiated', 1);
	}
	
	if ( $iPowerOnInProgress{$client} && ($avrQSInput{$client} eq "" || $audioEnabled) ) {  # store input source
		if ($audioEnabled) {  # audio menus in use
			$iDelay = 3;  # allow more time for menus to be populated
		} else {
			$iDelay = 0.5; # no need to wait as long
		}	
		
		$log->debug("*** DenonAvpControl: setting timer to store AVR input \n");
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + $iDelay), \&handleInputSource ); 
	} else {
		if ( $iPaused{$client} ) {  # if we paused playback during power on processing, restart it
			$log->debug("*** DenonAvpControl: Resuming paused playback after power-on \n");
			$client->execute([('playlist', 'jump', '+0')]);
			$client->execute([('play')]);
			$iPaused{$client} = 0;
		}
		$iPowerOnInProgress{$client} = 0; 
	}	
}

# ----------------------------------------------------------------------------
sub getAvpModelInfo {  # populate the AVR model info
	my $client = shift;
	my $avpIPAddress = $gIPAddress{$client};

	my $modelInfo = $gModelInfo{$avpIPAddress};
	
#	if ($modelInfo ne "inprogress" ) {  # skip if request in progress    # TESTING
		if ( $modelInfo eq "" || $modelInfo eq "unknown") {
			$gModelInfo{$avpIPAddress} = "inprogress";
			$log->debug("*** DenonAvpControl: getting AVR model string from device \n");
			Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpGetModelInfo($client, $avpIPAddress);
		}
#	}	# TESTING
}	

# ----------------------------------------------------------------------------
sub getAvpInputTable {  # populate the AVR input table
	my $client = shift;
	my $avpIPAddress = $gIPAddress{$client};
		
	$log->debug("*** DenonAvpControl: getting AVR input table from device \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpGetInputs($client, $avpIPAddress);
}	

# ----------------------------------------------------------------------------
sub getAvpSettings {  # populate the client audio menu
	my $client = shift;
	my $zone = shift;
	my $avpIPAddress = $gIPAddress{$client};
	
	$log->debug("*** DenonAvpControl: Getting AVR menu values\n");
	
	if ($zone == 0) {  # main menu for the main zone only
		# now check with the AVP to set the values of the settings
		Plugins::DenonAvpControl::DenonAvpComms::SendNetGetAvpSettings($client, $avpIPAddress, $gRefreshCVTable{$client});
	} else {   # get channel levels only for other zones
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpChannelLevels($client, $avpIPAddress, $zone);
	}
	$gMenuPopulated{$client} = 1;
}

# ----------------------------------------------------------------------------
sub calculateSBVolume {  # convert AVR volume to SB value (0-100)
	my $client = shift;
	my $avpVol = shift;
	
	# change the AVR volume to the SB value
	my $maxVolume = $prefs->client($client)->get('maxVol');	# max volume user wants AVR to be set to
	$log->debug("*** DenonAvpControl: Max volume: $maxVolume \n");
	if ( (length($avpVol) < 3) || (substr($avpVol,2,1) ne '5') ) {
		$avpVol = substr($avpVol,0,2) * 10;
	}
	
	my $volAdjust = sprintf("%d", (($avpVol / (80 + $maxVolume))**2) + 0.5);
	if ($volAdjust > 100) {
		$volAdjust = 100;
	}
	$log->debug("*** DenonAvpControl: New SB Vol for AVR: " . $volAdjust . "\n");
	
	return $volAdjust;
}

# ----------------------------------------------------------------------------
sub avpSetSM { # used to set the AVP surround mode
	my $request = shift;
	my $client = $request->client();

	my $avpIPAddress = $gIPAddress{$client};
	my $sMode = $request->getParam('_surroundMode'); #surround mode index
	my $sOldMode = $request->getParam('_oldSurroundMode'); #old surround mode index
	if ($sMode != $surroundMode{$client}) { #change the value
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpSurroundMode($client, $avpIPAddress, $sMode);
		$surroundMode{$client} = $sMode;
	}
	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateSurroundMode { #used to sync Surround Mode with AVP
	my $class = shift;
	my $client = shift;
	$surroundMode{$client} = shift; #will auto pick avp or avr

	$log->debug("*** DenonAvpControl: New SM is: " . $surroundMode{$client} . "\n");
	
	if ($gMenuUpdate{$client}) {
		Slim::Control::Request::executeRequest( $client, [ 'avpSM' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetRmEq { # used to set the AVP room equalizer mode
	my $request = shift;
	my $client = $request->client();
	my $avpIPAddress = $gIPAddress{$client};

	my $sMode = $request->getParam('_roomEq'); #Room eq index
	my $sOldMode = $request->getParam('_oldRoomEq'); #Room eq index
	$log->debug("sMode: $sMode \n");
	if ($sMode != $roomEq{$client}) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpRoomMode($client, $avpIPAddress, $sMode);
		$roomEq{$client} = $sMode;
	}
	$log->debug("roomEq: $roomEq{$client} \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateRoomEq { #used to sync Room EQ with AVP
	my $class = shift;
	my $client = shift;
	$roomEq{$client} = shift;
	$log->debug("*** DenonAvpControl: New Room EQ is: " . $roomEq{$client}. "\n");

	if ($gMenuUpdate{$client}) {
		Slim::Control::Request::executeRequest( $client, [ 'avpRmEq' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetDynEq{ # used to set the AVP dynamic equalizer mode
	my $request = shift;
	my $client = $request->client();	
	my $avpIPAddress = $gIPAddress{$client};

	my $sMode = $request->getParam('_dynamicEq'); #dynamic equalizer mode
	my $sOldMode = $request->getParam('_oldDynamicEq'); # old dynamic equalizer mode
	$log->debug("sMode: $sMode \n");
	if ($sMode != $dynamicEq{$client}) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetDynamicEq($client, $avpIPAddress, $sMode);
		$dynamicEq{$client} = $sMode;
	}

	$log->debug("dynamicEq: $dynamicEq{$client} \n");

	$request->setStatusDone();

	# update the plugin menu
	$log->debug("Refreshing menus after DynEq setting");
	Slim::Control::Jive::refreshPluginMenus($client);
}

# ----------------------------------------------------------------------------
sub updateDynEq { #used to sync Dynamic EQ with AVP
	my $class = shift;
	my $client = shift;
	$dynamicEq{$client} = shift;
	$log->debug("*** DenonAvpControl: Dynamic EQ is: " . $dynamicEq{$client}. "\n");

	if ($gMenuUpdate{$client}) {
		Slim::Control::Request::executeRequest( $client, [ 'avpDynEq' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetNM { # used to set the AVP Night mode
	my $request = shift;
	my $client = $request->client();
	my $avpIPAddress = $gIPAddress{$client};

	my $sMode = $request->getParam('_nightMode'); #night mode index
	my $sOldMode = $request->getParam('_oldNightMode'); # old night mode index
	if ($sMode != $nightMode{$client}) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpNightMode($client, $avpIPAddress, $sMode);
		$nightMode{$client} = $sMode;
	}
	$log->debug("nightMode: $nightMode{$client} \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateNM { #used to sync Night Mode with AVP
	my $class = shift;
	my $client = shift;
	$nightMode{$client} = shift;
	$log->debug("*** DenonAvpControl: Night Mode is: " . $nightMode{$client}. "\n");

	if ($gMenuUpdate{$client}) {
		Slim::Control::Request::executeRequest( $client, [ 'avpNM' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetRes { # used to set the AVP restorer mode
	my $request = shift;
	my $client = $request->client();
	my $avpIPAddress = $gIPAddress{$client};

	my $sMode = $request->getParam('_restorer'); #restorer index
	my $sOldMode = $request->getParam('_oldRestorer'); # old restorer index
	if ($sMode != $restorer{$client}) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpRestorerMode($client, $avpIPAddress, $sMode, 0);
		$restorer{$client} = $sMode;
	}

	$log->debug("restorer: $restorer{$client} \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateRestorer { #used to sync Restorer with AVP
	my $class = shift;
	my $client = shift;
	$restorer{$client} = shift;
	$log->debug("*** DenonAvpControl: Restorer Mode is: " . $restorer{$client}. "\n");

	if ($gMenuUpdate{$client}) {
		Slim::Control::Request::executeRequest( $client, [ 'avpRes' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetRefLvl { # used to set the AVP reference level mode
	my $request = shift;
	my $client = $request->client();
	my $avpIPAddress = $gIPAddress{$client};

	my $sMode = $request->getParam('_refLevel'); #ref level index
	my $sOldMode = $request->getParam('_oldRefLevel'); # old ref level index
	if ($sMode != $refLevel{$client}) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetRefLevel($client, $avpIPAddress, $sMode);
		$refLevel{$client} = $sMode;
	}

	$log->debug("ref level: $refLevel{$client} \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateRefLevel { #used to sync reference level with AVP
	my $class = shift;
	my $client = shift;
	$refLevel{$client} = shift;
	$log->debug("*** DenonAvpControl: Reference Level is: " . $refLevel{$client}. "\n");

	if ($gMenuUpdate{$client}) {
		Slim::Control::Request::executeRequest( $client, [ 'avpRefLvl' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetSw { # used to set the AVP Subwoofer state
	my $request = shift;
	my $client = $request->client();
	my $avpIPAddress = $gIPAddress{$client};

	my $sMode = $request->getParam('_subwoofer'); #Subwoofer index
	my $sOldMode = $request->getParam('_oldSubwoofer'); # old Subwoofer index
	if ($sMode != $subwoofer{$client}) {
		Plugins::DenonAvpControl::DenonAvpComms::SendNetSwState($client, $avpIPAddress, $sMode);
		$subwoofer{$client} = $sMode;
	}

	$log->debug("subwoofer: $subwoofer{$client} \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub updateSw { #used to sync SW state with AVP
	my $class = shift;
	my $client = shift;
	$subwoofer{$client} = shift;
	$log->debug("*** DenonAvpControl: Subwoofer state is: " . $subwoofer{$client}. "\n");

	if ($gMenuUpdate{$client}) {
		Slim::Control::Request::executeRequest( $client, [ 'avpSw' ] ); 
	}
}

# ----------------------------------------------------------------------------
sub avpSetQuickSelect { # used to execute a Quick Select command
	my $request = shift;
	my $client = $request->client();
	my $sMode = $request->getParam('_quickSelect'); #Quick Select index
	
	if ($iPowerOnInProgress{$client} == 1) {   	# ignore the request if another QS is in progress
		$log->debug("Quick select in progress: ignoring menu QS $sMode request \n");
		$request->setStatusDone();
		return;									# not very elegant but ...
	}
	
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};
	my $zone = $cprefs->get('zone');
	my $quickSelect = $cprefs->get('quickSelect');
	
	$gMenuPopulated{$client} = 0;   # must repopulate menu after any QS
	$iPowerOnInProgress{$client} = 1;  # block other commands until QS completes

	if ($sMode == $quickSelect) {  # if it is our defined Quick Select
		$iInitialAvpVol{$client} = calculateAvrVolume($client, 25);
		$avrQSInput{$client} = "" ;
	}
	
	$gRefreshCVTable{$client} = 1;  # refresh the channel volume table
	
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpQuickSelect($client, $avpIPAddress, $sMode, $zone, 2);
	$qSelect{$client} = $sMode;
	$gAllowQSUpdate{$client} = 1;  # allow QS update
	
	$log->debug("quick select: $sMode \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub avpSaveQuickSelect { # used to save/update a Quick Select command
	my $request = shift;
	my $client = $request->client();
	my $quickSelect = $qSelect{$client};	
	
	if ($quickSelect == 0) {   # just in case
		$request->setStatusDone();
		return;
	}
	
	if ($iPowerOnInProgress{$client} == 1 || !$gAllowQSUpdate{$client} ) {   	# ignore the request if a QS is in progress
		$log->debug("Quick select in progress: ignoring menu QS $quickSelect save request \n");
		$request->setStatusDone();
		return;		# not very elegant but ...
	}
	
	my $avpIPAddress = $gIPAddress{$client};
	my $cprefs = $prefs->client($client);
	my $zone = $cprefs->get('zone');
	
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpSaveQuickSelect($client, $avpIPAddress, $quickSelect, $zone);
	
	$gAllowQSUpdate{$client} = 0;  # block further updates until another QS is done or menu is rebuilt	
	
	my $message = $client->string('PLUGIN_DENONAVPCONTROL_QUICK_SAVE3') . " " . $quickSelect;
	$client->showBriefly( { 'jive' => { 'text' => [ $message ], } },{'duration' => 2, 'scroll' => 1, 'block' => 1 } );
	
	$log->debug("Updating quick select: $quickSelect \n");

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub avpSetSource { # used to change the input source
	my $request = shift;
	my $client = $request->client();
	my $sMode = $request->getParam('_source'); # source name
	
	if ($iPowerOnInProgress{$client} == 1) {   	# ignore the request if a QS is in progress
		$log->debug("Quick select in progress: ignoring menu Source Select request \n");
		$request->setStatusDone();
		return;									# not very elegant but ...
	}
	
	my $cprefs = $prefs->client($client);
	my $avpIPAddress = $gIPAddress{$client};
	my $zone = $cprefs->get('zone');
#	$iPowerOnInProgress{$client} = 1;  # block other commands until QS completes


#	if ( $sMode ne $curAvrSource{$client} ) {  # skip if it's the current source
		$gRefreshCVTable{$client} = 1;  # refresh the channel volume table
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpSetSource($client, $avpIPAddress, $sMode, $zone, 5);	
		$curAvrSource{$client} = $sMode;	
		$log->debug("Changed source to: " . $sMode . "\n");
#	}

	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub avpPowerToggle { # used to power the AVR on/off
	my $request = shift;
	my $client = $request->client();
	my $sMode = $request->getParam('_onOff'); # On or Off
	my $showMenu = $request->getParam('_menuPopulated');  # was the audio menu populated?
	
	if ($iPowerOnInProgress{$client} == 1) {   	# ignore the request if a QS is in progress
		$log->debug("Quick select in progress: ignoring menu Power On/Off request \n");
	} elsif ($sMode == 1) {  # power is on
		avpPowerOff($request, $showMenu);  # turn it off
	} else {
		$iPowerOnInProgress{$client} = 1;	
		avpPowerOn($request);   # turn it on
	}
	
	$request->setStatusDone();	
}

# ----------------------------------------------------------------------------
sub avpPowerOn { # used to power on the AVR
	my $request = shift;
	my $client = $request->client();	
	my $cprefs = $prefs->client($client);
	my $zone = $cprefs->get('zone');
	my $avpIPAddress = $gIPAddress{$client};
	
#	$iPowerOnInProgress{$client} = 1;	
	$log->debug("*** DenonAvpControl: handling menu Power ON request \n");
	Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpOn($client, $avpIPAddress, $zone, 0);
}

# ----------------------------------------------------------------------------
sub avpPowerOff { # used to power off the AVR
	my $request = shift;
	my $showMenu = shift;
	my $client = $request->client();
	
#	$log->debug("Show menu flag = " . $showMenu . "\n");
	if ($showMenu == 0) {
		$log->debug("Audio menu not yet displayed: refreshing menu \n");
	} else {
		$curAvrSource{$client} = "";    # clear the current source
		my $cprefs = $prefs->client($client);
		my $zone = $cprefs->get('zone');
		my $avpIPAddress = $gIPAddress{$client};
	
		$log->debug("*** DenonAvpControl: handling menu Power OFF request \n");
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpStandBy($client, $avpIPAddress, $zone);
	}
}

# ----------------------------------------------------------------------------
sub avpSetLvl { # used to set the AVP preamp level for variable mode
	my $request = shift;
	my $client = $request->client();

	my $level = $request->getParam('_level'); # AVR volume
	
	$level =~ m/(-?\d+)/; #remove label
	$level = $1;
	
	$log->debug("*** DenonAvpControl: Preamp level change request: " . $preLevel{$client} . "->" . $level . "\n");
	
	if ( !$outputLevelFixed{$client} && ($level != $preLevel{$client}) ) {
		$preLevel{$client} = $level;			
		$level = sprintf("%0*d",2,$level); 			
		my $cprefs = $prefs->client($client);
		my $avpIPAddress = $gIPAddress{$client};
		my $zone = $cprefs->get('zone');
		Plugins::DenonAvpControl::DenonAvpComms::SendNetAvpVol($client, $avpIPAddress, $level, $zone );
	}

	$log->debug("preamp level: $preLevel{$client} \n");
	
	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub avpSetChannels { # used to set the AVP channels
	my $request = shift;
	my $client = $request->client();
	
	my $channel = $request->getParam('_channel'); #the channel call
	my $level = $request->getParam('_level'); #channel level

	$level =~ m/(-?\d+)/; #remove label
	my $value = $1;
	my $oldValue = int($channels{$client,$channel});


	#convert channel level value for call
	$value += 50; #set to db abs value
	
	$log->debug("*** DenonAvpControl: Channel change: " . $channel . " " . $oldValue . "->" . $value);

	if ( $value != $oldValue) {  #don't execute if the same
		$channels{$client,$channel} = $value;  # update the table entry
		my $cprefs = $prefs->client($client);
		my $zone = $cprefs->get('zone');
		my $avpIPAddress = $gIPAddress{$client};
		Plugins::DenonAvpControl::DenonAvpComms::SendNetChannelLevel($client, $avpIPAddress, $zone, $channel, $value);
	}
				
	$request->setStatusDone();

}

# ----------------------------------------------------------------------------
sub updateChannels { #used to sync channels level with AVP
	my $class = shift;
	my $client = shift;
	my $saveHashTable = shift;
	
	if ($saveHashTable) {  # get the channel table address
		$log->debug("*** DenonAvpControl: Channel table was updated.\n");	
		my $hashRef = Plugins::DenonAvpControl::DenonAvpComms::getChannelsHash();	
		%channels = %$hashRef;
	}
}

# ----------------------------------------------------------------------------
sub handleModelInfo { #store model info string from AVR
	my $class = shift;
	my $client = shift;
	my $modelInfo = shift;
	my $avpIPAddress = $gIPAddress{$client};

	my $cprefs = $prefs->client($client);	
	my $audioEnabled = $cprefs->get('pref_AudioMenu');	

	$log->debug("*** DenonAvpControl: Model info string is: $modelInfo");
	
	$gModelInfo{$avpIPAddress} = $modelInfo;

	if (!$gInputTablePopulated{$avpIPAddress} && $audioEnabled ) {  # populate the input table from the AVR
		Slim::Utils::Timers::setTimer( $client, (Time::HiRes::time() + 0.5 ), \&getAvpInputTable);
	}						
}

# ----------------------------------------------------------------------------
sub updateInputTable { #store input table from AVR
	my $class = shift;
	my $client = shift;
	my $avpIPAddress = $gIPAddress{$client};

	$log->debug("*** DenonAvpControl: Input table was populated");
	$gInputTablePopulated{$avpIPAddress} = 1;
		
	my $hashRef = Plugins::DenonAvpControl::DenonAvpComms::getInputsHash();	
	%inputs = %$hashRef;		
}

# ----------------------------------------------------------------------------
# used to determine if connection used is digital
# We don't care if the user wants to use this in analog or non 100%
sub denonAvpInit {
	my $client = shift;
}

# ----------------------------------------------------------------------------
# determine if this player is using the DenonAvpControl plugin and its enabled
sub usingDenonAvpControl() {
	my $client = shift;
	my $cprefs = $prefs->client($client);
	my $pluginEnabled = $cprefs->get('pref_Enabled');

	# cannot use DS if no digital out (as with Baby)
	if ( (!$client->hasDigitalOut()) || ($client->model() eq 'baby')) {
		return 0;
	}
 	if ($pluginEnabled == 1) {
		return 1;
	}
	return 0;
}

# ----------------------------------------------------------------------------
# external volume indication support code
# used by iPeng and other controllers
sub getexternalvolumeinfoCLI {
	my @args = @_;
	&reportOnOurPlayers();
	if ( defined($getexternalvolumeinfoCoderef) ) {
		# chain to the next implementation
		return &$getexternalvolumeinfoCoderef(@args);
	}
	# else we're authoritative
	my $request = $args[0];
	$request->setStatusDone();
}

# ----------------------------------------------------------------------------
sub reportOnOurPlayers() {
	# loop through all currently attached players
	foreach my $client (Slim::Player::Client::clients()) {
		if (&usingDenonAvpControl($client) ) {
			# using our volume control, report on our capabilities
			$log->debug("Note that ".$client->name()." uses us for external volume control");
			Slim::Control::Request::notifyFromArray($client, ['getexternalvolumeinfo', 0,   1,   string(&getDisplayName())]);
#			Slim::Control::Request::notifyFromArray($client, ['getexternalvolumeinfo', 'relative:0', 'precise:1', 'plugin:DenonAvpControl']);
			# precise:1		can set exact volume
			# relative:1		can make relative volume changes
			# plugin:DenonSerial	this plugin's name
		}
	}
}
	
# --------------------------------------- external volume indication code -------------------------------
# end with something for plugin to do
1;
